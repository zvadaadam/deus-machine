// @zvada/agent-server/server — the standard wire (phase 2).
// JSON-RPC 2.0 over stdio/WebSocket: quick-ack turns, per-session sequenced
// events, bounded replay, engine-brokered permissions.

export { AgentServer, type AgentServerOptions } from "./agent-server.ts";
export {
	type InstallOptions,
	type InstallResult,
	runInstall,
	toolsFor,
} from "./install.ts";
export { DEFAULT_BUFFER_SIZE, SessionLog } from "./session-log.ts";
export {
	dial,
	type DialOptions,
	listen,
	type ListenOptions,
	stdioTransport,
} from "./transports.ts";
export {
	type AcpBindingOptions,
	createAcpAgentApp,
	serveAcpStdio,
} from "./acp/binding.ts";
