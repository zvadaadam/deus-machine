/**
 * What one envelope's `seq` means for a session's cursor.
 *
 *  - `deliver`   — the expected next envelope; the cursor advanced to it.
 *  - `duplicate` — already delivered (a replay overlap, a resync); drop it.
 *                  The cursor does NOT move.
 *  - `gap`       — envelopes were missed; hold this one and heal (replay).
 *                  The cursor does NOT move, so the healed events still land
 *                  in order.
 *  - `reset`     — `seq` restarted at 1 while the cursor was past it: the
 *                  session log began again (a new server process behind a
 *                  reconnecting transport). The cursor resets and DELIVERS
 *                  this envelope — treating it as a duplicate silently drops
 *                  the entire post-restart stream, which is exactly the bug
 *                  this verdict exists to prevent. The caller must drop the
 *                  state it was holding for the dead log (held-back envelopes,
 *                  partial reconstruction); the fresh log is authoritative.
 *
 * The reset rule is a HEURISTIC with two documented blind spots — at the seq
 * layer, a restart is indistinguishable from a redelivery in exactly these:
 * a restart seen while the cursor sits at 1 (the fresh seq 1 reads as a
 * duplicate), and a restart first contacted mid-stream (fresh seq k ≤ last
 * reads as a duplicate). Callers with a second signal close them: the wire
 * client detects a replay whose log ends below the cursor and adopts the
 * fresh log; a consumer that cannot replay treats any backwards seq beyond
 * the immediately-last frame as a replacement.
 */
export type SeqVerdict = "deliver" | "duplicate" | "gap" | "reset";

/**
 * Per-session `seq` bookkeeping — the whole of "did I already see this, did I
 * miss something, did the server restart", with no transport, no schemas and
 * no dependencies.
 *
 * This is the wire client's own discipline, hoisted so the consumers that
 * cannot use the client (a backend folding envelopes forwarded over its own
 * WebSocket, a Durable Object replaying a log) get the same answers instead of
 * a fourth hand-rolled variant. `AgentServerClient` is implemented on it.
 */
export interface SeqCursor {
	/** Classify `seq` for `sessionId`, advancing the cursor when it delivers. */
	advance(sessionId: string, seq: number): SeqVerdict;
	/** Forget the session entirely — the next `seq` starts a fresh stream. */
	reset(sessionId: string): void;
	/**
	 * Force the watermark (an evicted prefix accepted as lost, a snapshot
	 * restored from durable state). The next contiguous envelope is `seq + 1`.
	 */
	seek(sessionId: string, seq: number): void;
	/** Highest delivered `seq` for the session; 0 when none is known. */
	last(sessionId: string): number;
	/** The sessions with a cursor — what to resync after a reconnect. */
	sessions(): string[];
}

export function createSeqCursor(): SeqCursor {
	const lastSeq = new Map<string, number>();
	return {
		advance(sessionId, seq) {
			const last = lastSeq.get(sessionId) ?? 0;
			if (seq === 1 && last > 1) {
				lastSeq.set(sessionId, seq);
				return "reset";
			}
			if (seq <= last) return "duplicate";
			if (seq === last + 1) {
				lastSeq.set(sessionId, seq);
				return "deliver";
			}
			return "gap";
		},
		reset(sessionId) {
			lastSeq.delete(sessionId);
		},
		seek(sessionId, seq) {
			lastSeq.set(sessionId, seq);
		},
		last(sessionId) {
			return lastSeq.get(sessionId) ?? 0;
		},
		sessions() {
			return [...lastSeq.keys()];
		},
	};
}
