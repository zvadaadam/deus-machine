# RFD 0001 — Deterministic echo ids

**Status: adopted** (0.3.0, unpublished — shipped with the consumer-machinery batch).

## Change

The user echo's ids are **derived from the turn id** instead of minted as UUIDv7:

- echo message id: `echo-<turnId>`
- echo part ids: `echo-<turnId>-<index>`

Exported as `echoMessageId(turnId)` / `echoPartId(turnId, index)`;
`createUserEchoParts(input, turnId)` stamps them. This is a **documented
exception to Law 8** (engine-minted UUIDv7).

## Why

The echo is not new information — it is the caller's own input played back, and
one turn has exactly one echo message. Every consumer that renders an
optimistic prompt bubble was reconciling a look-alike against the echo by
`turnId` (spec §7.2's old rule) — a swap with visible failure modes (deus lost
file parts in the swap; agnt double-echoed). With derived ids, a consumer that
minted the `turnId` predicts the echo **byte-for-byte**: the optimistic bubble
IS the echo, and it upserts onto itself. Retried turns converge the same way
(turn admission is idempotent on `{sessionId, turnId}`).

## What ids still are

Opaque to peers. Derivation is a producer rule matched by exported consumer
helpers — not a licence to parse structure out of ids anywhere else.

## Costs (documented, accepted)

- Echo ids do not time-sort against UUIDv7 ids. Never order by id; order by
  `outputIndex`/`seq` (which the spec already mandates — Law 5).
- Echo ids fail UUID-shaped derivations: uuid-typed columns and
  `createdAtFromUUID7`-style timestamp extraction (returns 0). Derive the
  echo's time from its **turn id**, which is UUIDv7 and embedded verbatim.

## Spec delta

PROTOCOL.md §7.2 (echo reconciliation) and Law 8 (id minting) carry the
amendment; `docs/consuming.md` describes prediction instead of reconciliation.
