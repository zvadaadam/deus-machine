// Read-only projections of a folded `ConversationState`.
//
// `reduceConversation` says what the stream MEANS; these say what a UI or an
// API layer then ASKS of it. Every one of them was written independently — and
// differently — in each product before it landed here: the turn grouping (with
// the guard that keeps a finished turn out of streaming UI), the subagent
// nesting map, the "what is the agent doing right now" indicator, and the
// tool-result text every renderer falls back to.
//
// Pure, allocation-light, and derived — never cached in state, never a source
// of truth. Call them per render.

import type { ConversationMessage, ConversationState, TimelineEntry } from "./reduce.ts";
import type { ToolState } from "./tool-state.ts";

/**
 * One rendered turn card: a run of consecutive timeline entries that belong to
 * the same turn and the same speaker.
 */
export interface ConversationTurnGroup {
	turnId: string;
	role: "user" | "assistant";
	/** Messages (and compactions) in stream order. */
	entries: TimelineEntry[];
	/** True for the final group only — see `groupIntoTurns`. */
	isLatest: boolean;
}

/**
 * Group the timeline into turn cards: consecutive entries break into a new
 * group when the speaker changes or the turn changes. (A group carries one
 * `turnId`, so two back-to-back user echoes from different turns stay
 * separate even though the role is unchanged.) Compactions are engine-side
 * content and group as `assistant` within their turn — a divider that renders
 * inside the run it interrupted, which is where it happened.
 *
 * `isLatest` is TRUE FOR THE FINAL GROUP ONLY, and only while nothing follows
 * it. That guard is the whole point: a consumer renders the latest group in
 * streaming mode (expanded, live cursor), and the moment the next turn's user
 * echo lands, the previous group MUST lose the flag. Without it, the gap
 * between "user submits" and "first assistant part arrives" re-opens the
 * finished turn in streaming mode — the completed answer visibly reverts to
 * "working". Combine with your own busy flag (`isLatest && role ===
 * "assistant" && isWorking`), never with position alone.
 */
export function groupIntoTurns(state: ConversationState): ConversationTurnGroup[] {
	const groups: ConversationTurnGroup[] = [];
	let current: ConversationTurnGroup | undefined;
	for (const entry of state.timeline) {
		const role = entry.kind === "message" ? entry.role : "assistant";
		if (!current || current.turnId !== entry.turnId || current.role !== role) {
			current = { turnId: entry.turnId, role, entries: [], isLatest: false };
			groups.push(current);
		}
		current.entries.push(entry);
	}
	const last = groups[groups.length - 1];
	if (last) last.isLatest = true;
	return groups;
}

/**
 * Subagent output, keyed by the `toolCallId` of the tool that spawned it.
 *
 * A message with `parentToolCallId` is NOT top-level model output — rendering
 * it in the main flow double-prints the subagent's work next to the tool card
 * that owns it. Consumers nest `subagentGroups(state).get(part.toolCallId)`
 * under the tool part and filter parented messages out of the main timeline
 * (`groupIntoTurns` keeps them, because "which turn did this belong to" is
 * still true — the filtering is a rendering choice).
 */
export function subagentGroups(state: ConversationState): Map<string, ConversationMessage[]> {
	const groups = new Map<string, ConversationMessage[]>();
	for (const entry of state.timeline) {
		if (entry.kind !== "message" || entry.parentToolCallId === undefined) continue;
		const group = groups.get(entry.parentToolCallId);
		if (group) group.push(entry);
		else groups.set(entry.parentToolCallId, [entry]);
	}
	return groups;
}

/** What the agent is doing right now, for a live activity indicator. */
export type AgentActivity = "thinking" | "generating" | "tool_running" | "tool_failed" | "idle";

/**
 * Derive the live activity from the LAST part of the LAST top-level assistant
 * message of the LAST ACTIVE turn: reasoning → `thinking`, text →
 * `generating`, a pending/in-progress tool → `tool_running`, a failed tool →
 * `tool_failed`.
 *
 * Everything else is `idle` — no active turn, no assistant output yet, an
 * unknown part type, or a part that says nothing about what happens next (a
 * completed tool: the model is about to speak, but the stream has not said so
 * yet). `idle` DURING an active turn means "between observable activities",
 * not "finished": a consumer with its own busy flag renders its default
 * working state there rather than nothing.
 *
 * Subagent messages (`parentToolCallId`) are skipped: the main thread's
 * activity is the spawning tool call, which stays `tool_running` for as long
 * as the subagent works — otherwise the indicator would flicker on the
 * subagent's internal steps.
 */
export function agentActivity(state: ConversationState): AgentActivity {
	let activeTurnId: string | undefined;
	for (let i = state.turns.length - 1; i >= 0; i--) {
		const turn = state.turns[i];
		if (turn?.status === "active") {
			activeTurnId = turn.turnId;
			break;
		}
	}
	if (activeTurnId === undefined) return "idle";

	for (let i = state.timeline.length - 1; i >= 0; i--) {
		const entry = state.timeline[i];
		if (entry?.kind !== "message") continue;
		if (entry.turnId !== activeTurnId) continue;
		if (entry.role !== "assistant" || entry.parentToolCallId !== undefined) continue;
		const part = entry.parts[entry.parts.length - 1];
		if (!part) continue;
		// Unknown part types carry a `raw` bag and nothing we can interpret.
		if ("raw" in part) return "idle";
		if (part.type === "reasoning") return "thinking";
		if (part.type === "text") return "generating";
		if (part.type === "tool") {
			const status = part.state.status;
			if (status === "failed") return "tool_failed";
			if (status === "pending" || status === "in_progress") return "tool_running";
		}
		return "idle";
	}
	return "idle";
}

/**
 * The tool result as display text: a completed call's `output`, a failed
 * call's `error`, and "" for everything that has not produced one yet
 * (`pending`, `in_progress`) or never will (`cancelled`).
 *
 * The empty string is deliberate and load-bearing: a renderer that shows this
 * unconditionally shows nothing for a call in flight, instead of the
 * placeholder prose ("Running…", "Cancelled") each consumer invented
 * differently. Structured output (`state.content`: diffs, images, terminals)
 * is a richer view a renderer opts into — `output` stays the universal
 * fallback, per the three-audience doctrine.
 */
export function toolResultText(state: ToolState): string {
	if (state.status === "completed") return state.output;
	if (state.status === "failed") return state.error;
	return "";
}
