import {
	CLI_TOOLS,
	CliProvisioner,
	type CliTool,
	type ProvisionOptions,
	type ResolvedCli,
	toolForHarness,
} from "../core/index.ts";
import type { AgentHarness } from "../protocol/index.ts";

export interface InstallOptions {
	/** Restrict to the CLIs these harnesses need. Defaults to every tool. */
	harnesses?: AgentHarness[];
	provision?: ProvisionOptions;
	/** Injectable provisioner boundary for tests. */
	createProvisioner?: (options: ProvisionOptions) => Pick<CliProvisioner, "install">;
}

export interface InstallResult {
	tool: CliTool;
	cli: ResolvedCli;
}

/** Which managed CLIs a set of harnesses needs (deduped, stable order). */
export function toolsFor(harnesses: AgentHarness[] | undefined): CliTool[] {
	if (!harnesses) return [...CLI_TOOLS];
	// Unmanaged harnesses (acp) resolve to undefined — nothing to prefetch.
	const needed = new Set(
		harnesses.map(toolForHarness).filter((t): t is CliTool => t !== undefined),
	);
	return CLI_TOOLS.filter((tool) => needed.has(tool));
}

/**
 * Prefetch the pinned CLI builds into the managed cache — the cold-start
 * eraser: run it while building a container/sandbox image and runtime turns
 * never download. Downloads run in parallel; failures reject with the first
 * error after all settle (so one flaky download doesn't hide the others).
 */
export async function runInstall(options: InstallOptions = {}): Promise<InstallResult[]> {
	const provision = options.provision ?? {};
	const provisioner = options.createProvisioner?.(provision) ?? new CliProvisioner(provision);
	const tools = toolsFor(options.harnesses);
	const settled = await Promise.allSettled(tools.map((tool) => provisioner.install(tool)));
	const failure = settled.find((result) => result.status === "rejected");
	if (failure) throw failure.reason;
	return settled.map((result, i) => ({
		tool: tools[i] as CliTool,
		cli: (result as PromiseFulfilledResult<ResolvedCli>).value,
	}));
}
