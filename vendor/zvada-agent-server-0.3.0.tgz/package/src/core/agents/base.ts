import type {
	AgentCapabilities,
	AgentHarness,
	AgentInput,
	McpServerConfig,
	PermissionMode,
	PermissionToolCall,
	ThinkingLevel,
} from "../../protocol/index.ts";

/**
 * What the engine tells a harness after brokering a permission round-trip.
 * The harness maps this onto its native approval vocabulary (Claude
 * `allow`/`deny`, codex `accept`/`decline`/`cancel`).
 */
export type PermissionDecision =
	| {
			decision: "allow";
			/**
			 * Allow-with-modified-input (`permission.resolved.outcome.updatedInput`):
			 * the harness MUST execute this input, not the original — what was
			 * approved is what runs. Absent = the original input was approved as-is.
			 */
			updatedInput?: Record<string, unknown>;
	  }
	| { decision: "deny"; reason?: string }
	/** The turn is being cancelled — abort rather than merely skip the tool. */
	| { decision: "cancel" };

/**
 * Provided by the engine; called by a harness when its backend blocks on an
 * approval. The engine emits `permission.requested`, waits for
 * `respondPermission` (or cancellation), and returns the decision. `signal`
 * lets the harness abort the wait when its own backend gives up.
 */
export type PermissionRequestHandler = (
	toolCall: PermissionToolCall,
	opts?: { signal?: AbortSignal },
) => Promise<PermissionDecision>;

/**
 * Everything a harness needs to run one turn. The engine builds this from a
 * RunRequest. `sessionId` is our stable logical id (the session-manager key);
 * `resumeSessionId` is the harness-native id to continue (from a prior
 * `session.created`). A harness reports its discovered native id via
 * `onNativeSession` so the engine can surface it for future resumes.
 */
export interface AgentExecuteOptions {
	sessionId: string;
	turnId: string;
	cwd: string;
	additionalDirectories?: string[];
	model?: string;
	thinkingLevel?: ThinkingLevel;
	permissionMode?: PermissionMode;
	maxTurns?: number;
	systemPromptAppend?: string;
	resumeSessionId?: string;
	resumeSessionAt?: string;
	mcpServers?: Record<string, McpServerConfig>;
	env?: Record<string, string>;
	apiKey?: string;
	/** Disable all built-in tools for this turn (text-only). */
	disableTools?: boolean;
	signal?: AbortSignal;
	/**
	 * Called once with the harness-native session/thread id (for resume).
	 * Pass the harness's honest `resumed` judgment unconditionally — the
	 * runtime surfaces it only on turns that requested a resume (false =
	 * fresh-session fallback).
	 */
	onNativeSession?: (nativeSessionId: string, info?: { resumed?: boolean }) => void;
	/** Engine-brokered approval round-trip (see PermissionRequestHandler). */
	onPermissionRequest?: PermissionRequestHandler;
}

/** Raw, harness-specific event. Adapters interpret it; the engine never does. */
export type RawAgentEvent = unknown;

/**
 * What `cancel` reports back. `confirmed: true` = the cancelled state holds —
 * either nothing was running (`hadTurn: false`, a clean no-op ack) or the
 * harness acknowledged the interrupt and the turn will end promptly.
 * `confirmed: false` = a turn existed and the cancel was dispatched
 * best-effort but NOT acknowledged (the backend's interrupt timed out) — the
 * underlying agent may still be running, and the turn's `turn.ended` event
 * remains the source of truth.
 */
export interface CancelResult {
	confirmed: boolean;
	/** Whether an in-flight turn existed when the cancel arrived. */
	hadTurn: boolean;
}

/**
 * A harness: a thin wrapper over one agent backend (Claude Code, Codex SDK,
 * Codex app-server). `execute` yields raw backend events; normalization is the
 * adapter's job. Harnesses own session reuse and cancellation.
 */
export interface Agent {
	readonly harness: AgentHarness;
	readonly capabilities: AgentCapabilities;
	execute(input: AgentInput, options: AgentExecuteOptions): AsyncIterableIterator<RawAgentEvent>;
	/** Cancel the in-flight turn for a logical session (see `CancelResult`). */
	cancel(sessionId: string): Promise<CancelResult>;
	/** Release all harness-owned state for one idle logical session. */
	release?(sessionId: string): Promise<void>;
	/** Tear down every live session (process shutdown). */
	terminateAll(): Promise<void>;
}

export abstract class BaseAgent implements Agent {
	abstract readonly harness: AgentHarness;
	abstract readonly capabilities: AgentCapabilities;

	/**
	 * In-flight turn controllers per logical sessionId. A set (not a single
	 * controller) so overlapping turns on one session can't clobber each other's
	 * cancellation — `cancel(sessionId)` aborts all of them, and `endTurn`
	 * removes only the specific controller it created.
	 */
	protected readonly inflight = new Map<string, Set<AbortController>>();

	abstract execute(
		input: AgentInput,
		options: AgentExecuteOptions,
	): AsyncIterableIterator<RawAgentEvent>;

	async cancel(sessionId: string): Promise<CancelResult> {
		const controllers = this.inflight.get(sessionId);
		const hadTurn = (controllers?.size ?? 0) > 0;
		for (const controller of controllers ?? []) controller.abort();
		// Idle sessions are a clean no-op ack, and the abort signal
		// deterministically ends the engine's execute loop for tracked turns —
		// both confirmed. Harnesses whose backend needs its own interrupt
		// round-trip (claude) refine `confirmed` in their override.
		return { confirmed: true, hadTurn };
	}

	async release(sessionId: string): Promise<void> {
		await this.cancel(sessionId);
		this.inflight.delete(sessionId);
	}

	async terminateAll(): Promise<void> {
		for (const set of this.inflight.values()) {
			for (const controller of set) controller.abort();
		}
		this.inflight.clear();
	}

	/** Create a per-turn controller bound to `sessionId`, optionally chained to an external signal. */
	protected trackTurn(sessionId: string, external?: AbortSignal): AbortController {
		const controller = new AbortController();
		let set = this.inflight.get(sessionId);
		if (!set) {
			set = new Set();
			this.inflight.set(sessionId, set);
		}
		set.add(controller);
		if (external) {
			if (external.aborted) controller.abort();
			else external.addEventListener("abort", () => controller.abort(), { once: true });
		}
		return controller;
	}

	protected endTurn(sessionId: string, controller?: AbortController): void {
		const set = this.inflight.get(sessionId);
		if (!set) return;
		if (controller) set.delete(controller);
		else set.clear();
		if (set.size === 0) this.inflight.delete(sessionId);
	}
}
