# Deploying agent-server

## CLI provisioning (deterministic agents)

The native harnesses spawn real CLIs (`claude` ~220 MB, `codex` ~300 MB
unpacked). Instead of trusting whatever version a host happens to have, the
engine can **download the pinned, engine-tested builds** from the npm registry
into a local cache — sha512-verified, installed atomically, shared across
processes. Three modes (`--provision`, `$AGENT_SERVER_PROVISION`, or
`createAgentRuntime({ provision })`):

- **`auto`** (default): explicit override → host install → managed cache →
  download. Zero-config: uses what the machine has, self-heals on bare ones.
- **`pinned`**: override → cache → download. Never trusts host installs —
  every process in a fleet runs the exact tested build.
- **`system`**: override → host install only. Never downloads (air-gapped).

"Host install" means the build the installed SDK itself would run — claude's
sibling platform package, codex's vendored `@openai/codex` tree (the JS ↔ CLI
pair from your lockfile) — with PATH as codex's fallback. Overrides are
operator-level only — `$CLAUDE_CLI_PATH` / `$CODEX_CLI_PATH` (or
`provision.overrides`), never wire config: a remote client must not choose the
executable a server spawns. Auth stays host-side either way: managed CLIs read
the same `~/.claude` / `~/.codex` (or per-turn `config.apiKey` BYOK) as your
own installs. Every resolution logs one stderr line
(`claude CLI: … (cache 0.3.168)`) so runs are diagnosable.

Pins live in `src/core/provision/pins.ts`: the claude pin tracks the
lockfile's `@anthropic-ai/claude-agent-sdk` version (test-enforced); the codex
pin is the version the app-server adapter's protocol was verified against.

## Single binary & sandbox cold starts

The server compiles to a self-contained executable — no bun, node, or
node_modules on the target:

```sh
bun build --compile packages/agent-server/src/server/bin.ts --outfile dist/agent-server
# cross-compile from any machine:
#   --target=bun-darwin-arm64 | bun-darwin-x64 | bun-linux-x64 | bun-linux-arm64
#   | bun-linux-x64-musl (Alpine) | bun-linux-arm64-musl
```

Inside a compiled binary the Claude SDK can't reach its platform package, so
provisioning is what makes the binary *work*: first turn on a bare machine
downloads the pinned CLIs (~7 s on datacenter bandwidth, parallel), every
later boot resolves from cache instantly.

For sandboxes (E2B, Modal, Fly, plain Docker), erase even that first-turn cost
by prefetching **at image build time**:

```dockerfile
FROM debian:bookworm-slim
RUN apt-get update && apt-get install -y ca-certificates tar && rm -rf /var/lib/apt/lists/*
COPY dist/agent-server /usr/local/bin/agent-server
# bake the pinned CLIs into the image → zero downloads at runtime
RUN agent-server install
ENV ANTHROPIC_API_KEY=""            # or mount ~/.claude / ~/.codex at runtime
ENTRYPOINT ["agent-server", "--provision", "pinned", "--listen", "0.0.0.0:4747"]
```

`agent-server install` respects `--harness a,b` (only fetch what you run) and
`$AGENT_SERVER_CACHE_DIR` (e.g. point it at a persistent volume instead of
baking). The cache layout is version-keyed
(`<cache>/claude/0.3.168-darwin-arm64/…`), so image layers and shared volumes
dedupe naturally and concurrent cold starts converge on one copy. The cache
root is created `0o700` and must be owned by the running user — a foreign or
symlinked root is refused (predictable install paths must not be plantable).

Measured in a live E2B sandbox (x86_64 Ubuntu, 2026-07): sandbox create 0.7 s,
`install --harness claude-code` 3.0 s (71 MB, verified), first real Claude
turn over the wire (BYOK `config.apiKey`) **2.0 s**. With the CLIs baked into
the template, boot-to-first-token is effectively sandbox-create + turn time.

## Trust boundary

The WebSocket wire carries no built-in authentication or TLS termination.
Keep it on a trusted channel — localhost, sandbox-internal, or behind your own
authenticated transport boundary. The stdio wire inherits the trust of
whoever spawned the process.
