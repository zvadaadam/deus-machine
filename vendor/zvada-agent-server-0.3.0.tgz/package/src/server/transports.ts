/// <reference types="bun" />
import { createInterface } from "node:readline";
import { type WireTransport, channelTransport, pushNdjsonLines } from "../protocol/index.ts";
import type { AgentServer } from "./agent-server.ts";

/**
 * NDJSON over stdio — for a parent process that spawns the server and owns its
 * pipes (deus-machine's model). Nothing else may write to stdout in this mode;
 * logs belong on stderr.
 */
export function stdioTransport(
	stdin: NodeJS.ReadableStream = process.stdin,
	stdout: NodeJS.WritableStream = process.stdout,
): WireTransport {
	const rl = createInterface({ input: stdin, terminal: false });
	const { transport, push, end } = channelTransport({
		send: (line) => void stdout.write(`${line}\n`),
		close: () => rl.close(),
	});
	rl.on("line", push);
	rl.on("close", () => end("stdin closed"));
	// A dead parent pipe (EPIPE) must route through the close path — an
	// unhandled stream 'error' would crash the process instead.
	stdin.on("error", (err: Error) => end(`stdin error: ${err.message}`));
	stdout.on("error", (err: Error) => end(`stdout error: ${err.message}`));
	return transport;
}

export interface ListenOptions {
	/** Port to bind (0 = ephemeral). */
	port?: number;
	hostname?: string;
	/** Restrict upgrades to this path (e.g. "/wire"); any path when omitted. */
	path?: string;
}

/**
 * Accept WebSocket clients (agnt's model: the consumer connects to us). Each
 * accepted socket becomes an attached transport; all of them receive the
 * event broadcast.
 */
export function listen(
	server: AgentServer,
	opts: ListenOptions = {},
): { url: string; port: number; stop(): void } {
	type Channel = ReturnType<typeof channelTransport>;
	const bun = Bun.serve<{ channel?: Channel }>({
		port: opts.port ?? 0,
		hostname: opts.hostname ?? "127.0.0.1",
		fetch(req, srv) {
			if (opts.path && new URL(req.url).pathname !== opts.path) {
				return new Response("not found", { status: 404 });
			}
			return srv.upgrade(req, { data: {} })
				? undefined
				: new Response("websocket upgrade required", { status: 426 });
		},
		websocket: {
			open(ws) {
				const channel = channelTransport({
					send: (line) => void ws.send(line),
					close: () => ws.close(),
				});
				ws.data.channel = channel;
				server.attach(channel.transport);
			},
			message(ws, message) {
				const channel = ws.data.channel;
				if (channel) pushNdjsonLines(channel.push, message);
			},
			close(ws) {
				ws.data.channel?.end("socket closed");
			},
		},
	});
	const port = bun.port ?? opts.port ?? 0;
	return {
		url: `ws://${bun.hostname ?? opts.hostname ?? "127.0.0.1"}:${port}${opts.path ?? ""}`,
		port,
		stop: () => void bun.stop(true),
	};
}

export interface DialOptions {
	/** Base reconnect delay; grows exponentially up to `maxRetryDelayMs`. */
	retryDelayMs?: number;
	maxRetryDelayMs?: number;
	onStateChange?: (state: "connecting" | "connected" | "closed") => void;
}

/**
 * Dial out to a consumer and keep redialing on drop (echo's model: the
 * sandboxed server opens a reverse connection to the backend). The remote end
 * replays missed events via `events/replay` after each reconnect.
 */
export function dial(server: AgentServer, url: string, opts: DialOptions = {}): { stop(): void } {
	const base = opts.retryDelayMs ?? 500;
	const cap = opts.maxRetryDelayMs ?? 30_000;
	let stopped = false;
	let attempt = 0;
	let current: WireTransport | null = null;
	let socket: WebSocket | null = null;
	let timer: ReturnType<typeof setTimeout> | null = null;

	const connect = () => {
		if (stopped) return;
		opts.onStateChange?.("connecting");
		const ws = new WebSocket(url);
		socket = ws;
		const channel = channelTransport({
			send: (line) => void ws.send(line),
			close: () => ws.close(),
		});
		ws.addEventListener("open", () => {
			if (stopped) {
				ws.close();
				return;
			}
			attempt = 0;
			current = channel.transport;
			server.attach(channel.transport);
			opts.onStateChange?.("connected");
		});
		ws.addEventListener("message", (ev) => pushNdjsonLines(channel.push, ev.data));
		ws.addEventListener("close", () => {
			channel.end("socket closed");
			if (socket === ws) socket = null;
			if (current === channel.transport) current = null;
			if (stopped) return;
			opts.onStateChange?.("closed");
			attempt += 1;
			timer = setTimeout(connect, Math.min(cap, base * 2 ** Math.min(attempt - 1, 6)));
		});
		// A close event always follows; nothing to do here.
		ws.addEventListener("error", () => {});
	};

	connect();
	return {
		stop() {
			stopped = true;
			if (timer) clearTimeout(timer);
			if (current) current.close();
			else socket?.close();
			socket = null;
			current = null;
		},
	};
}
