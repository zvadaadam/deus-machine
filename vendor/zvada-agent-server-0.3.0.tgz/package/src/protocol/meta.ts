import { z } from "zod";

/**
 * The extension slot (Law 4 — ACP pattern): present on every event, part,
 * tool state, and result-content item. Adapters and products MUST NOT add
 * root-level fields to canonical types — all root names are reserved for
 * future protocol versions; extensions live here under namespaced keys
 * (`deus/...`, `agnt/...`).
 *
 * Reserved keys (W3C trace context, MCP-compatible): `traceparent`,
 * `tracestate`, `baggage`.
 */
export const MetaSchema = z.record(z.string(), z.unknown()).optional();
export type Meta = Record<string, unknown>;
