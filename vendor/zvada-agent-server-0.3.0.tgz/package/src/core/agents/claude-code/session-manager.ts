import type { McpSetServersResult } from "@anthropic-ai/claude-agent-sdk";
import type { McpServerConfig } from "../../../protocol/index.ts";
import { configFingerprint } from "../config-fingerprint.ts";
import { ClaudeGeneratorSession } from "./generator-session.ts";
import type { ClaudeSessionEndReason, ClaudeSessionExtras } from "./generator-session.ts";
import type { ClaudeSessionConfig } from "./options.ts";

/** Directory-set identity: order and duplicates don't change the sandbox surface. */
function directoriesFingerprint(dirs: string[] | undefined): string {
	return configFingerprint([...new Set(dirs ?? [])].sort());
}

/** Whether immutable Claude subprocess config changed and requires a restart. */
export function claudeSessionNeedsRestart(
	prev: ClaudeSessionConfig,
	next: ClaudeSessionConfig,
): boolean {
	return (
		prev.cwd !== next.cwd ||
		(prev.cliPath ?? "") !== (next.cliPath ?? "") ||
		(prev.permissionMode ?? "") !== (next.permissionMode ?? "") ||
		// thinking/effort are fixed at spawn in the modern SDK vocabulary (the
		// old setMaxThinkingTokens hot-swap is deprecated and effort-blind), so
		// a level change restarts — context survives via claudeRestartConfig.
		(prev.thinkingLevel ?? "") !== (next.thinkingLevel ?? "") ||
		(prev.systemPromptAppend ?? "") !== (next.systemPromptAppend ?? "") ||
		// A rewind (resumeSessionAt) is applied by the SDK only at spawn, so a
		// warm session cannot honor it — any change forces a restart. The
		// symmetric diff deliberately also restarts on set->unset: it keeps the
		// gate correct even if the stored config lags a reused turn, at the
		// cost of one extra (context-preserving) respawn after a revert.
		(prev.resumeSessionAt ?? "") !== (next.resumeSessionAt ?? "") ||
		directoriesFingerprint(prev.additionalDirectories) !==
			directoriesFingerprint(next.additionalDirectories) ||
		(prev.apiKey ?? "") !== (next.apiKey ?? "") ||
		(prev.maxTurns ?? 100) !== (next.maxTurns ?? 100) ||
		(prev.idleTimeoutMs ?? 5 * 60_000) !== (next.idleTimeoutMs ?? 5 * 60_000) ||
		Boolean(prev.disableTools) !== Boolean(next.disableTools) ||
		configFingerprint(prev.env) !== configFingerprint(next.env)
		// mcpServers deliberately absent: MCP changes hot-swap on the live
		// session (`setMcpServers`) instead of restarting the subprocess.
	);
}

/** Preserve context within the same cwd/credential boundary; explicit resume always wins. */
export function claudeRestartConfig(
	previous: ClaudeSessionConfig,
	next: ClaudeSessionConfig,
	nativeSessionId: string | null,
): ClaudeSessionConfig {
	if (next.resumeSessionId || !nativeSessionId) return next;
	const sameResumeBoundary =
		previous.cwd === next.cwd &&
		(previous.apiKey ?? "") === (next.apiKey ?? "") &&
		configFingerprint(previous.env) === configFingerprint(next.env);
	return sameResumeBoundary ? { ...next, resumeSessionId: nativeSessionId } : next;
}

/**
 * One live `ClaudeGeneratorSession` per logical session id. Decides, per turn,
 * whether the existing session can be reused (hot-swapping model/mcp) or must
 * be torn down and recreated (cwd / permission / thinking / system-prompt
 * changes alter the subprocess in ways the live query can't). `resumeSessionId`
 * is read only at spawn — it never forces a restart on a warm session.
 */
export class ClaudeSessionManager {
	private readonly sessions = new Map<string, ClaudeGeneratorSession>();

	constructor(
		private readonly onSessionEnd?: (sessionId: string, reason: ClaudeSessionEndReason) => void,
	) {}

	async getOrCreate(
		sessionId: string,
		config: ClaudeSessionConfig,
		extras?: ClaudeSessionExtras,
	): Promise<ClaudeGeneratorSession> {
		let startConfig = config;
		const existing = this.sessions.get(sessionId);
		if (existing && existing.currentState !== "terminated") {
			if (this.needsRestart(existing.currentConfig, config)) {
				startConfig = claudeRestartConfig(
					existing.currentConfig,
					config,
					existing.currentSessionId,
				);
				await existing.terminate("replaced");
				this.sessions.delete(sessionId);
			} else {
				await this.hotSwapIfNeeded(existing, config);
				return existing;
			}
		}

		const session = new ClaudeGeneratorSession(
			sessionId,
			startConfig,
			(reason) => {
				if (this.sessions.get(sessionId) === session) this.sessions.delete(sessionId);
				this.onSessionEnd?.(sessionId, reason);
			},
			extras,
		);
		this.sessions.set(sessionId, session);
		try {
			await session.start();
		} catch (err) {
			// Don't leave a half-started session in the map — it could never serve a turn.
			this.sessions.delete(sessionId);
			throw err;
		}
		return session;
	}

	get(sessionId: string): ClaudeGeneratorSession | undefined {
		return this.sessions.get(sessionId);
	}

	async terminate(sessionId: string): Promise<void> {
		const session = this.sessions.get(sessionId);
		if (!session) return;
		await session.terminate();
		if (this.sessions.get(sessionId) === session) this.sessions.delete(sessionId);
	}

	async terminateAll(): Promise<void> {
		await Promise.all([...this.sessions.values()].map((s) => s.terminate("shutdown")));
		this.sessions.clear();
	}

	private needsRestart(prev: ClaudeSessionConfig, next: ClaudeSessionConfig): boolean {
		return claudeSessionNeedsRestart(prev, next);
	}

	private async hotSwapIfNeeded(
		session: ClaudeGeneratorSession,
		next: ClaudeSessionConfig,
	): Promise<void> {
		if (next.model !== session.currentConfig.model) {
			await session.setModel(next.model);
		}
		if (
			configFingerprint(next.mcpServers ?? {}) !==
			configFingerprint(session.currentConfig.mcpServers ?? {})
		) {
			await session.setMcpServers(next.mcpServers ?? {});
		}
	}

	/**
	 * Explicit live MCP swap (e.g. mid-conversation app registration). NOTE:
	 * this syncs the session's config, so the NEXT turn's wire config (if it
	 * still carries the old server set) will swap back — explicit swappers
	 * must keep their per-turn `mcpServers` in step.
	 */
	async setMcpServers(
		sessionId: string,
		servers: Record<string, McpServerConfig>,
	): Promise<McpSetServersResult | undefined> {
		const session = this.sessions.get(sessionId);
		if (!session || session.currentState === "terminated") return undefined;
		return session.setMcpServers(servers);
	}
}
