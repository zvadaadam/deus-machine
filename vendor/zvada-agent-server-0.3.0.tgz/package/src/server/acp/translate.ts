import type { ContentBlock, McpServer, SessionUpdate } from "@agentclientprotocol/sdk";
import type { LifecycleEvent, McpServerConfig, PartInput, ToolPart } from "../../protocol/index.ts";

/**
 * Per-prompt translator from the engine's LifecycleEvents to ACP v1
 * `session/update` payloads — the exact inverse of the acp harness adapter
 * (the vocabularies were aligned for this: ToolKind, tool status, and
 * permission shapes pass through unchanged).
 *
 * Deliberate v1 gaps: sub-agent parts (`parentToolCallId`) have no ACP slot
 * and are dropped (the parent tool's result carries the outcome); the
 * `session.compaction` entity has no v1 equivalent; `usage_update` requires
 * `size`, so gauges without a window size are skipped. The user echo is
 * skipped too — the ACP client authored the prompt and re-chunking it back
 * would duplicate it.
 */
export class AcpUpdateTranslator {
	/** toolCallIds already announced via `tool_call`. */
	private readonly openedTools = new Set<string>();
	/** Text/reasoning characters already emitted per part (dedupe snapshots vs deltas). */
	private readonly sentByPart = new Map<string, number>();
	/** Message ids of the user echo (role "user") — skipped entirely. */
	private readonly userMessageIds = new Set<string>();
	/** Part ids that belong to a sub-agent (parented) — their deltas are skipped. */
	private readonly parentedParts = new Set<string>();

	translate(event: LifecycleEvent): SessionUpdate[] {
		switch (event.type) {
			case "message.started": {
				if (event.role === "user") this.userMessageIds.add(event.messageId);
				return [];
			}
			case "message.part.delta": {
				if (this.parentedParts.has(event.partId)) return [];
				if (this.userMessageIds.has(event.messageId)) return [];
				const { delta } = event;
				if (delta.type === "tool_input") return []; // covered by part snapshots
				this.sentByPart.set(
					event.partId,
					(this.sentByPart.get(event.partId) ?? 0) + delta.text.length,
				);
				return [
					chunk(
						delta.type === "text" ? "agent_message_chunk" : "agent_thought_chunk",
						delta.text,
						event.messageId,
					),
				];
			}
			case "message.part": {
				const part = event.part;
				if (part.parentToolCallId) {
					this.parentedParts.add(part.id);
					return [];
				}
				if (this.userMessageIds.has(event.messageId)) return [];
				if (part.type === "tool") return this.toolUpdate(part);
				// Image/file parts have no v1 chunk slot (agent-side); dropped.
				if (part.type !== "text" && part.type !== "reasoning") return [];
				// While a part is still streaming, its snapshots mirror the deltas
				// (adapters mutate in place, so an early snapshot can already carry
				// delta text — emitting both doubles it). Only the final `done`
				// snapshot may contribute an unseen suffix, which is also how fully
				// non-streamed parts (no deltas at all) get emitted exactly once.
				if (part.state !== "done") return [];
				const sent = this.sentByPart.get(part.id) ?? 0;
				if (part.text.length <= sent) return [];
				this.sentByPart.set(part.id, part.text.length);
				return [
					chunk(
						part.type === "text" ? "agent_message_chunk" : "agent_thought_chunk",
						part.text.slice(sent),
						event.messageId,
					),
				];
			}
			case "session.usage":
				if (event.size === undefined) return [];
				return [
					{
						sessionUpdate: "usage_update",
						used: event.used,
						size: event.size,
						...(event.cost !== undefined && {
							cost: { amount: event.cost, currency: "USD" },
						}),
					},
				];
			default:
				return [];
		}
	}

	private toolUpdate(part: ToolPart): SessionUpdate[] {
		// Statuses and ToolKind are the SDK's own vocabulary (DESIGN D2), with
		// two edge maps: `cancelled` (ACP v2 / schema 1.6+) predates our pinned
		// SDK's ToolCallStatus and maps to `failed`; our open kind narrows via a
		// membership check — `task` and extensions fall back to `other`.
		const status = (part.state.status === "cancelled" ? "failed" : part.state.status) as Exclude<
			typeof part.state.status,
			"cancelled"
		>;
		const acpKinds = new Set([
			"read",
			"edit",
			"delete",
			"move",
			"search",
			"execute",
			"think",
			"fetch",
			"switch_mode",
			"other",
		]);
		const kind = part.kind
			? ((acpKinds.has(part.kind) ? part.kind : "other") as "other")
			: undefined;
		if (!this.openedTools.has(part.toolCallId)) {
			this.openedTools.add(part.toolCallId);
			return [
				{
					sessionUpdate: "tool_call",
					toolCallId: part.toolCallId,
					title: part.title ?? part.toolName,
					name: part.toolName,
					...(kind && { kind }),
					status,
					...(part.locations?.length && { locations: part.locations }),
					...("input" in part.state && { rawInput: part.state.input }),
				},
			];
		}
		const output =
			part.state.status === "failed"
				? part.state.error
				: part.state.status === "completed"
					? part.state.output
					: undefined;
		return [
			{
				sessionUpdate: "tool_call_update",
				toolCallId: part.toolCallId,
				status,
				...(output && {
					content: [{ type: "content", content: { type: "text", text: output } }],
				}),
			},
		];
	}
}

function chunk(
	kind: "agent_message_chunk" | "agent_thought_chunk",
	text: string,
	messageId: string,
): SessionUpdate {
	return { sessionUpdate: kind, content: { type: "text", text }, messageId };
}

/** ACP prompt content → engine input (text + base64 images; the rest is dropped). */
export function fromPromptBlocks(prompt: ContentBlock[]): string | PartInput[] {
	const parts: PartInput[] = [];
	for (const block of prompt) {
		if (block.type === "text" && block.text) parts.push({ type: "text", text: block.text });
		else if (block.type === "image" && block.data) {
			parts.push({ type: "image", data: block.data, mimeType: block.mimeType });
		}
	}
	if (parts.length === 1 && parts[0]?.type === "text") return parts[0].text;
	return parts.length ? parts : "";
}

/** ACP `McpServer[]` → engine MCP config map (inverse of the harness-side mapping). */
export function fromAcpMcpServers(
	servers: McpServer[] | undefined,
): Record<string, McpServerConfig> | undefined {
	if (!servers?.length) return undefined;
	const out: Record<string, McpServerConfig> = {};
	// Note: the SDK's `type: "acp"` nested-agent variant is silently dropped.
	for (const server of servers) {
		if ("command" in server) {
			out[server.name] = {
				type: "stdio",
				command: server.command,
				args: server.args,
				env: Object.fromEntries((server.env ?? []).map((e) => [e.name, e.value])),
			};
		} else if ("url" in server && (server.type === "http" || server.type === "sse")) {
			out[server.name] = {
				type: server.type,
				url: server.url,
				headers: Object.fromEntries((server.headers ?? []).map((h) => [h.name, h.value])),
			};
		}
	}
	return Object.keys(out).length ? out : undefined;
}
