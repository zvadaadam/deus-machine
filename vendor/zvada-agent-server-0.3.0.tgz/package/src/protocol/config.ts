import { z } from "zod";
import { AgentHarnessSchema } from "./harness.ts";
import { AgentInputSchema } from "./part-input.ts";
import { ThinkingLevelSchema } from "./thinking.ts";

/**
 * Permission posture for a turn. `bypass_permissions` auto-approves every
 * tool (the right default inside a sandbox); `plan` is read-only planning;
 * `dont_ask` never prompts — unapproved tools are denied, sandboxes stay at
 * their normal (non-dangerous) level. Values follow the casing law (snake);
 * adapters map to provider vocabulary at the edge (Claude SDK: acceptEdits,
 * bypassPermissions).
 */
export const PermissionModeSchema = z.enum([
	"default",
	"plan",
	"accept_edits",
	"dont_ask",
	"bypass_permissions",
]);
export type PermissionMode = z.infer<typeof PermissionModeSchema>;

/** Minimal external MCP server descriptor (stdio or http/sse). */
export const McpServerConfigSchema = z.discriminatedUnion("type", [
	z.object({
		type: z.literal("stdio"),
		command: z.string(),
		args: z.array(z.string()).optional(),
		env: z.record(z.string(), z.string()).optional(),
	}),
	z.object({
		type: z.literal("http"),
		url: z.string(),
		headers: z.record(z.string(), z.string()).optional(),
	}),
	z.object({
		type: z.literal("sse"),
		url: z.string(),
		headers: z.record(z.string(), z.string()).optional(),
	}),
]);
export type McpServerConfig = z.infer<typeof McpServerConfigSchema>;

/** Everything needed to configure a turn against a harness. */
export const RunConfigSchema = z.object({
	harness: AgentHarnessSchema,
	/** Free-form model id/alias; omit to use the harness default. */
	model: z.string().optional(),
	thinkingLevel: ThinkingLevelSchema.optional(),
	/** Working directory the agent operates in. */
	cwd: z.string(),
	/**
	 * Extra directories the agent may access beyond `cwd`. Mapped by the
	 * claude-code and codex-sdk harnesses; codex-app-server and acp have no
	 * native equivalent today and ignore it.
	 */
	additionalDirectories: z.array(z.string()).optional(),
	systemPromptAppend: z.string().optional(),
	maxTurns: z.number().int().positive().optional(),
	permissionMode: PermissionModeSchema.optional(),
	/**
	 * Native session/thread id to resume (from a prior `session.created`). When
	 * set, the harness continues that conversation instead of starting fresh.
	 */
	resumeSessionId: z.string().optional(),
	/**
	 * Resume from a specific historical message within the resumed session
	 * (branch/retry flows). Claude-only today; other harnesses ignore it.
	 */
	resumeSessionAt: z.string().optional(),
	mcpServers: z.record(z.string(), McpServerConfigSchema).optional(),
	/** Extra env vars layered onto the agent subprocess. */
	env: z.record(z.string(), z.string()).optional(),
	/** Per-turn API key override (BYOK). Falls back to ambient/proxy auth. */
	apiKey: z.string().optional(),
	/**
	 * Disable all built-in tools for this turn (text-only). Honored by harnesses
	 * that support it (Claude); Codex achieves the same via a read-only sandbox.
	 */
	disableTools: z.boolean().optional(),
	/**
	 * Interleave `raw` passthrough events (the harness's unparsed events) with
	 * the normalized stream. Migration/debug escape hatch — see `RawEvent`.
	 */
	includeRaw: z.boolean().optional(),
});
export type RunConfig = z.infer<typeof RunConfigSchema>;

/**
 * A single request to run one turn.
 *  - `sessionId` is OUR stable logical id (the session-manager key). It is the
 *    same across every turn of a conversation.
 *  - the harness-native id (for resume) is discovered at runtime and surfaced
 *    via the `session.created` lifecycle event.
 */
export const RunRequestSchema = z.object({
	sessionId: z.string(),
	turnId: z.string(),
	input: AgentInputSchema,
	config: RunConfigSchema,
});
export type RunRequest = z.infer<typeof RunRequestSchema>;
