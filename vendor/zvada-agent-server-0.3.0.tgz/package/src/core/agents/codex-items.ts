import type { ToolMeta } from "../../protocol/index.ts";
import { CODEX_TOOL_KINDS, codexFileChangeLocations } from "./tool-meta.ts";

/**
 * The codex tool-item vocabulary, shared by the Codex SDK adapter
 * (snake_case fields) and the app-server adapter (camelCase fields, with
 * snake_case fallbacks for older payloads). Descriptors are pure: adapters
 * keep their own streaming mechanics and call these for naming, input/meta
 * shaping, and completion-result extraction.
 */
export interface CodexToolItem {
	id: string;
	command?: string | string[];
	aggregatedOutput?: string;
	aggregated_output?: string;
	exitCode?: number;
	exit_code?: number;
	status?: string;
	changes?: Array<{ path: string; kind: string }>;
	server?: string;
	tool?: string;
	arguments?: unknown;
	result?: unknown;
	error?: { message?: string } | string;
	query?: string;
}

export interface CodexToolDescriptor {
	toolName(item: CodexToolItem): string;
	input(item: CodexToolItem): Record<string, unknown>;
	meta(item: CodexToolItem): ToolMeta;
	result(item: CodexToolItem): { output: string; isError: boolean };
}

export function pickCodexError(err: CodexToolItem["error"]): string {
	if (!err) return "";
	return typeof err === "string" ? err : (err.message ?? "");
}

/** Join `{text}` blocks of an MCP content array; JSON-stringify anything else. */
function stringifyMcpResult(result: unknown): string {
	const content =
		result && typeof result === "object" && "content" in result
			? (result as { content?: unknown }).content
			: result;
	if (content == null) return "";
	if (typeof content === "string") return content;
	if (Array.isArray(content)) {
		return content
			.map((b) =>
				b && typeof b === "object" && "text" in b
					? String((b as { text: unknown }).text)
					: JSON.stringify(b),
			)
			.join("");
	}
	return JSON.stringify(content);
}

const failed = (item: CodexToolItem) => item.status === "failed";

export const CODEX_TOOL_ITEMS: Record<string, CodexToolDescriptor> = {
	commandExecution: {
		toolName: () => "shell",
		input: (item) => ({ command: item.command ?? "" }),
		meta: () => ({ kind: CODEX_TOOL_KINDS.shell }),
		result: (item) => ({
			output: item.aggregatedOutput ?? item.aggregated_output ?? "",
			isError: failed(item) || (item.exitCode ?? item.exit_code ?? 0) !== 0,
		}),
	},
	fileChange: {
		toolName: () => "apply_patch",
		input: (item) => ({ changes: item.changes ?? [] }),
		meta: (item) => ({
			kind: CODEX_TOOL_KINDS.apply_patch,
			locations: codexFileChangeLocations(item.changes),
		}),
		result: (item) => ({
			output: (item.changes ?? []).map((c) => `${c.kind} ${c.path}`).join("\n"),
			isError: failed(item),
		}),
	},
	mcpToolCall: {
		toolName: (item) => `${item.server ?? "mcp"}.${item.tool ?? "tool"}`,
		input: (item) => ({ arguments: item.arguments }),
		meta: () => ({ kind: CODEX_TOOL_KINDS.mcp }),
		result: (item) => {
			const err = pickCodexError(item.error);
			return {
				output: err || stringifyMcpResult(item.result),
				isError: failed(item) || Boolean(err),
			};
		},
	},
	webSearch: {
		toolName: () => "web_search",
		input: (item) => ({ query: item.query ?? "" }),
		meta: () => ({ kind: CODEX_TOOL_KINDS.web_search }),
		result: (item) => ({ output: item.query ?? "", isError: failed(item) }),
	},
};

/** Map either protocol's item-type spelling onto a descriptor. */
export function codexToolDescriptor(itemType: string): CodexToolDescriptor | undefined {
	switch (itemType) {
		case "command_execution":
		case "commandExecution":
			return CODEX_TOOL_ITEMS.commandExecution;
		case "file_change":
		case "fileChange":
			return CODEX_TOOL_ITEMS.fileChange;
		case "mcp_tool_call":
		case "mcpToolCall":
			return CODEX_TOOL_ITEMS.mcpToolCall;
		case "web_search":
		case "webSearch":
			return CODEX_TOOL_ITEMS.webSearch;
		default:
			return undefined;
	}
}
