import {
	DEFAULT_TOKEN_USAGE,
	type Part,
	type ReasoningPart,
	type StopReason,
	type StreamContext,
	type TextPart,
	type TokenUsage,
	type ToolPart,
	completeToolPart,
	createReasoningPart,
	createTextPart,
	createToolPart,
} from "../../../protocol/index.ts";
import {
	type CodexToolDescriptor,
	type CodexToolItem,
	codexToolDescriptor,
} from "../codex-items.ts";
import type { AdapterEvent, EventTransformer, TransformResult } from "../types.ts";

/**
 * Parses `codex app-server` v2 notifications into AdapterEvents. This harness
 * streams token-level deltas (item/agentMessage/delta, item/reasoning/*Delta),
 * so unlike the Codex SDK adapter no diffing is needed. Items carry camelCase
 * fields. Tool-like items (commandExecution/fileChange/mcpToolCall/webSearch)
 * become tool parts that complete on item/completed.
 */

/** One app-server item: the shared codex tool vocabulary plus streaming fields. */
interface CodexItem extends CodexToolItem {
	type: string;
	text?: string;
}
interface Notification {
	method: string;
	params: {
		item?: CodexItem;
		itemId?: string;
		delta?: string;
		tokenUsage?: {
			total?: Record<string, number>;
			last?: Record<string, number>;
			modelContextWindow?: number;
		};
		turn?: { error?: { message?: string } | null };
		error?: { message?: string; additionalDetails?: string | null };
		willRetry?: boolean;
		message?: string;
	};
}

export class CodexAppServerTransformer implements EventTransformer<unknown> {
	private readonly ctx: StreamContext;
	private readonly partByItem = new Map<string, Part>();

	private usage: TokenUsage = { ...DEFAULT_TOKEN_USAGE };
	private stopReason?: StopReason;
	private finishReason?: string;
	private error?: string;

	constructor(ctx: { sessionId: string }) {
		this.ctx = { sessionId: ctx.sessionId, messageId: "" };
	}

	process(raw: unknown): AdapterEvent[] {
		const { method, params } = raw as Notification;
		switch (method) {
			case "item/started":
				return params.item ? this.openItem(params.item) : [];
			case "item/completed":
				return params.item ? this.completeItem(params.item) : [];
			case "item/agentMessage/delta":
				return this.textDelta(params.itemId, params.delta, "text");
			case "item/reasoning/textDelta":
			case "item/reasoning/summaryTextDelta":
				return this.textDelta(params.itemId, params.delta, "reasoning");
			case "thread/tokenUsage/updated": {
				this.captureUsage(params.tokenUsage?.total);
				const total = params.tokenUsage?.total;
				if (!total) return [];
				const used =
					total.totalTokens ??
					(total.inputTokens ?? 0) + (total.cachedInputTokens ?? 0) + (total.outputTokens ?? 0);
				const size = params.tokenUsage?.modelContextWindow;
				return [{ kind: "usage", used, ...(size !== undefined && { size }) }];
			}
			case "turn/completed":
				// (A pre-completion non-retry `error` cannot reach here in practice:
				// the agent's queue ends the turn on that notification.)
				if (params.turn?.error) this.error = params.turn.error.message ?? "codex turn error";
				this.finishReason = this.error ? "error" : "completed";
				if (!this.error) this.stopReason = "end_turn";
				return [];
			case "error":
				// v2 errors carry a nested TurnError and may be transient. A retrying
				// notification is diagnostic only; turn/completed remains authoritative.
				if (params.willRetry) return [];
				this.error = params.error?.message ?? params.message ?? "codex app-server error";
				this.finishReason = "error";
				return [];
			default:
				return [];
		}
	}

	finish(): TransformResult {
		return {
			usage: this.usage,
			stopReason: this.stopReason,
			finishReason: this.finishReason,
			error: this.error,
		};
	}

	private openItem(item: CodexItem): AdapterEvent[] {
		switch (item.type) {
			case "agentMessage": {
				const part = createTextPart(this.ctx, item.text ?? "", true);
				this.partByItem.set(item.id, part);
				return [{ kind: "part-open", part }];
			}
			case "reasoning": {
				const part = createReasoningPart(this.ctx, item.text ?? "", true);
				this.partByItem.set(item.id, part);
				return [{ kind: "part-open", part }];
			}
			default: {
				// commandExecution / fileChange / mcpToolCall / webSearch share one
				// descriptor vocabulary; userMessage and unknown item types produce
				// no assistant output.
				const d = codexToolDescriptor(item.type);
				return d ? this.openTool(item, d) : [];
			}
		}
	}

	private completeItem(item: CodexItem): AdapterEvent[] {
		const part = this.partByItem.get(item.id);
		switch (item.type) {
			case "agentMessage":
			case "reasoning": {
				const p = (part ??
					(item.type === "agentMessage"
						? createTextPart(this.ctx, item.text ?? "", true)
						: createReasoningPart(this.ctx, item.text ?? "", true))) as TextPart | ReasoningPart;
				// Reasoning items complete with text:"" while their thought content
				// streamed via item/reasoning/summaryTextDelta — an empty completed
				// text must not clobber the accumulated delta text (consumers persist
				// the terminal snapshot).
				if (item.text) p.text = item.text;
				p.state = "done";
				if (!part) this.partByItem.set(item.id, p);
				return [{ kind: "part-update", part: p }];
			}
			default: {
				const d = codexToolDescriptor(item.type);
				if (!d) return [];
				const tool = this.ensureTool(item, d);
				completeToolPart(tool, d.result(item));
				return [{ kind: "part-update", part: tool }];
			}
		}
	}

	private textDelta(
		itemId: string | undefined,
		delta: string | undefined,
		kind: "text" | "reasoning",
	): AdapterEvent[] {
		if (!itemId || !delta) return [];
		const events: AdapterEvent[] = [];
		let part = this.partByItem.get(itemId) as TextPart | ReasoningPart | undefined;
		if (!part) {
			part =
				kind === "text"
					? createTextPart(this.ctx, "", true)
					: createReasoningPart(this.ctx, "", true);
			this.partByItem.set(itemId, part);
			events.push({ kind: "part-open", part });
		}
		part.text += delta;
		events.push(
			kind === "text"
				? { kind: "text-delta", partId: part.id, text: delta }
				: { kind: "reasoning-delta", partId: part.id, text: delta },
		);
		return events;
	}

	private openTool(item: CodexItem, d: CodexToolDescriptor): AdapterEvent[] {
		const part = createToolPart(this.ctx, item.id, d.toolName(item), d.input(item), d.meta(item));
		this.partByItem.set(item.id, part);
		return [{ kind: "part-open", part }];
	}

	private ensureTool(item: CodexItem, d: CodexToolDescriptor): ToolPart {
		const existing = this.partByItem.get(item.id) as ToolPart | undefined;
		if (existing) return existing;
		const part = createToolPart(this.ctx, item.id, d.toolName(item), d.input(item), d.meta(item));
		this.partByItem.set(item.id, part);
		return part;
	}

	private captureUsage(total: Record<string, number> | undefined): void {
		if (!total) return;
		this.usage = {
			input: total.inputTokens ?? 0,
			output: total.outputTokens ?? 0,
			reasoning: total.reasoningOutputTokens ?? total.reasoningTokens ?? 0,
			cache: { read: total.cachedInputTokens ?? 0, write: 0 },
		};
	}
}

export function createCodexAppServerTransformer(ctx: { sessionId: string }): EventTransformer {
	return new CodexAppServerTransformer(ctx);
}
