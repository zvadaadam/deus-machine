/**
 * Single-consumer async channel. Producers `push()` values and then `end()`
 * (graceful) or `fail(error)` (consumers reject once buffered values drain);
 * a single consumer iterates with `for await`. `push` after end/fail is a
 * no-op; `return()` lets a consumer `break` out and end the stream. Shared by
 * core (prompt feeding, per-turn event buffering) and client (turn streams).
 */
export class AsyncQueue<T> implements AsyncIterableIterator<T> {
	private queue: T[] = [];
	private waiting: Array<{
		resolve: (r: IteratorResult<T>) => void;
		reject: (e: unknown) => void;
	}> = [];
	private done = false;
	private failure: unknown;

	push(value: T): void {
		if (this.done) return;
		const w = this.waiting.shift();
		if (w) w.resolve({ value, done: false });
		else this.queue.push(value);
	}

	end(): void {
		if (this.done) return;
		this.done = true;
		for (const w of this.waiting) w.resolve({ value: undefined as never, done: true });
		this.waiting = [];
	}

	fail(error: unknown): void {
		if (this.done) return;
		this.done = true;
		this.failure = error;
		for (const w of this.waiting) w.reject(error);
		this.waiting = [];
	}

	get size(): number {
		return this.queue.length;
	}

	next(): Promise<IteratorResult<T>> {
		// Check length, not the shifted value: a queued `undefined`/falsy item is
		// a real value and must not be mistaken for an empty queue.
		if (this.queue.length > 0) {
			return Promise.resolve({ value: this.queue.shift() as T, done: false });
		}
		if (this.done) {
			return this.failure !== undefined
				? Promise.reject(this.failure)
				: Promise.resolve({ value: undefined as never, done: true });
		}
		return new Promise((resolve, reject) => this.waiting.push({ resolve, reject }));
	}

	return(): Promise<IteratorResult<T>> {
		// IteratorClose is terminal: a consumer that breaks has discarded every
		// buffered value, even when return() is called directly.
		this.queue = [];
		this.end();
		return Promise.resolve({ value: undefined as never, done: true });
	}

	[Symbol.asyncIterator](): AsyncIterableIterator<T> {
		return this;
	}
}
