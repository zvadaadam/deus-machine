// @zvada/agent-server — the root export is the wire contract (zod-only, safe
// in any runtime). The seats live behind subpaths: ./core embeds the engine,
// ./server serves the wire, ./client talks to one.
export * from "./protocol/index.ts";
