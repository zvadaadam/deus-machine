# Changelog

## 0.3.0

**Breaking.** `WIRE_PROTOCOL_VERSION` 1 → 2. The protocol batch that folds the
nine-harness survey into one canonical layer: one spelling per concept, ACP's
vocabulary wherever the concepts overlap, `_meta` everywhere, unknowns
preserved instead of dropped, and a casing test that fails the build on drift.
There is no compatibility shim — decode the rename table below.

Also in this batch:

- `verifyStreamContract` (exported from the package root): machine-checkable
  stream-contract verification — ordering rules plus projection agreement
  (the reducer's final state must match the authoritative snapshots). The
  CLI grows `run --verify` (exit 1 on violation); every live harness/wire
  test is contract-checked.
- Honest cancels in the pre-first-yield window: a `turn/cancel` that lands
  between the `turn/start` quick-ack and the harness registering its
  abortable turn now answers `{outcome: "unconfirmed"}` (the abort landed on
  nothing and the turn may run to completion) instead of a clean `cancelled`.
- `session/close` broadcasts `session.ended {reason: "released"}` on the
  stream (consuming one seq) — subscribers learn the terminal fact from the
  stream itself, not from the closer's RPC result.

### The rename table (old → new)

- `parentToolUseId` → `parentToolCallId` (on parts and `message.started`;
  REMOVED entirely from `message.part` / `message.part.delta` events — the
  part carries it)
- Delta types: `"text-delta"` → `"text"`, `"reasoning-delta"` → `"reasoning"`,
  `"tool-input-delta"` → `"tool_input"`
- Event `"session.compacted"` → `"session.compaction"` (now an upsert entity:
  REQUIRED new fields `compactionId: string`,
  `status: "in_progress"|"completed"|"failed"|"cancelled"`; optional `summary`,
  `abstractsIds`)
- `error` event: `{error: string, code?: string}` →
  `{category: ErrorCategory, message: string}` (`recoverable`/`stack`
  unchanged)
- `turn.ended.error`: `{name, message}` → `{category, message}`
- `PermissionMode` values: `"acceptEdits"` → `"accept_edits"`, `"dontAsk"` →
  `"dont_ask"`, `"bypassPermissions"` → `"bypass_permissions"` (engine-side
  values; SDK-facing values in adapters stay camelCase — the adapters map)
- `PartInput`/parts: `mediaType` → `mimeType`
- `TurnCancelResult`: `{cancelled: boolean, confirmed?, activeTurnId?}` →
  discriminated union `{outcome:"cancelled",turnId}` |
  `{outcome:"unconfirmed",turnId}` | `{outcome:"no_active_turn",activeTurnId?}`
- `ToolState`: new fifth status `"cancelled"` `{status,input,time{start,end}}`;
  `completed.title` now OPTIONAL (no more default-to-`toolName`); `completed`
  gains optional `content?: ToolResultContent[]` and `metadata?`
- `TOOL_STATUSES` → **`RUNTIME_TOOL_STATUSES`**, `ToolStatus` →
  **`RuntimeToolStatus`** (`ToolStatusSchema` → `RuntimeToolStatusSchema`).
  The rename marks a deliberate deviation from §2, which lists `ToolStatus`
  among the OPEN vocabularies: this union is **closed**. The status is a
  STRUCTURAL discriminator here — each status carries its own payload
  (`pending.partialInput`, `in_progress.time{start}`, `completed.output`,
  `failed.error`, `cancelled.time{start,end}`) — so an unknown status has no
  decodable body and would only ever be a shape nothing can render. New
  statuses are protocol additions (a new arm), not producer extensions; the
  `Runtime` prefix says which set you are importing. Raised against the spec
  rather than silently diverging — if §2 wins, the fix is an
  `UnknownToolState {status, input?, _meta?}` arm, not a re-opened union.
- `classifyError` fallback category renamed `"unknown"` → `"internal"`
- ALL `message.*` events now carry `sessionId`; `message.started` gained
  `model?`, lost its `metadata` bag
- Every event / part / tool state has optional `_meta`
- Reducer: `ConversationState.messages`/`compactions` replaced by a unified
  `timeline: Array<ConversationMessage|ConversationCompaction>`
  (kind-discriminated: `kind:"message"`/`"compaction"`); helper
  `conversationMessages(state)`; new state fields `ended?`, `unknownEvents`;
  `reduceConversation` also accepts an `UnknownEvent` and preserves it

### New

- **The user echo (§7.2).** Every turn now opens with the submitted input
  echoed back as a complete user message —
  `message.started{role:"user", outputIndex:0}` → one `message.part` per input
  part → `message.ended` — before any harness output. Assistant messages now
  start at `outputIndex: 1`. The stream is a complete transcript: multi-client
  attach, replay, and persistence no longer need the client's own copy of the
  prompt. Reconciliation is by `turnId`; the engine mints the `messageId`.
- **`session.ended {reason}`** — `idle` | `replaced` | `released` |
  `shutdown` (OPEN). `ConversationState.ended` records it.
- **`session.compaction` as a positional, ID-addressed entity.** First
  appearance anchors its place in the timeline; later upserts advance
  `status`/`summary` in place without moving or restamping it. A failed
  compaction is representable instead of a stream that goes quiet.
- **Structured tool output (three audiences).** `output` (string) stays the
  model-facing record and rendering fallback; `content?: ToolResultContent[]`
  (`text` | `image` | `diff` | `terminal`) is the display-grade view;
  `metadata?` is the machine channel. The claude-code adapter now populates
  `content` for text and image result blocks instead of only flattening.
- **Subagent metadata.** `Task`-style spawns populate
  `subagent {type, description, model, agentId?}` from the tool's input, and
  `kind: "task"` is derived from its PRESENCE — no more tool-name allowlists.
- **`reasoning.time` and `providerMetadata` are real.** The claude-code adapter
  stamps `time.start`/`time.end` across a thinking block and marks
  `redacted_thinking` with `providerMetadata: {redacted: true}` instead of
  collapsing it into plain reasoning.
- **Unknown preservation (Law 6).** `decodeLifecycleEvent` keeps an unknown
  event type in order as `{type, raw}` rather than dropping it; the reducer
  collects them in `state.unknownEvents`. Known types with malformed bodies
  still fail loudly.
- **Cancellation closure.** At `turn.ended{stopReason:"cancelled"}` the reducer
  transitions the turn's non-terminal tool parts to `status:"cancelled"` — a
  cancelled turn can no longer strand tools as `in_progress` forever.
- **One casing test (Law 9).** `test/protocol/casing.test.ts` walks every enum,
  discriminator and field name in the vocabulary and fails on a Law-2
  violation. The two documented kebab exceptions (`AGENT_HARNESSES`,
  `ModelSwitchMode`) are excluded explicitly.
- **Permissions actually offer what the schema advertises (§6.4).** The broker
  now offers all four option kinds (`allow_once`, `allow_always`,
  `reject_once`, `reject_always`), and an `*_always` answer becomes a standing
  per-session rule: later calls to that tool are answered without a round-trip
  and without synthesizing a prompt event that never happened. Rules are
  cleared by `session/close`.
- **`permission.resolved.outcome.updatedInput` is honoured.** An edited input
  travels `PermissionDecision {decision:"allow", updatedInput?}` into the
  claude-code harness's `canUseTool` return, so what was approved is what runs.
  Codex and ACP have no slot for it in their approval replies — documented at
  both call sites rather than silently dropped.
- **Law 6 on the paths that carry traffic.** `decodeLifecycleEvent` is now what
  the wire client uses: an unknown event type is DELIVERED (advancing `seq`,
  so it can never be mistaken for a gap) as `UnknownEvent`, and `events/replay`
  decodes envelope-by-envelope so one unknown event cannot poison the buffer
  that heals a gap. New `decodePart` gives `message.part` a lenient part
  decoder — an unknown part type is preserved as
  `UnknownPart {type, id, sessionId, messageId, parentToolCallId?, raw}` in its
  message instead of failing the event. **Breaking for consumers**:
  `TurnHandle.events`, `onEvent` and `client.replay()` are typed
  `DecodedLifecycleEvent | UnknownEvent` — narrow with `isUnknownEvent` /
  `isUnknownPart` (`reduceConversation` already accepts the union).
- **Law 5 is enforced, not just documented.** One `EpochMsSchema`
  (integer, non-negative, rejects `-0`) types every event `timestamp` and every
  nested `time.start`/`time.end` on tool states and reasoning parts. A
  seconds-based or fractional stamp is now a parse error instead of a value
  that sorts wrong in production.
- Open vocabularies reject blank values (`""`, `"   "`) while still accepting
  unknown ones — one `openVocabulary()` helper instead of six casts. New
  `COMPACTION_TRIGGERS` (`auto` | `manual`, OPEN) types
  `session.compaction.trigger`, and `ConversationState.harness` is the closed
  `AgentHarness` again instead of a widened `string`.
- Image and file parts now ENFORCE §4's "exactly one of `data` | `url`" on the
  output side, as the input side already did.
- Cancellation closure preserves a pending tool's streamed JSON under
  `_meta["agent-server/partialInput"]` (`PARTIAL_INPUT_META_KEY`) instead of
  dropping what the call was about; `emptyConversation().totals` now uses the
  same zero shape as `DEFAULT_TOKEN_USAGE`.
- `verifyStreamContract` fixes two false positives that failed LEGAL streams:
  a cancelled turn's trailing deltas (a snapshot is a prefix of the fold, not
  a ceiling) and multi-turn sessions (`session.created` is per turn, since the
  engine re-announces it on every turn's first yield). Its vacuous
  "refold the same stream" determinism check is replaced by a real re-delivery
  probe: every upsert-shaped event delivered twice must leave the timeline,
  per-message part counts, resolved permissions and billing totals unchanged.
- The CLI renderer now folds the stream with `reduceConversation` instead of
  hand-rolling two switch statements over the event union — the reference
  implementation is dogfooded, as `docs/consuming.md` tells consumers to do.
- Deliberately absent under Law 7 (advertise nothing you don't deliver): §8's
  `InitializeResult.experimental` (no experimental capability to gate yet) and
  §12's `docs/rfds/` (no RFD process while the protocol has one implementation).

## 0.2.3

- **`reduceConversation`** (root / `./protocol`): the canonical
  LifecycleEvent → conversation-state reducer. Pure, copy-on-write fold that
  encodes the stream's consumption rules — part upsert by `part.id`
  (including late tool completions landing in their original message),
  authoritative snapshots over streamed deltas, exactly-once permission
  resolution, the gauge/billing-totals distinction. Ships with
  `emptyConversation()` and `pendingPermissions()`. Replaces the fold every
  consumer had been writing by hand.
- **`onSessionEnd`** (`ClaudeCodeAgentOptions`): fires exactly once when a
  live session's subprocess ends, with why — `idle` | `replaced` |
  `released` | `shutdown`. The seam for host-managed per-session resources
  (BYOK proxy keys, recorders).
- **`onDiagnostic`** (`CreateRegistryOptions`, `AgentRuntime` options,
  `createAnthropicProxy` options): operational signals the engine previously
  swallowed — `interruptTimeout`, `resumeFallback`, `sinkError`,
  `proxyUpstreamAuth`. Handler errors can never break a turn.

## 0.2.2

- **Idempotent turn admission.** `AgentRuntime.run` converges a duplicate
  `{sessionId, turnId}` with identical input onto the in-flight promise or
  the memoized summary (bounded per-session window, released by
  `session/close`) — a retried RPC can never double-execute a turn. Same ids
  with different input throw `TurnConflictError`. `runtime.admission()` is
  the pure probe; `turn/start` delegates (`deduplicated: true` acks, wire
  error `turnConflict`). Registration precedes execution start, so even a
  synchronous reentrant sink converges.
- **Confirmed, turn-stamped cancels.** `Agent.cancel` returns
  `{confirmed, hadTurn}`; `interruptTurn()` reports the SDK round-trip
  outcome instead of swallowing it; `turn/cancel` accepts a `turnId` stamp
  and refuses a stale one with `activeTurnId` instead of killing the
  successor turn. Claude aborts before interrupting, fixing a race where a
  clean cancel could surface as `error`.
- **Bun-proof BYOK proxy.** SSE bodies pipe through a fresh stream
  (downstream disconnects propagate upstream — no leaked sockets); non-SSE
  responses drop stale `content-encoding`/`content-length`/
  `transfer-encoding`; structured 502 on unreachable upstreams; injectable
  `fetch`. Media-type detection parses instead of substring-matching.
- Turn-end ordering hardened: `turn.ended` never starts before any
  `permission.resolved` emission completed, regardless of who settled it.
- Empty-string session/turn ids are rejected at the wire schema.
- `toolPolicy` receives the SDK's full `canUseTool` context (signal,
  suggestions, blockedPath, decisionReason).

## 0.2.1

- codex-app-server: an `item/completed` carrying `text: ""` no longer
  clobbers reasoning text accumulated from `summaryTextDelta`s — thoughts
  persist in the terminal snapshot consumers store.

## 0.2.0

- The four packages (`@zvada/agent-server-{protocol,core,server,client}`)
  consolidated into **one package** with subpath seats: root = the wire
  contract, `./core` (+ `./core/proxy`), `./server` (ships the
  `agent-server` bin), `./client`. The old four are deprecated on npm.
