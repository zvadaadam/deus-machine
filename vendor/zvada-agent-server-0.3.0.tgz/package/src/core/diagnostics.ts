/**
 * The engine's diagnostics port: operational signals the engine used to
 * swallow (best-effort paths that must not fail a turn) surfaced to the host
 * instead. Products log/metric these; the engine never does its own logging.
 * Handler errors are always swallowed — a diagnostics sink must never be able
 * to break a turn.
 */

/**
 * Known diagnostic kinds (open set — new kinds may appear in minor versions;
 * the `(string & {})` arm keeps the union open without losing autocomplete):
 *  - `interruptTimeout` — a cancel's SDK interrupt round-trip timed out
 *    (the turn was reported `confirmed: false`; the agent may still run).
 *  - `resumeFallback` — a requested resume failed and the turn re-ran on a
 *    fresh session (also visible as `session.created.resumed: false`).
 *  - `sinkError` — an EventSink emit threw; the event was dropped for that
 *    sink and the turn continued.
 *  - `proxyUpstreamAuth` — the BYOK proxy's upstream rejected the real key
 *    (401/403): the stored key is invalid/expired, not the placeholder.
 */
export type DiagnosticKind =
	| "interruptTimeout"
	| "resumeFallback"
	| "sinkError"
	| "proxyUpstreamAuth"
	| (string & {});

export interface EngineDiagnostic {
	type: DiagnosticKind;
	sessionId?: string;
	message: string;
	detail?: unknown;
	timestamp: number;
}

/**
 * Declared `=> void` so any callback shape is assignable (TS's void-return
 * exemption covers `() => diagnostics.push(d)` AND async handlers); a
 * returned promise is still detected at runtime and its rejection swallowed.
 */
export type DiagnosticHandler = (diagnostic: EngineDiagnostic) => void;

/** Invoke a handler without letting it break the calling path — sync throws
 * AND async rejections are swallowed (the diagnostics sink owns its own
 * reliability). Stamps the timestamp so call sites don't repeat it. */
export function emitDiagnostic(
	handler: DiagnosticHandler | undefined,
	diagnostic: Omit<EngineDiagnostic, "timestamp">,
): void {
	if (!handler) return;
	try {
		const result = handler({ ...diagnostic, timestamp: Date.now() }) as unknown;
		if (result instanceof Promise) {
			result.catch(() => {});
		}
	} catch {
		// see above
	}
}
