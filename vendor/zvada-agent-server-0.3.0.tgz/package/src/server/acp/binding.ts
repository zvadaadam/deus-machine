import { Readable, Writable } from "node:stream";
import type {
	AgentApp,
	AgentConnection,
	PromptResponse,
	RequestPermissionResponse,
} from "@agentclientprotocol/sdk";
import type { AgentRuntime, EventSink } from "../../core/index.ts";
import { generateUUIDv7 } from "../../core/index.ts";
import type {
	AgentHarness,
	LifecycleEvent,
	PermissionMode,
	PermissionOutcome,
} from "../../protocol/index.ts";
import { AcpUpdateTranslator, fromAcpMcpServers, fromPromptBlocks } from "./translate.ts";

/** ACP protocol major version this binding speaks. */
const PROTOCOL_VERSION = 1;

export interface AcpBindingOptions {
	runtime: AgentRuntime;
	/** The harness this ACP agent fronts (operator-chosen at launch). */
	harness: AgentHarness;
	model?: string;
	/** Defaults to `default` so tool approvals flow to the ACP client. */
	permissionMode?: PermissionMode;
	name?: string;
	version?: string;
}

interface BoundSession {
	cwd: string;
	mcpServers?: ReturnType<typeof fromAcpMcpServers>;
}

/**
 * The phase-3 ACP *server* binding: exposes the runtime as an Agent Client
 * Protocol v1 agent, so anything that speaks ACP (Zed, another agent-server's
 * `acp` harness, any product) can drive our harnesses with zero custom
 * integration. `session/prompt` runs one engine turn; LifecycleEvents stream
 * out as `session/update`; engine-brokered permissions become
 * `session/request_permission` round-trips (identical option vocabulary).
 * Resume is within-process: an ACP sessionId stays valid for the binding's
 * lifetime (cross-process resume needs host persistence — not offered yet).
 */
export async function createAcpAgentApp(options: AcpBindingOptions): Promise<AgentApp> {
	const acp = await import("@agentclientprotocol/sdk");
	const { runtime, harness } = options;
	const sessions = new Map<string, BoundSession>();

	const requireSession = (sessionId: string): BoundSession => {
		const session = sessions.get(sessionId);
		if (!session) throw acp.RequestError.resourceNotFound(sessionId);
		return session;
	};

	return acp
		.agent({ name: options.name ?? "agent-server" })
		.onRequest("initialize", (ctx) => ({
			protocolVersion: Math.min(ctx.params.protocolVersion, PROTOCOL_VERSION),
			agentInfo: { name: options.name ?? "agent-server", version: options.version ?? "0.0.0" },
			agentCapabilities: {
				promptCapabilities: { image: true },
				sessionCapabilities: { resume: {}, close: {} },
			},
			authMethods: [],
		}))
		.onRequest("session/new", (ctx) => {
			const sessionId = generateUUIDv7();
			sessions.set(sessionId, {
				cwd: ctx.params.cwd,
				mcpServers: fromAcpMcpServers(ctx.params.mcpServers),
			});
			return { sessionId };
		})
		.onRequest("session/resume", (ctx) => {
			const session = requireSession(ctx.params.sessionId);
			session.cwd = ctx.params.cwd;
			if (ctx.params.mcpServers) session.mcpServers = fromAcpMcpServers(ctx.params.mcpServers);
			return {};
		})
		.onRequest("session/close", async (ctx) => {
			requireSession(ctx.params.sessionId);
			await runtime.closeSession(harness, ctx.params.sessionId);
			sessions.delete(ctx.params.sessionId);
			return {};
		})
		.onNotification("session/cancel", (ctx) => {
			if (sessions.has(ctx.params.sessionId)) {
				void runtime.cancel(harness, ctx.params.sessionId);
			}
		})
		.onRequest("session/prompt", async (ctx) => {
			const session = requireSession(ctx.params.sessionId);
			const translator = new AcpUpdateTranslator();
			const sink: EventSink = {
				emit: async (event: LifecycleEvent) => {
					if (event.type === "permission.requested") {
						// Round-trip to the ACP client; its outcome shape matches ours.
						let outcome: PermissionOutcome = { outcome: "cancelled" };
						try {
							const response: RequestPermissionResponse = await ctx.client.request(
								"session/request_permission",
								{
									sessionId: ctx.params.sessionId,
									toolCall: {
										toolCallId: event.toolCall?.toolCallId ?? event.requestId,
										title: event.title,
										status: "pending",
										...(event.toolCall?.kind && { kind: event.toolCall.kind }),
										...(event.toolCall?.rawInput && { rawInput: event.toolCall.rawInput }),
									},
									options: event.options,
								},
							);
							outcome = response.outcome;
						} catch {
							// Client refused/disconnected — fall through to cancelled.
						}
						runtime.respondPermission(ctx.params.sessionId, event.requestId, outcome);
						return;
					}
					for (const update of translator.translate(event)) {
						void ctx.client.notify("session/update", {
							sessionId: ctx.params.sessionId,
							update,
						});
					}
				},
			};
			const summary = await runtime.run(
				{
					sessionId: ctx.params.sessionId,
					turnId: generateUUIDv7(),
					input: fromPromptBlocks(ctx.params.prompt),
					config: {
						harness,
						cwd: session.cwd,
						model: options.model,
						permissionMode: options.permissionMode ?? "default",
						mcpServers: session.mcpServers,
					},
				},
				sink,
			);
			// ACP v1's StopReason set is closed and has no `error` member. Map our
			// open stopReason onto it: `error` reports as an ended turn with the
			// failure in `_meta` (an ACP client must see a stop, not a JSON-RPC
			// failure), and extension/unknown values fall back to `end_turn`.
			const acpStopReasons = new Set([
				"end_turn",
				"max_tokens",
				"max_turn_requests",
				"refusal",
				"cancelled",
			]);
			if (summary.stopReason === "error") {
				return {
					stopReason: "end_turn",
					_meta: {
						"zvada.dev/error": summary.error ?? { category: "internal", message: "turn failed" },
					},
				} as PromptResponse;
			}
			return {
				stopReason: (acpStopReasons.has(summary.stopReason)
					? summary.stopReason
					: "end_turn") as PromptResponse["stopReason"],
			};
		});
}

/** Serve the binding on this process's stdio (what an ACP client spawns). */
export async function serveAcpStdio(options: AcpBindingOptions): Promise<AgentConnection> {
	const acp = await import("@agentclientprotocol/sdk");
	const app = await createAcpAgentApp(options);
	return app.connect(
		acp.ndJsonStream(
			Writable.toWeb(process.stdout),
			Readable.toWeb(process.stdin) as ReadableStream<Uint8Array>,
		),
	);
}
