import type { StopReason } from "./lifecycle.ts";

/**
 * The stop reasons that mean "the turn finished the way it was supposed to".
 * A subset of `STOP_REASONS` — everything except `error`.
 *
 * `cancelled` is CLEAN: the user asked for the turn to stop and it stopped.
 * Products that treat it as a failure paint an error banner over the user's
 * own action (all three copies of this set in the wild got this right, and
 * two of them then drifted on `refusal` and `max_turn_requests`).
 *
 * Zod-free and dependency-free on purpose: this is a membership test, and a
 * consumer branching on a stop reason should not have to load the schemas.
 */
export const CLEAN_STOP_REASONS = [
	"end_turn",
	"max_tokens",
	"max_turn_requests",
	"refusal",
	"cancelled",
] as const;

/**
 * True when the turn stopped for a reason this build knows to be clean.
 *
 * `StopReason` is an OPEN vocabulary (Law 3): a newer engine's value, or an
 * adapter's `_`-prefixed extension, reaches an older consumer unchanged. Such
 * a value is classified as NOT clean — the conservative direction. Showing a
 * failure affordance for an outcome we cannot interpret is recoverable (the
 * user retries); silently rendering an unknown outcome as success is not (the
 * turn looks complete, the work is gone, nothing points at the cause).
 */
export function isCleanStop(reason: StopReason | undefined): boolean {
	return (CLEAN_STOP_REASONS as readonly string[]).includes(reason as string);
}

/**
 * The complement of `isCleanStop`: `error`, plus every stop reason this build
 * does not know (see the conservative-classification note above). `undefined`
 * — a turn with no stop reason at all — is a failure too: a turn that ended
 * without saying why did not end well.
 */
export function isFailureStopReason(reason: StopReason | undefined): boolean {
	return !isCleanStop(reason);
}
