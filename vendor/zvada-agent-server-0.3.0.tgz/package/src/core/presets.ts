import { AGENT_HARNESSES, type AgentHarness } from "../protocol/index.ts";
import { AcpAgent, type AcpAgentOptions } from "./agents/acp/acp-agent.ts";
import { createAcpTransformer } from "./agents/acp/adapter.ts";
import { createClaudeCodeTransformer } from "./agents/claude-code/adapter.ts";
import { ClaudeCodeAgent, type ClaudeCodeAgentOptions } from "./agents/claude-code/claude-agent.ts";
import { createCodexAppServerTransformer } from "./agents/codex-app-server/adapter.ts";
import { CodexAppServerAgent } from "./agents/codex-app-server/codex-app-server-agent.ts";
import { createCodexSdkTransformer } from "./agents/codex-sdk/adapter.ts";
import { CodexSdkAgent } from "./agents/codex-sdk/codex-sdk-agent.ts";
import { AgentRegistry } from "./agents/registry.ts";
import type { DiagnosticHandler } from "./diagnostics.ts";
import { CliProvisioner, type ProvisionOptions } from "./provision/provisioner.ts";
import { AgentRuntime } from "./runtime/agent-runtime.ts";

export interface CreateRegistryOptions {
	/**
	 * Which harnesses to register. Defaults to the three native harnesses,
	 * plus `acp` when `acp` config is provided (it has no default launch).
	 */
	harnesses?: AgentHarness[];
	/**
	 * CLI provisioning policy — how the native `claude`/`codex` binaries are
	 * found or downloaded (see `CliProvisioner`). Defaults to `auto`.
	 */
	provision?: ProvisionOptions;
	/**
	 * ACP harness configuration. Required to enable `acp`: the harness needs an
	 * operator-supplied launch command for the target agent (never wire-driven).
	 */
	acp?: AcpAgentOptions;
	/**
	 * Claude harness embed-tier options (e.g. in-process `sdkMcpServers`).
	 * `resolveCliPath` stays provisioner-wired here.
	 */
	claudeCode?: Omit<ClaudeCodeAgentOptions, "resolveCliPath">;
	/**
	 * Operational diagnostics port (see `EngineDiagnostic`): interrupt
	 * timeouts, resume fallbacks, sink failures — signals the engine must not
	 * fail a turn over, surfaced for the host to log/metric. Applied to the
	 * runtime and every harness that emits them; a harness-level
	 * `claudeCode.onDiagnostic` overrides for that harness.
	 */
	onDiagnostic?: DiagnosticHandler;
}

/** Build a registry with the standard harnesses wired to their adapters. */
export function createAgentRegistry(opts: CreateRegistryOptions = {}): AgentRegistry {
	// Default: every harness that can run unconfigured — acp joins only when its
	// operator launch config is present (it has nothing to run otherwise).
	const enabled = new Set<AgentHarness>(
		opts.harnesses ?? AGENT_HARNESSES.filter((h) => h !== "acp" || Boolean(opts.acp)),
	);
	// One provisioner per registry: resolution is memoized per tool, so both
	// codex harnesses share a single download and every agent logs one source.
	const provisioner = new CliProvisioner(opts.provision);
	const claudeCli = () => provisioner.resolve("claude").then((cli) => cli?.path);
	const codexCli = () => provisioner.resolve("codex").then((cli) => cli?.path);

	const registry = new AgentRegistry();
	if (enabled.has("claude-code")) {
		registry.register(
			new ClaudeCodeAgent({
				onDiagnostic: opts.onDiagnostic,
				...opts.claudeCode,
				resolveCliPath: claudeCli,
			}),
			createClaudeCodeTransformer,
		);
	}
	if (enabled.has("codex-sdk")) {
		registry.register(new CodexSdkAgent({ resolveCliPath: codexCli }), createCodexSdkTransformer);
	}
	if (enabled.has("codex-app-server")) {
		registry.register(
			new CodexAppServerAgent({ resolveCliPath: codexCli }),
			createCodexAppServerTransformer,
		);
	}
	if (enabled.has("acp")) {
		if (!opts.acp) {
			throw new Error("the acp harness requires CreateRegistryOptions.acp (resolveLaunch)");
		}
		registry.register(new AcpAgent(opts.acp), createAcpTransformer);
	}
	return registry;
}

/** Convenience: a ready-to-use runtime with the standard harnesses. */
export function createAgentRuntime(opts: CreateRegistryOptions = {}): AgentRuntime {
	return new AgentRuntime(createAgentRegistry(opts), { onDiagnostic: opts.onDiagnostic });
}
