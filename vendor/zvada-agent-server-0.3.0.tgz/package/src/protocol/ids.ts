/**
 * UUIDv7 — time-ordered identifiers. The leading 48 bits are a millisecond
 * timestamp, so ids sort chronologically (handy for ordering parts/messages
 * without a separate createdAt column). Uses Web Crypto, available on both
 * Bun and Node >= 20 via `globalThis.crypto`.
 */
export function generateUUIDv7(): string {
	const timestamp = Date.now();

	const rand = new Uint8Array(10);
	crypto.getRandomValues(rand);

	const bytes = new Uint8Array(16);

	// 48-bit big-endian timestamp.
	bytes[0] = (timestamp / 2 ** 40) & 0xff;
	bytes[1] = (timestamp / 2 ** 32) & 0xff;
	bytes[2] = (timestamp / 2 ** 24) & 0xff;
	bytes[3] = (timestamp / 2 ** 16) & 0xff;
	bytes[4] = (timestamp / 2 ** 8) & 0xff;
	bytes[5] = timestamp & 0xff;

	// version (7) + 4 bits random
	bytes[6] = 0x70 | (rand[0]! & 0x0f);
	bytes[7] = rand[1]!;
	// variant (10xx) + 6 bits random
	bytes[8] = 0x80 | (rand[2]! & 0x3f);
	bytes[9] = rand[3]!;
	bytes[10] = rand[4]!;
	bytes[11] = rand[5]!;
	bytes[12] = rand[6]!;
	bytes[13] = rand[7]!;
	bytes[14] = rand[8]!;
	bytes[15] = rand[9]!;

	const hex: string[] = [];
	for (let i = 0; i < 16; i++) hex.push(bytes[i]!.toString(16).padStart(2, "0"));
	return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex
		.slice(6, 8)
		.join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10, 16).join("")}`;
}

/** Extract the embedded millisecond timestamp from a UUIDv7. */
export function timestampFromUUIDv7(id: string): number {
	const hex = id.replace(/-/g, "").slice(0, 12);
	return Number.parseInt(hex, 16);
}

/** Short, non-sortable id for ad-hoc correlation (e.g. JSON-RPC request ids). */
export function generateId(prefix?: string): string {
	const id = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
	return prefix ? `${prefix}_${id}` : id;
}
