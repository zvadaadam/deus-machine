import { createHash } from "node:crypto";
import { once } from "node:events";
import { createWriteStream } from "node:fs";
import { CliProvisionError } from "../utils/errors.ts";

export const DEFAULT_NPM_REGISTRY = "https://registry.npmjs.org";

/** The subset of npm packument `dist` we need to fetch a package verifiably. */
export interface NpmDist {
	tarball: string;
	/** Subresource integrity, e.g. `sha512-<base64>`. */
	integrity: string;
}

type FetchLike = (url: string, init?: RequestInit) => Promise<Response>;

/** One retry on network-level failures; 4xx/5xx are not retried. */
async function fetchOk(fetchImpl: FetchLike, url: string): Promise<Response> {
	let lastError: unknown;
	for (let attempt = 0; attempt < 2; attempt++) {
		try {
			const res = await fetchImpl(url);
			if (!res.ok) {
				throw new CliProvisionError(`GET ${url} failed: ${res.status} ${res.statusText}`);
			}
			return res;
		} catch (error) {
			if (error instanceof CliProvisionError) throw error;
			lastError = error;
		}
	}
	throw new CliProvisionError(`GET ${url} failed: ${String(lastError)}`, { cause: lastError });
}

/**
 * Fetch the registry metadata for one exact package version and return its
 * tarball location + integrity. The returned tarball URL is the registry's own
 * (works with mirrors/private registries that rewrite hosts).
 */
export async function fetchDist(
	registry: string,
	packageName: string,
	version: string,
	fetchImpl: FetchLike = fetch,
): Promise<NpmDist> {
	// Scoped names keep the literal `@` but escape the inner slash.
	const base = registry.replace(/\/+$/, "");
	const url = `${base}/${packageName.replace("/", "%2F")}/${version}`;
	const res = await fetchOk(fetchImpl, url);
	const body = (await res.json()) as { dist?: { tarball?: string; integrity?: string } };
	const { tarball, integrity } = body.dist ?? {};
	if (!tarball || !integrity) {
		throw new CliProvisionError(
			`Registry metadata for ${packageName}@${version} has no dist.tarball/integrity — is this version published for your platform?`,
		);
	}
	return { tarball, integrity };
}

/**
 * Stream a tarball to disk, hashing as it lands, and reject on integrity
 * mismatch. Only sha512 (what the npm registry publishes) is supported.
 * Returns the byte count for progress logs.
 */
export async function downloadWithIntegrity(
	url: string,
	destFile: string,
	integrity: string,
	fetchImpl: FetchLike = fetch,
): Promise<number> {
	const expected = /^sha512-([A-Za-z0-9+/=]+)$/.exec(integrity)?.[1];
	if (!expected) {
		throw new CliProvisionError(`Unsupported integrity format (want sha512-…): ${integrity}`);
	}
	const res = await fetchOk(fetchImpl, url);
	if (!res.body) throw new CliProvisionError(`GET ${url} returned no body`);

	const hash = createHash("sha512");
	const out = createWriteStream(destFile);
	// One persistent listener: an unobserved WriteStream 'error' would crash the
	// process, and per-chunk `once("error")` listeners would accumulate instead.
	let streamError: unknown;
	out.on("error", (error) => {
		streamError = error;
	});
	let bytes = 0;
	try {
		for await (const chunk of res.body as unknown as AsyncIterable<Uint8Array>) {
			if (streamError) throw streamError;
			hash.update(chunk);
			bytes += chunk.byteLength;
			// events.once rejects on 'error' and removes its listeners either way.
			if (!out.write(chunk)) await once(out, "drain");
		}
		if (streamError) throw streamError;
		// Reject on 'error' too: a failure during the terminal flush (e.g.
		// ENOSPC on the last buffered chunk) never fires the end callback, and
		// without this listener the await would hang instead of surfacing it.
		await new Promise<void>((resolve, reject) => {
			out.once("error", reject);
			out.end(() => (streamError ? reject(streamError as Error) : resolve()));
		});
	} catch (error) {
		out.destroy();
		throw error;
	}
	const actual = hash.digest("base64");
	if (actual !== expected) {
		throw new CliProvisionError(
			`Integrity mismatch for ${url}: expected sha512-${expected}, got sha512-${actual}`,
		);
	}
	return bytes;
}
