import { z } from "zod";

/**
 * Law 5 — every instant on this wire is epoch MILLISECONDS, as an integer.
 * One schema, used by every `timestamp` and every nested `time.start`/
 * `time.end`, so the boundary validation is real rather than prose: a bare
 * `z.number()` accepts `-5`, `1.5` and `-0`, all of which round-trip silently
 * and then sort, subtract and render wrong (a seconds-based stamp lands in
 * 1970; `-0` breaks `Object.is` keyed caches).
 */
export const EpochMsSchema = z
	.number()
	.int()
	.nonnegative()
	// -0 passes `>= 0`; it is not a legal instant, and it survives JSON as `0`
	// only by accident of the serializer.
	.refine((value) => !Object.is(value, -0), { message: "epoch-ms must not be -0" });
export type EpochMs = z.infer<typeof EpochMsSchema>;

/** A start/end span in epoch ms (tool executions, thinking blocks). */
export const TimeSpanSchema = z.object({ start: EpochMsSchema, end: EpochMsSchema });
/** A span whose end is unknown while the thing is still running. */
export const OpenTimeSpanSchema = z.object({ start: EpochMsSchema, end: EpochMsSchema.optional() });
