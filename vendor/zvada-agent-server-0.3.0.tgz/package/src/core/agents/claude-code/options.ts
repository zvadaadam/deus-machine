import type {
	Options as CCOptions,
	McpSdkServerConfigWithInstance,
} from "@anthropic-ai/claude-agent-sdk";
import type { McpServerConfig, PermissionMode, ThinkingLevel } from "../../../protocol/index.ts";

/**
 * In-process MCP servers (the SDK's `createSdkMcpServer` output). Operator
 * embed-tier only — instances can't travel a wire, so these never appear in
 * RunConfig; they merge into the SDK's `mcpServers` beside the wire-configured
 * ones and win name conflicts (the host owns its own tools).
 */
export type SdkMcpServers = Record<string, McpSdkServerConfigWithInstance>;

/**
 * Operator SDK-option overrides (embed-tier escape hatch for surface the
 * engine does not model: disallowedTools, forwardSubagentText, extraArgs, ...).
 * The Omit list is the engine's own wiring — fields whose silent clobber would
 * desync session diffing (cwd/env/permissionMode/resume), break the adapter
 * (includePartialMessages), or bypass engine merges (mcpServers, hooks,
 * canUseTool) — so "cannot be overridden" is compiler-enforced.
 */
export type ClaudeSdkOptionOverrides = Partial<
	Omit<
		CCOptions,
		| "canUseTool"
		| "hooks"
		| "mcpServers"
		| "resume"
		| "resumeSessionAt"
		| "cwd"
		| "env"
		| "permissionMode"
		| "includePartialMessages"
		| "pathToClaudeCodeExecutable"
	>
>;

/** Internal config for one live Claude session (a value the session manager keys/diffs on). */
export interface ClaudeSessionConfig {
	cwd: string;
	additionalDirectories?: string[];
	model?: string;
	thinkingLevel?: ThinkingLevel;
	permissionMode?: PermissionMode;
	maxTurns?: number;
	systemPromptAppend?: string;
	resumeSessionId?: string;
	resumeSessionAt?: string;
	mcpServers?: Record<string, McpServerConfig>;
	env?: Record<string, string>;
	apiKey?: string;
	idleTimeoutMs?: number;
	/** Disable all built-in tools (used by text-only smoke runs). */
	disableTools?: boolean;
	/**
	 * Explicit `claude` binary (from the provisioner / operator override).
	 * Unset lets the SDK resolve its sibling platform package — which fails
	 * inside compiled binaries, where this must be provided.
	 */
	cliPath?: string;
}

/**
 * Map our permission posture onto the Claude SDK's. `bypassPermissions`
 * auto-approves every tool and is dangerous outside a sandbox, so it must be
 * requested explicitly — an unset/unknown mode falls back to the safe `default`.
 */
function toSdkPermissionMode(mode: PermissionMode | undefined): CCOptions["permissionMode"] {
	switch (mode) {
		case "bypass_permissions":
			return "bypassPermissions";
		case "plan":
			return "plan";
		case "accept_edits":
			return "acceptEdits";
		case "dont_ask":
			// Native SDK mode: never prompt, deny unapproved. Unlike
			// bypassPermissions it needs no dangerous flag (and the CLI keeps
			// extended thinking enabled, which bypass turns off).
			return "dontAsk";
		default:
			return "default";
	}
}

/**
 * Build the env handed to the Claude subprocess. The SDK REPLACES the child env
 * entirely when `env` is set, so we must spread `process.env` to preserve PATH/
 * HOME (and thus keychain/subscription auth). We only inject ANTHROPIC_API_KEY
 * when an explicit key is supplied — otherwise the CLI's own auth is used.
 */
function buildEnv(config: ClaudeSessionConfig): Record<string, string | undefined> {
	return {
		...process.env,
		...(config.apiKey ? { ANTHROPIC_API_KEY: config.apiKey } : {}),
		...config.env,
	};
}

export function buildClaudeOptions(
	config: ClaudeSessionConfig,
	sdkMcpServers?: SdkMcpServers,
	overrides?: ClaudeSdkOptionOverrides,
): CCOptions {
	const mode = toSdkPermissionMode(config.permissionMode);

	const options: CCOptions = {
		cwd: config.cwd,
		maxTurns: config.maxTurns ?? 100,
		permissionMode: mode,
		// Streaming input mode + partial messages give us token-level deltas.
		includePartialMessages: true,
		systemPrompt: config.systemPromptAppend
			? { type: "preset", preset: "claude_code", append: config.systemPromptAppend }
			: { type: "preset", preset: "claude_code" },
		env: buildEnv(config),
	};

	if (config.cliPath) options.pathToClaudeCodeExecutable = config.cliPath;
	if (config.model) options.model = config.model;
	if (config.additionalDirectories?.length)
		options.additionalDirectories = config.additionalDirectories;
	if (mode === "bypassPermissions") options.allowDangerouslySkipPermissions = true;
	if (config.thinkingLevel !== undefined) {
		// Modern SDK vocabulary (maxThinkingTokens is deprecated): adaptive
		// thinking with an effort level; `off` disables extended thinking.
		if (config.thinkingLevel === "off") {
			options.thinking = { type: "disabled" };
		} else {
			options.thinking = { type: "adaptive" };
			options.effort = config.thinkingLevel;
		}
	}
	if (config.resumeSessionId) {
		options.resume = config.resumeSessionId;
		// SDK contract: resumeSessionAt is only meaningful WITH resume — never
		// pass it alone (the CLI would get a bare --resume-session-at).
		if (config.resumeSessionAt) options.resumeSessionAt = config.resumeSessionAt;
	}
	if (config.disableTools) {
		// Text-only. `tools: []` drops built-in tools, but ambient tools (LSP, MCP
		// servers) are injected by the user's filesystem settings, which that alone
		// doesn't suppress — so also run in SDK isolation (`settingSources: []`) and
		// honor only explicitly-passed MCP servers (none).
		options.tools = [];
		options.settingSources = [];
		options.strictMcpConfig = true;
	} else if (config.mcpServers || sdkMcpServers) {
		// Our McpServerConfig is structurally assignable to the SDK's stdio/http/sse
		// shapes; in-process servers merge beside them (operator wins conflicts).
		options.mcpServers = { ...config.mcpServers, ...sdkMcpServers };
	}

	// Operator overrides land last; the engine wires hooks/canUseTool after
	// this function returns, so those can never be clobbered (and the
	// ClaudeSdkOptionOverrides type excludes them anyway).
	if (overrides) Object.assign(options, overrides);

	// Fable-class models withhold thinking plaintext by default: blocks stream
	// structure + token estimates only, so every reasoning part arrives with
	// empty text. The hidden `--thinking-display summarized` flag opts into
	// summary text (ignored by CLIs that don't honor it). Applied after operator
	// overrides so an unrelated operator extraArgs can't drop it, while an
	// explicit operator `thinking-display` key still wins.
	if (config.thinkingLevel !== "off") {
		options.extraArgs = { "thinking-display": "summarized", ...options.extraArgs };
	}

	return options;
}
