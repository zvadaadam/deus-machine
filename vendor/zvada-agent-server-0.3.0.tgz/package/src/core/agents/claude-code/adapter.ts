import {
	DEFAULT_TOKEN_USAGE,
	type ReasoningPart,
	type StopReason,
	type StreamContext,
	type SubagentMetadata,
	type TextPart,
	type TokenUsage,
	type ToolPart,
	type ToolResultContent,
	appendToolInput,
	completeToolPart,
	createPendingToolPart,
	createReasoningPart,
	createTextPart,
	createToolPart,
	setToolMeta,
	startToolPart,
} from "../../../protocol/index.ts";
import { claudeToolMeta, toolLocationsFromInput } from "../tool-meta.ts";
import type { AdapterEvent, EventTransformer, TransformResult } from "../types.ts";

/**
 * Parses raw Claude Code SDK messages into normalized AdapterEvents.
 *
 * The main signal is the `stream_event` message (Anthropic raw streaming):
 * content_block_start opens a part, content_block_delta streams text/thinking/
 * tool-input, content_block_stop finalizes it. Tool results arrive later as
 * `user` messages and complete the matching tool part in place. The terminal
 * `result` message carries authoritative usage/cost. We rely on streaming for
 * content, so the non-streaming `assistant` message is processed only as a
 * fallback when partial messages were absent for it (e.g. some sub-agent paths)
 * — see `streamedThisMessage`.
 */

// --- Minimal structural types for the Anthropic stream events we consume. ---
// (Kept local so the adapter doesn't hard-depend on @anthropic-ai/sdk types.)
interface StreamEvent {
	type: string;
	index?: number;
	content_block?: { type: string; id?: string; name?: string };
	delta?: {
		type?: string;
		text?: string;
		thinking?: string;
		partial_json?: string;
		stop_reason?: string;
	};
	usage?: { output_tokens?: number };
}
interface RawUsage {
	input_tokens?: number;
	output_tokens?: number;
	cache_read_input_tokens?: number;
	cache_creation_input_tokens?: number;
}
interface ContentBlock {
	type: string;
	text?: string;
	thinking?: string;
	id?: string;
	name?: string;
	input?: Record<string, unknown>;
	tool_use_id?: string;
	content?: unknown;
	is_error?: boolean;
}
type ClaudeMessage =
	| {
			type: "system";
			subtype?: string;
			compact_metadata?: { trigger?: string; pre_tokens?: number; post_tokens?: number };
	  }
	| { type: "stream_event"; event: StreamEvent; parent_tool_use_id?: string | null }
	// Synthetic, appended by ClaudeCodeAgent when the turn's abort controller
	// fired — disambiguates interrupt from execution failure (same SDK result).
	| { type: "turn_interrupted" }
	| {
			type: "assistant";
			message?: { content?: ContentBlock[]; usage?: RawUsage };
			parent_tool_use_id?: string | null;
	  }
	| { type: "user"; message?: { content?: ContentBlock[] | string } }
	| {
			type: "result";
			subtype?: string;
			usage?: RawUsage;
			modelUsage?: Record<string, { contextWindow?: number }>;
			total_cost_usd?: number;
			stop_reason?: string | null;
			is_error?: boolean;
	  };

type BlockKind = "text" | "reasoning" | "tool";
interface BlockEntry {
	partId: string;
	kind: BlockKind;
	part: TextPart | ReasoningPart | ToolPart;
}

function safeParseJson(input: string): Record<string, unknown> {
	if (!input.trim()) return {};
	try {
		const v = JSON.parse(input);
		return v && typeof v === "object" ? (v as Record<string, unknown>) : {};
	} catch {
		return {};
	}
}

/** Map Anthropic stop reasons / result subtypes onto the normalized enum. */
function mapClaudeStopReason(
	stopReason: string | null | undefined,
	subtype: string | undefined,
): StopReason | undefined {
	if (subtype === "error_max_turns") return "max_turn_requests";
	switch (stopReason) {
		case "end_turn":
		case "stop_sequence":
		case "tool_use":
		case "pause_turn":
			return "end_turn";
		case "max_tokens":
			return "max_tokens";
		case "refusal":
			return "refusal";
		default:
			return undefined;
	}
}

/** Context occupancy from an Anthropic usage block: full prompt + output. */
function contextTokens(usage: RawUsage): number {
	return (
		(usage.input_tokens ?? 0) +
		(usage.cache_read_input_tokens ?? 0) +
		(usage.cache_creation_input_tokens ?? 0) +
		(usage.output_tokens ?? 0)
	);
}

function stringifyToolResult(content: unknown): string {
	if (typeof content === "string") return content;
	if (Array.isArray(content)) {
		return content
			.map((b) =>
				b && typeof b === "object" && "text" in b ? String((b as { text: unknown }).text) : "",
			)
			.join("");
	}
	if (content == null) return "";
	return JSON.stringify(content);
}

/**
 * The display-grade view of a tool_result's content blocks (spec §3.4): the
 * flattened string stays the model-facing record, this preserves what
 * flattening drops — images especially, which contribute "" to the string.
 * Block shapes we can't express are skipped, never guessed.
 */
function toolResultContent(content: unknown): ToolResultContent[] | undefined {
	if (!Array.isArray(content)) return undefined;
	const out: ToolResultContent[] = [];
	for (const raw of content) {
		if (!raw || typeof raw !== "object") continue;
		const block = raw as {
			type?: unknown;
			text?: unknown;
			source?: { data?: unknown; media_type?: unknown } | null;
		};
		if (block.type === "text" && typeof block.text === "string") {
			out.push({ type: "text", text: block.text });
			continue;
		}
		if (block.type === "image") {
			const { data, media_type } = block.source ?? {};
			// Only the base64 source form is expressible — ToolResultContent has no url variant.
			if (typeof data === "string" && typeof media_type === "string") {
				out.push({ type: "image", data, mimeType: media_type });
			}
		}
	}
	return out.length ? out : undefined;
}

/**
 * SubagentMetadata from a spawning tool's input, shared by the streamed and
 * non-streaming paths. `subagent_type` in the input identifies a spawn on any
 * tool name; `Task` is Claude's own spawn tool and counts even before its
 * input parses into anything useful (presence of `subagent` is what promotes
 * the part to `kind: "task"` — see protocol §3.5).
 */
function subagentFromInput(
	toolName: string,
	input: Record<string, unknown>,
): SubagentMetadata | undefined {
	const str = (key: string): string | undefined =>
		typeof input[key] === "string" ? (input[key] as string) : undefined;
	const type = str("subagent_type");
	if (type === undefined && toolName !== "Task") return undefined;
	const description = str("description");
	const model = str("model");
	return {
		...(type !== undefined && { type }),
		...(description !== undefined && { description }),
		...(model !== undefined && { model }),
	};
}

export class ClaudeCodeTransformer implements EventTransformer<unknown> {
	private readonly ctx: StreamContext;
	/** Anthropic content blocks of the in-flight message, by stream index. */
	private blocks = new Map<number, BlockEntry>();
	/** Tool parts by tool_use_id, so a later tool_result can complete them. */
	private readonly toolPartsById = new Map<string, ToolPart>();
	private currentParent?: string;
	/**
	 * Set by ANY stream_event in this turn (the transformer is per-turn). When
	 * set, the trailing complete `assistant` snapshot just repeats content we
	 * already streamed, so it is skipped — except sub-agent replies, which never
	 * stream and arrive only as a complete message. Mirrors the source sidecars'
	 * sticky `hasReceivedStreamEvents` flag; a per-message flag (reset on the
	 * first assistant) double-emits text when a message mixes text + tool_use.
	 */
	private hasStreamed = false;

	private usage: TokenUsage = { ...DEFAULT_TOKEN_USAGE };
	private stopReason?: StopReason;
	private finishReason?: string;
	private cost?: number;
	private error?: string;
	private interrupted = false;
	private execFailure = false;
	private sawResult = false;

	constructor(ctx: { sessionId: string }) {
		this.ctx = { sessionId: ctx.sessionId, messageId: "" };
	}

	process(raw: unknown): AdapterEvent[] {
		const msg = raw as ClaudeMessage;
		switch (msg.type) {
			case "stream_event":
				return this.handleStream(msg.event, msg.parent_tool_use_id ?? undefined);
			case "assistant":
				return this.handleAssistant(msg);
			case "user":
				return this.handleToolResults(msg.message?.content);
			case "result":
				return this.captureResult(msg);
			case "turn_interrupted":
				// Synthetic marker from ClaudeCodeAgent: an interrupt WAS requested
				// for this turn (arrives after the result, so decide in finish()).
				this.interrupted = true;
				return [];
			case "system":
				if (msg.subtype === "compact_boundary") {
					const meta = msg.compact_metadata ?? {};
					return [
						{
							kind: "compacted",
							trigger: meta.trigger,
							preTokens: meta.pre_tokens,
							postTokens: meta.post_tokens,
						},
					];
				}
				return [];
			default:
				return [];
		}
	}

	finish(): TransformResult {
		// error_during_execution + null stop_reason is cancellation ONLY when the
		// agent confirmed an interrupt; otherwise it is a real failure (a silent
		// "cancelled" here is how a bad resume id used to vanish without a trace).
		// A confirmed interrupt with NO result at all (aborted before the SDK
		// emitted one) is also a cancellation, not a completed turn.
		const cancelled = this.interrupted && (this.execFailure || !this.sawResult);
		const error =
			this.error ??
			(this.execFailure && !this.interrupted
				? "Claude turn failed during execution (error_during_execution — e.g. an invalid resumeSessionId fails this way)"
				: undefined);
		return {
			usage: this.usage,
			stopReason: this.stopReason,
			finishReason: this.finishReason,
			cost: this.cost,
			error,
			cancelled,
		};
	}

	private ctxFor(): StreamContext {
		// `parentToolCallId` is the protocol spelling; Claude's own wire field is
		// `parent_tool_use_id`. Spelling this the provider's way silently dropped
		// every subagent linkage (a conditional spread dodges excess-property checks).
		return { ...this.ctx, ...(this.currentParent ? { parentToolCallId: this.currentParent } : {}) };
	}

	/**
	 * Fallback for messages delivered without streaming (notably some sub-agent
	 * paths). If the in-flight message already streamed, its parts are live —
	 * skip the duplicate. Otherwise emit its content blocks as finalized parts.
	 */
	private handleAssistant(msg: Extract<ClaudeMessage, { type: "assistant" }>): AdapterEvent[] {
		// Context gauge: every top-level model message carries fresh usage (the
		// sub-agent's context is its own and would misreport the session's).
		const gauge: AdapterEvent[] =
			msg.message?.usage && !msg.parent_tool_use_id
				? [{ kind: "usage", used: contextTokens(msg.message.usage) }]
				: [];
		// Streaming already emitted this content live via stream_event deltas; the
		// trailing complete snapshot would duplicate it. Skip — except sub-agent
		// replies (parent_tool_use_id), which never stream and arrive only here.
		if (this.hasStreamed && !msg.parent_tool_use_id) return gauge;
		const content = msg.message?.content;
		if (!Array.isArray(content)) return [];
		const prevParent = this.currentParent;
		this.currentParent = msg.parent_tool_use_id ?? undefined;
		const events: AdapterEvent[] = [];
		for (const block of content) {
			if (block.type === "text" && block.text) {
				events.push({ kind: "part-open", part: createTextPart(this.ctxFor(), block.text, false) });
			} else if (block.type === "thinking" || block.type === "redacted_thinking") {
				const redacted = block.type === "redacted_thinking";
				// A redacted block carries no plaintext (its `data` is an encrypted
				// blob), so emit it on the flag alone — the redaction is the signal.
				if (!block.thinking && !redacted) continue;
				// A complete block opens and closes at once: one stamp for both ends.
				const now = Date.now();
				const part = createReasoningPart(this.ctxFor(), block.thinking ?? "", false);
				part.time = { start: now, end: now };
				if (redacted) part.providerMetadata = { redacted: true };
				events.push({ kind: "part-open", part });
			} else if (block.type === "tool_use" && block.id) {
				const name = block.name ?? "tool";
				const input = block.input ?? {};
				const subagent = subagentFromInput(name, input);
				const part = createToolPart(this.ctxFor(), block.id, name, input, {
					...claudeToolMeta(name, input),
					...(subagent && { subagent }),
				});
				this.toolPartsById.set(block.id, part);
				events.push({ kind: "part-open", part });
			}
		}
		this.currentParent = prevParent;
		return [...gauge, ...events];
	}

	private handleStream(event: StreamEvent, parentToolCallId?: string): AdapterEvent[] {
		// Sticky for the whole turn: any stream event means the trailing complete
		// `assistant` snapshot is a duplicate of what we streamed.
		this.hasStreamed = true;
		switch (event.type) {
			case "message_start":
				this.blocks.clear();
				this.currentParent = parentToolCallId;
				// Each top-level model message becomes a wire message. Sub-agent
				// messages don't open one — their parts nest via parentToolCallId.
				return parentToolCallId ? [] : [{ kind: "message-start", role: "assistant" }];
			case "content_block_start":
				return this.openBlock(event);
			case "content_block_delta":
				return this.deltaBlock(event);
			case "content_block_stop":
				return this.closeBlock(event);
			case "message_delta":
				if (typeof event.delta?.stop_reason === "string")
					this.finishReason = event.delta.stop_reason;
				if (event.usage?.output_tokens) this.usage.output = event.usage.output_tokens;
				return [];
			case "message_stop":
				return parentToolCallId || this.currentParent ? [] : [{ kind: "message-end" }];
			default:
				return [];
		}
	}

	private openBlock(event: StreamEvent): AdapterEvent[] {
		const index = event.index ?? 0;
		const cb = event.content_block;
		if (!cb) return [];
		if (cb.type === "text") {
			const part = createTextPart(this.ctxFor(), "", true);
			this.blocks.set(index, { partId: part.id, kind: "text", part });
			return [{ kind: "part-open", part }];
		}
		if (cb.type === "thinking" || cb.type === "redacted_thinking") {
			const part = createReasoningPart(this.ctxFor(), "", true);
			// Thought duration starts here; content_block_stop closes it.
			part.time = { start: Date.now() };
			// The plaintext never arrives for a redacted block — keep the flag so a
			// consumer can render "[redacted]" instead of an empty thought.
			if (cb.type === "redacted_thinking") part.providerMetadata = { redacted: true };
			this.blocks.set(index, { partId: part.id, kind: "reasoning", part });
			return [{ kind: "part-open", part }];
		}
		if (cb.type === "tool_use") {
			const name = cb.name ?? "tool";
			const part = createPendingToolPart(this.ctxFor(), cb.id ?? "", name, claudeToolMeta(name));
			this.blocks.set(index, { partId: part.id, kind: "tool", part });
			if (cb.id) this.toolPartsById.set(cb.id, part);
			return [{ kind: "part-open", part }];
		}
		return [];
	}

	private deltaBlock(event: StreamEvent): AdapterEvent[] {
		const entry = this.blocks.get(event.index ?? 0);
		const d = event.delta;
		if (!entry || !d) return [];
		if (d.type === "text_delta" && entry.kind === "text" && d.text) {
			(entry.part as TextPart).text += d.text;
			return [{ kind: "text-delta", partId: entry.partId, text: d.text }];
		}
		if (d.type === "thinking_delta" && entry.kind === "reasoning" && d.thinking) {
			(entry.part as ReasoningPart).text += d.thinking;
			return [{ kind: "reasoning-delta", partId: entry.partId, text: d.thinking }];
		}
		if (d.type === "input_json_delta" && entry.kind === "tool" && d.partial_json) {
			const tool = entry.part as ToolPart;
			appendToolInput(tool, d.partial_json);
			return [
				{
					kind: "tool-input-delta",
					partId: entry.partId,
					toolCallId: tool.toolCallId,
					toolName: tool.toolName,
					input: d.partial_json,
				},
			];
		}
		return [];
	}

	private closeBlock(event: StreamEvent): AdapterEvent[] {
		const entry = this.blocks.get(event.index ?? 0);
		if (!entry) return [];
		if (entry.kind === "text" || entry.kind === "reasoning") {
			const part = entry.part as TextPart | ReasoningPart;
			part.state = "done";
			if (entry.kind === "reasoning") {
				const reasoning = part as ReasoningPart;
				reasoning.time = { start: reasoning.time?.start ?? Date.now(), end: Date.now() };
			}
			return [{ kind: "part-update", part }];
		}
		const tool = entry.part as ToolPart;
		const partial = tool.state.status === "pending" ? tool.state.partialInput : "";
		const input = safeParseJson(partial);
		startToolPart(tool, input);
		// The streamed open carried no input, so subagent metadata can only be
		// read now that the partial JSON has parsed.
		const locations = toolLocationsFromInput(input);
		const subagent = subagentFromInput(tool.toolName, input);
		if (locations || subagent) {
			setToolMeta(tool, { ...(locations && { locations }), ...(subagent && { subagent }) });
		}
		return [{ kind: "part-update", part: tool }];
	}

	private handleToolResults(content: ContentBlock[] | string | undefined): AdapterEvent[] {
		if (!Array.isArray(content)) return [];
		const events: AdapterEvent[] = [];
		for (const block of content) {
			if (block.type !== "tool_result" || !block.tool_use_id) continue;
			const tool = this.toolPartsById.get(block.tool_use_id);
			if (!tool) continue;
			const content = toolResultContent(block.content);
			completeToolPart(tool, {
				output: stringifyToolResult(block.content),
				isError: block.is_error === true,
				...(content && { content }),
			});
			events.push({ kind: "part-update", part: tool });
		}
		return events;
	}

	private captureResult(msg: Extract<ClaudeMessage, { type: "result" }>): AdapterEvent[] {
		this.sawResult = true;
		if (msg.usage) {
			this.usage = {
				input: msg.usage.input_tokens ?? 0,
				output: msg.usage.output_tokens ?? this.usage.output,
				cache: {
					read: msg.usage.cache_read_input_tokens ?? 0,
					write: msg.usage.cache_creation_input_tokens ?? 0,
				},
			};
		}
		if (typeof msg.total_cost_usd === "number") this.cost = msg.total_cost_usd;
		this.finishReason = msg.stop_reason ?? msg.subtype ?? this.finishReason;
		this.stopReason = mapClaudeStopReason(msg.stop_reason, msg.subtype);
		if (msg.subtype && msg.subtype !== "success") {
			if (msg.subtype === "error_during_execution" && msg.stop_reason === null) {
				// Ambiguous shape: an interrupt AND an execution failure (e.g. a bad
				// resume id) both surface this way. The agent's `turn_interrupted`
				// marker (which arrives after this message) disambiguates in finish().
				this.execFailure = true;
			} else if (msg.subtype === "error_max_turns") {
				// Hitting the turn budget is a stop condition, not a failure.
			} else {
				this.error = `Claude turn ended: ${msg.subtype}`;
			}
		}
		// Final authoritative gauge: the result knows the context-window size.
		if (!msg.usage) return [];
		const size = Object.values(msg.modelUsage ?? {})
			.map((m) => m.contextWindow ?? 0)
			.reduce((a, b) => Math.max(a, b), 0);
		return [
			{
				kind: "usage",
				used: contextTokens(msg.usage),
				...(size > 0 && { size }),
				...(this.cost !== undefined && { cost: this.cost }),
			},
		];
	}
}

export function createClaudeCodeTransformer(ctx: { sessionId: string }): EventTransformer {
	return new ClaudeCodeTransformer(ctx);
}
