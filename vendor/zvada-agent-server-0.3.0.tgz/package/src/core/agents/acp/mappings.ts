import type {
	ContentBlock,
	McpServer,
	PermissionOption,
	RequestPermissionRequest,
	RequestPermissionResponse,
	ToolCallLocation,
} from "@agentclientprotocol/sdk";
import type {
	AgentInput,
	McpServerConfig,
	PermissionMode,
	PermissionToolCall,
	ToolKind,
	ToolLocation,
} from "../../../protocol/index.ts";
import { TOOL_KINDS } from "../../../protocol/index.ts";

/**
 * The single bridge between ACP's vocabulary and the engine's. Everything here
 * is a pure conversion shared by the agent (outbound requests, permission
 * round-trips) and the adapter (inbound session updates) — the harness
 * seat's single bridge, so its two halves cannot drift. (The ACP *server*
 * binding in packages/server/src/acp/ is the inverse direction, not a copy.)
 */

/** ACP's ToolKind strings are ours verbatim (DESIGN D2); narrow with a membership check. */
export function toolKindOf(kind: string | null | undefined): ToolKind | undefined {
	return kind && (TOOL_KINDS as readonly string[]).includes(kind) ? (kind as ToolKind) : undefined;
}

/** ACP `ToolCallLocation[]` → engine `ToolLocation[]` (drop null lines, empty → absent). */
export function toToolLocations(
	locations: ToolCallLocation[] | null | undefined,
): ToolLocation[] | undefined {
	if (!locations?.length) return undefined;
	return locations.map((l) => ({ path: l.path, ...(l.line != null && { line: l.line }) }));
}

/** Engine MCP config map → ACP `McpServer[]` (names come from the record keys). */
export function toAcpMcpServers(
	mcpServers: Record<string, McpServerConfig> | undefined,
): McpServer[] {
	if (!mcpServers) return [];
	return Object.entries(mcpServers).map(([name, config]): McpServer => {
		if (config.type === "stdio") {
			return {
				name,
				command: config.command,
				args: config.args ?? [],
				env: Object.entries(config.env ?? {}).map(([n, value]) => ({ name: n, value })),
			};
		}
		return {
			type: config.type,
			name,
			url: config.url,
			headers: Object.entries(config.headers ?? {}).map(([n, value]) => ({ name: n, value })),
		};
	});
}

/** Engine turn input → ACP prompt content blocks (image blocks gated on agent capability). */
export function toPromptBlocks(input: AgentInput, imagesSupported: boolean): ContentBlock[] {
	if (typeof input === "string") return [{ type: "text", text: input }];
	const blocks: ContentBlock[] = [];
	for (const part of input) {
		if (part.type === "text") {
			blocks.push({ type: "text", text: part.text });
		} else if (part.type === "image" && imagesSupported) {
			if (part.data) {
				blocks.push({ type: "image", data: part.data, mimeType: part.mimeType });
			} else if (part.url) {
				blocks.push({ type: "resource_link", uri: part.url, name: part.url });
			}
		} else if (part.type === "file" && part.url) {
			blocks.push({ type: "resource_link", uri: part.url, name: part.url });
		}
	}
	return blocks.length ? blocks : [{ type: "text", text: "" }];
}

/** ACP permission request → the engine's PermissionToolCall (SDK-validated, no casts). */
export function permissionToolCall(request: RequestPermissionRequest): PermissionToolCall {
	const toolCall = request.toolCall;
	const kind = toolKindOf(toolCall.kind);
	const locations = toToolLocations(toolCall.locations);
	return {
		...(toolCall.toolCallId && { toolCallId: toolCall.toolCallId }),
		toolName: toolCall.name ?? toolCall.title ?? toolCall.kind ?? "tool",
		...(kind && { kind }),
		...(toolCall.title && { title: toolCall.title }),
		...(locations && { locations }),
		...(isRecord(toolCall.rawInput) && { rawInput: toolCall.rawInput }),
	};
}

export const CANCELLED_OUTCOME: RequestPermissionResponse = {
	outcome: { outcome: "cancelled" },
};

/**
 * Pick the option matching the decision: allow → first allow_once/allow_always,
 * deny → first reject_once/reject_always; no matching option → cancelled.
 */
export function chooseOutcome(
	options: PermissionOption[],
	allow: boolean,
): RequestPermissionResponse {
	const kinds = allow ? ["allow_once", "allow_always"] : ["reject_once", "reject_always"];
	for (const kind of kinds) {
		const match = options.find((o) => o.kind === kind);
		if (match) return { outcome: { outcome: "selected", optionId: match.optionId } };
	}
	return CANCELLED_OUTCOME;
}

/**
 * Decide an ACP permission request without the engine broker: mirrors the
 * codex posture where only `default` mode asks — every other mode auto-decides.
 */
export function autoDecide(
	request: RequestPermissionRequest,
	mode: PermissionMode | undefined,
): RequestPermissionResponse {
	const kind = request.toolCall.kind;
	const allowed =
		mode === "bypass_permissions" ||
		(mode === "accept_edits" && (kind === "edit" || kind === "read"));
	return chooseOutcome(request.options, allowed);
}

/** The SDK types `rawInput`/`rawOutput` as `unknown`; the engine wants a record. */
export function isRecord(value: unknown): value is Record<string, unknown> {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
