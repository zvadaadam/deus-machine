# Harness support matrix

Four harnesses, one event stream. The lifecycle event *structure* is identical
across harnesses (one generic `EventProcessor` drives it); payloads and config
support differ only where the backends genuinely do.

| Harness | Backend | Streaming | Resume | Model switch |
| --- | --- | --- | --- | --- |
| `claude-code` | `@anthropic-ai/claude-agent-sdk` (claude CLI) | token-level | yes (`resume`) | in-session (`setModel`) |
| `codex-sdk` | `@openai/codex-sdk` (codex CLI exec) | item-level (deltas synthesized) | yes (`resumeThread`) | restart-session |
| `codex-app-server` | `codex app-server` (JSON-RPC subprocess) | token-level | yes (`thread/resume`) | in-session (per-turn) |
| `acp` | any ACP v1 agent via `@agentclientprotocol/sdk` | per-agent | yes (`session/resume`) | per-agent |

The `acp` harness is opt-in (an operator-supplied launch command, never
wire-sourced): well-known agents run by name (`--harness=pi`,
`--harness=gemini`); anything else via `--acp-agent="<launch command>"` /
`$AGENT_SERVER_ACP_AGENT`, or `CreateRegistryOptions.acp.resolveLaunch` when
embedding.

All harnesses share: one stable logical `sessionId` you assign, a
harness-native id surfaced via `session.created` (persist it to resume later),
warm multi-turn reuse, a unified `ThinkingLevel`, and normalized token usage.

## `RunConfig` support per harness

| `RunConfig` field | claude-code | codex-sdk | codex-app-server |
| --- | --- | --- | --- |
| `model` | ✅ + hot-swap | ✅ (restart on change) | ✅ (per-turn) |
| `thinkingLevel` | ✅ | ✅ | ✅ |
| `permissionMode` | ✅ | ✅ → sandbox | ✅ → sandbox |
| `resumeSessionId` | ✅ | ✅ | ✅ |
| `systemPromptAppend` | ✅ | ❌ (SDK has no field) | ✅ (`developerInstructions`) |
| `maxTurns` | ✅ | ❌ | ❌ |
| `mcpServers` | ✅ | ❌ (capability=false) | ❌ (capability=false) |
| `apiKey` / `env` | ✅ | ✅ | `env` ✅, `apiKey` via ambient CLI auth |
| `disableTools` | ✅ | (use read-only sandbox) | (use read-only sandbox) |
| `permissionRequests` | ✅ (`canUseTool`) | ❌ (sandbox is the gate) | ✅ (`on-request` approvals) |
| `includeRaw` | ✅ | ✅ | ✅ |

Consult `runtime.capabilities(harness)` before relying on a capability.

## Payload notes

- A turn ends with a normalized `stopReason`
  (`end_turn | max_tokens | max_turn_requests | refusal | cancelled | error`);
  the raw provider string travels in `finishReason`.
- `cost` is reported only by Claude; `reasoning` tokens only by Codex.
- Tool names are provider-native for Claude (`Bash`, `Read`) and normalized
  for Codex (`shell`, `apply_patch`, …) — but the tool `kind`
  (`read`/`edit`/`execute`/…) is normalized for all.
- `raw` events are an opt-in (`config.includeRaw`) passthrough of the
  harness's unparsed event, for migration/debugging/fixture-recording. `data`
  has **no stability guarantees** and is off by default.

## Known limitations (roadmap)

- **MCP servers** are wired for Claude only; Codex MCP passthrough is pending
  an upstream protocol re-verification.
- The **BYOK proxy** (`/core/proxy`) is a building block, not yet auto-wired
  into the harnesses (they use ambient/explicit keys today).
- **Hook bridge** (PreToolUse/Stop decisions) is exposed for the claude
  embed tier only (`hooks` factory); there is no wire-level hook surface yet.
- The WebSocket wire has no built-in auth — see
  [deploy.md](deploy.md#trust-boundary).
