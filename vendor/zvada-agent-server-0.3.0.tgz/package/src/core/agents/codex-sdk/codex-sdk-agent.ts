import type { Codex, Thread, ThreadEvent, ThreadOptions } from "@openai/codex-sdk";
import type { AgentCapabilities, AgentInput, PermissionMode } from "../../../protocol/index.ts";
import { codexReasoningEffort } from "../../../protocol/index.ts";
import type { AgentExecuteOptions, RawAgentEvent } from "../base.ts";
import { BaseAgent } from "../base.ts";
import { configFingerprint } from "../config-fingerprint.ts";

const CAPABILITIES: AgentCapabilities = {
	multiTurn: true,
	sessionResume: true,
	// A Codex thread's model/effort is fixed at creation; changing them restarts it.
	modelSwitch: "restart-session",
	thinkingLevels: true,
	images: false,
	mcpServers: false,
	// Codex exec mode has no approval callback — the sandbox is the gate.
	permissionRequests: false,
};

export interface LiveThread {
	thread: Thread;
	model?: string;
	thinkingLevel?: string;
	cwd: string;
	permissionMode?: PermissionMode;
	credentialsFingerprint: string;
	systemPromptAppend?: string;
	additionalDirectoriesFingerprint: string;
}

function credentialsFingerprint(options: Pick<AgentExecuteOptions, "apiKey" | "env">): string {
	return configFingerprint({ apiKey: options.apiKey, env: options.env });
}

/** Sandbox surface identity — a changed directory set must restart the thread. */
function directoriesFingerprint(
	options: Pick<AgentExecuteOptions, "additionalDirectories">,
): string {
	// Order and duplicates don't change the sandbox surface — don't churn threads.
	return configFingerprint([...new Set(options.additionalDirectories ?? [])].sort());
}

/**
 * Instance identity: credentials plus constructor-level config. The SDK fixes
 * `developer_instructions` at `new Codex(...)`, so a different append needs a
 * different instance; the thread restarts too (`codexThreadCompatible`) but
 * keeps its context via the auto-resume path — restart-with-resume, matching
 * the claude-code policy for systemPromptAppend changes.
 */
function instanceFingerprint(
	options: Pick<AgentExecuteOptions, "apiKey" | "env" | "systemPromptAppend">,
): string {
	return configFingerprint({
		apiKey: options.apiKey,
		env: options.env,
		// One equality convention with codexThreadCompatible: absent == empty.
		systemPromptAppend: options.systemPromptAppend ?? "",
	});
}

export function codexThreadCompatible(
	existing: LiveThread | undefined,
	options: AgentExecuteOptions,
): boolean {
	return Boolean(
		existing &&
			existing.cwd === options.cwd &&
			existing.model === options.model &&
			existing.thinkingLevel === options.thinkingLevel &&
			existing.permissionMode === options.permissionMode &&
			existing.credentialsFingerprint === credentialsFingerprint(options) &&
			(existing.systemPromptAppend ?? "") === (options.systemPromptAppend ?? "") &&
			existing.additionalDirectoriesFingerprint === directoriesFingerprint(options) &&
			(!options.resumeSessionId || options.resumeSessionId === existing.thread.id),
	);
}

function mapSandbox(mode: PermissionMode | undefined): ThreadOptions["sandboxMode"] {
	switch (mode) {
		case "bypass_permissions":
			return "danger-full-access";
		case "accept_edits":
		case "dont_ask":
			// Never-ask posture, but inside the normal sandbox — danger-full is
			// reserved for the explicitly dangerous mode.
			return "workspace-write";
		default:
			return "read-only";
	}
}

function toCodexInput(input: AgentInput): string {
	if (typeof input === "string") return input;
	return input
		.filter((p) => p.type === "text")
		.map((p) => (p.type === "text" ? p.text : ""))
		.join("\n\n");
}

function threadOptions(options: AgentExecuteOptions): ThreadOptions {
	const opts: ThreadOptions = {
		workingDirectory: options.cwd,
		skipGitRepoCheck: true,
		approvalPolicy: "never",
		sandboxMode: mapSandbox(options.permissionMode),
		...(options.additionalDirectories?.length
			? { additionalDirectories: options.additionalDirectories }
			: {}),
	};
	if (options.model) opts.model = options.model;
	if (options.thinkingLevel)
		opts.modelReasoningEffort = codexReasoningEffort(options.thinkingLevel);
	return opts;
}

export interface CodexSdkAgentOptions {
	/**
	 * Resolve the `codex` binary to spawn (typically the provisioner's,
	 * memoized). `undefined` defers to the SDK's own lookup. Operator-level
	 * only — never sourced from the wire.
	 */
	resolveCliPath?: () => Promise<string | undefined>;
}

/**
 * Codex harness backed by `@openai/codex-sdk` (which runs the `codex` CLI in
 * exec mode). A `Thread` is reused per logical session for multi-turn; model or
 * effort changes recreate it (restart-session). Resume across processes uses
 * `resumeThread(nativeId)`. Streams at item granularity — the adapter derives
 * text deltas by diffing successive item snapshots.
 */
export class CodexSdkAgent extends BaseAgent {
	readonly harness = "codex-sdk" as const;
	readonly capabilities = CAPABILITIES;
	private readonly threads = new Map<string, LiveThread>();
	// Instance-level config (credentials AND developer_instructions) is fixed
	// at construction, so one instance per distinct (apiKey, env, append) —
	// keying by a fingerprint prevents one session's key or instructions from
	// bleeding into another's.
	private readonly codexByCreds = new Map<string, Codex>();

	constructor(private readonly agentOptions: CodexSdkAgentOptions = {}) {
		super();
	}

	private async getCodex(options: AgentExecuteOptions): Promise<Codex> {
		const fingerprint = instanceFingerprint(options);
		const cached = this.codexByCreds.get(fingerprint);
		if (cached) return cached;
		const codexPathOverride = await this.agentOptions.resolveCliPath?.();
		const { Codex } = await import("@openai/codex-sdk");
		const codex = new Codex({
			...(codexPathOverride ? { codexPathOverride } : {}),
			...(options.apiKey ? { apiKey: options.apiKey } : {}),
			...(options.env ? { env: { ...process.env, ...options.env } as Record<string, string> } : {}),
			...(options.systemPromptAppend
				? { config: { developer_instructions: options.systemPromptAppend } }
				: {}),
		});
		this.codexByCreds.set(fingerprint, codex);
		return codex;
	}

	private async resolveThread(options: AgentExecuteOptions): Promise<LiveThread> {
		const existing = this.threads.get(options.sessionId);
		const effort = options.thinkingLevel;
		if (existing && codexThreadCompatible(existing, options)) return existing;

		const codex = await this.getCodex(options);
		const fingerprint = credentialsFingerprint(options);
		// Preserve context within the same cwd/credential boundary (mirrors the
		// claude-code restart policy); an explicit resumeSessionId always wins.
		const resumeThreadId =
			options.resumeSessionId ??
			(existing && existing.cwd === options.cwd && existing.credentialsFingerprint === fingerprint
				? existing.thread.id
				: undefined);
		const thread = resumeThreadId
			? codex.resumeThread(resumeThreadId, threadOptions(options))
			: codex.startThread(threadOptions(options));
		const live: LiveThread = {
			thread,
			model: options.model,
			thinkingLevel: effort,
			cwd: options.cwd,
			permissionMode: options.permissionMode,
			credentialsFingerprint: fingerprint,
			systemPromptAppend: options.systemPromptAppend,
			additionalDirectoriesFingerprint: directoriesFingerprint(options),
		};
		this.threads.set(options.sessionId, live);
		return live;
	}

	async *execute(
		input: AgentInput,
		options: AgentExecuteOptions,
	): AsyncIterableIterator<RawAgentEvent> {
		const controller = this.trackTurn(options.sessionId, options.signal);
		try {
			const live = await this.resolveThread(options);
			// Codex keeps the thread id on resume, so honored = same id came back.
			const resumeInfo = (id: string) => ({ resumed: id === options.resumeSessionId });
			if (live.thread.id) options.onNativeSession?.(live.thread.id, resumeInfo(live.thread.id));

			const { events } = await live.thread.runStreamed(toCodexInput(input), {
				signal: controller.signal,
			});

			let reported = Boolean(live.thread.id);
			for await (const event of events as AsyncGenerator<ThreadEvent>) {
				if (!reported && event.type === "thread.started" && event.thread_id) {
					reported = true;
					options.onNativeSession?.(event.thread_id, resumeInfo(event.thread_id));
				}
				yield event as RawAgentEvent;
			}
			// thread.id is populated once the turn has started.
			if (!reported && live.thread.id)
				options.onNativeSession?.(live.thread.id, resumeInfo(live.thread.id));
		} finally {
			this.endTurn(options.sessionId, controller);
		}
	}

	override async release(sessionId: string): Promise<void> {
		await super.release(sessionId);
		this.threads.delete(sessionId);
	}

	override async terminateAll(): Promise<void> {
		await super.terminateAll();
		this.threads.clear();
		this.codexByCreds.clear();
	}
}
