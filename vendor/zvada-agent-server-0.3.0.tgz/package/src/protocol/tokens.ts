import { z } from "zod";

/**
 * Normalized token accounting. Every harness reports usage differently
 * (Claude: input/output/cache_creation/cache_read; Codex: input/output/
 * reasoning/cached). Adapters fold those into this single shape.
 *
 * INVARIANTS (normative — so consumers never subtract):
 *  - `input` is NON-CACHED input tokens ONLY; billed input =
 *    `input + cache.read + cache.write` (the three are disjoint).
 *  - `reasoning` is a subset of `output` (output already includes it).
 *  - `writeEphemeral5m`/`writeEphemeral1h` are subsets of `cache.write`.
 * Providers that fold cache hits into a total prompt count are unfolded once,
 * at the adapter — never downstream.
 */
export const TokenUsageSchema = z.object({
	input: z.number().default(0),
	output: z.number().default(0),
	reasoning: z.number().optional(),
	cache: z
		.object({
			read: z.number().default(0),
			write: z.number().default(0),
			/** Anthropic 5m-TTL cache-creation bucket, when reported. */
			writeEphemeral5m: z.number().optional(),
			/** Anthropic 1h-TTL cache-creation bucket, when reported. */
			writeEphemeral1h: z.number().optional(),
		})
		.optional(),
});

export type TokenUsage = z.infer<typeof TokenUsageSchema>;

export const DEFAULT_TOKEN_USAGE: TokenUsage = {
	input: 0,
	output: 0,
	reasoning: 0,
	cache: { read: 0, write: 0 },
};

function addOptional(a: number | undefined, b: number | undefined): number | undefined {
	if (a === undefined && b === undefined) return undefined;
	return (a ?? 0) + (b ?? 0);
}

export function addTokenUsage(a: TokenUsage, b: TokenUsage): TokenUsage {
	return {
		input: a.input + b.input,
		output: a.output + b.output,
		reasoning: (a.reasoning ?? 0) + (b.reasoning ?? 0),
		cache: {
			read: (a.cache?.read ?? 0) + (b.cache?.read ?? 0),
			write: (a.cache?.write ?? 0) + (b.cache?.write ?? 0),
			...(addOptional(a.cache?.writeEphemeral5m, b.cache?.writeEphemeral5m) !== undefined
				? { writeEphemeral5m: addOptional(a.cache?.writeEphemeral5m, b.cache?.writeEphemeral5m) }
				: {}),
			...(addOptional(a.cache?.writeEphemeral1h, b.cache?.writeEphemeral1h) !== undefined
				? { writeEphemeral1h: addOptional(a.cache?.writeEphemeral1h, b.cache?.writeEphemeral1h) }
				: {}),
		},
	};
}
