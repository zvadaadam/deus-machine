import { z } from "zod";
import { openVocabulary } from "./vocabulary.ts";

/**
 * The one error vocabulary (Law: one shape per concept). Used by
 * `turn.ended.error`, the standalone `error` event, and `RunSummary.error`.
 *
 * OPEN (Law 3): products may extend with their own categories (deus adds
 * "db_write"); unknown non-`_` values are reserved for this protocol.
 * `usage_limit` (plan/quota exhausted) and `rate_limit` (429/backoff) are
 * deliberately distinct — they need different user guidance; collapsing them
 * is a display choice, never a wire merge.
 */
export const ERROR_CATEGORIES = [
	"auth",
	"rate_limit",
	"usage_limit",
	"context_limit",
	"network",
	"abort",
	"invalid_request",
	"process_exit",
	"internal",
] as const;
export type ErrorCategory = (typeof ERROR_CATEGORIES)[number] | (string & {});
export const ErrorCategorySchema = openVocabulary<ErrorCategory>();

export const ErrorInfoSchema = z.object({
	category: ErrorCategorySchema,
	message: z.string(),
});
export type ErrorInfo = z.infer<typeof ErrorInfoSchema>;

/**
 * Maps a raw harness error into a stable category, so callers can react
 * (retry on `network`/`rate_limit`, surface `auth` prominently, treat `abort`
 * as success). Rule order matters. Distilled from deus-machine's lifecycle
 * classifier; lives in /protocol because categories are vocabulary.
 */
const RULES: ReadonlyArray<[ErrorCategory, readonly string[]]> = [
	["abort", ["aborted", "aborterror", "cancelled", "canceled", "interrupted", "sigint"]],
	[
		"auth",
		[
			"unauthorized",
			"401",
			"authentication",
			"invalid api key",
			"invalid_api_key",
			"not logged in",
			"login required",
			"forbidden",
			"403",
		],
	],
	["rate_limit", ["rate limit", "rate_limit", "429", "too many requests"]],
	["usage_limit", ["usage limit", "quota", "insufficient_quota", "billing", "credit"]],
	["context_limit", ["context length", "context_length", "maximum context", "too many tokens"]],
	[
		"network",
		[
			"econnrefused",
			"econnreset",
			"etimedout",
			"enotfound",
			"network",
			"fetch failed",
			"socket hang up",
		],
	],
	["invalid_request", ["invalid request", "invalid_request_error", "400", "bad request"]],
	["process_exit", ["exited with code", "process exited", "spawn", "enoent", "killed"]],
];

export function classifyError(error: unknown): ErrorCategory {
	const message = (error instanceof Error ? error.message : String(error)).toLowerCase();
	for (const [category, needles] of RULES) {
		if (needles.some((n) => message.includes(n))) return category;
	}
	return "internal";
}

/** Whether a turn can plausibly be retried after this error. */
export function isRecoverable(category: ErrorCategory): boolean {
	return category === "rate_limit" || category === "network";
}

/** Abort is a user action, not a failure to report. */
export function isCancellation(error: unknown): boolean {
	return classifyError(error) === "abort";
}
