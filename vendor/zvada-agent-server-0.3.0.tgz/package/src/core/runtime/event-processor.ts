import { classifyError, generateUUIDv7 } from "../../protocol/index.ts";
import type { Delta, LifecycleEvent, Part, StopReason } from "../../protocol/index.ts";
import type { AdapterEvent, TransformResult } from "../agents/types.ts";

/** Where a part lives on the wire — fixed at first emission for the whole turn. */
interface PartAddress {
	messageId: string;
	outputIndex: number;
	partIndex: number;
}

/**
 * Turns the harness-agnostic AdapterEvent stream into wire LifecycleEvents.
 * Owns all id/index bookkeeping: assigns message ids, per-message output
 * indices, and per-part indices, and brackets messages with started/ended.
 *
 * Parts are registered turn-wide: a part keeps the message/indices of its
 * first emission even when updated after that message ended (e.g. a tool
 * completing after the model message that issued it) — consumers upsert by
 * `part.id`. One instance per turn.
 */
export class EventProcessor {
	private openMessageId?: string;
	/** `parentToolCallId` of the open message (undefined for top-level messages). */
	private openMessageParent?: string;
	private currentOutputIndex = -1;
	private nextOutputIndex = 0;
	private nextPartIndex = 0;
	private readonly partAddressById = new Map<string, PartAddress>();

	constructor(
		private readonly sessionId: string,
		private readonly turnId: string,
		private readonly meta: { harness?: string; model?: string } = {},
	) {}

	/**
	 * The user echo: emits the submitted input back onto the stream as a
	 * complete user message at outputIndex 0, before any harness output — the
	 * stream is a complete transcript. Reconciliation is by turnId (one user
	 * message per turn); the engine mints the messageId.
	 */
	*echoUserMessage(parts: Part[]): Generator<LifecycleEvent> {
		yield* this.openMessage("user");
		for (const part of parts) {
			yield* this.emitPart(part);
		}
		yield* this.closeMessage();
	}

	*handle(ev: AdapterEvent): Generator<LifecycleEvent> {
		switch (ev.kind) {
			case "message-start":
				yield* this.openMessage(ev.role);
				return;
			case "message-end":
				yield* this.closeMessage();
				return;
			case "part-open":
			case "part-update":
				yield* this.emitPart(ev.part);
				return;
			case "text-delta": {
				const e = this.delta(ev.partId, { type: "text", text: ev.text });
				if (e) yield e;
				return;
			}
			case "reasoning-delta": {
				const e = this.delta(ev.partId, { type: "reasoning", text: ev.text });
				if (e) yield e;
				return;
			}
			case "tool-input-delta": {
				const e = this.delta(ev.partId, {
					type: "tool_input",
					toolCallId: ev.toolCallId,
					toolName: ev.toolName,
					input: ev.input,
				});
				if (e) yield e;
				return;
			}
			case "usage":
				yield {
					type: "session.usage",
					sessionId: this.sessionId,
					turnId: this.turnId,
					used: ev.used,
					...(ev.size !== undefined && { size: ev.size }),
					...(ev.cost !== undefined && { cost: ev.cost }),
					timestamp: Date.now(),
				};
				return;
			case "compacted":
				// Harnesses report compaction after the fact — a single completed
				// upsert of the positional entity (its first appearance anchors it).
				yield {
					type: "session.compaction",
					sessionId: this.sessionId,
					turnId: this.turnId,
					compactionId: generateUUIDv7(),
					status: "completed",
					...(ev.trigger && { trigger: ev.trigger }),
					...(ev.preTokens !== undefined && { preTokens: ev.preTokens }),
					...(ev.postTokens !== undefined && { postTokens: ev.postTokens }),
					timestamp: Date.now(),
				};
				return;
		}
	}

	*finish(result: TransformResult, stopReason: StopReason): Generator<LifecycleEvent> {
		yield* this.closeMessage();
		yield {
			type: "turn.ended",
			turnId: this.turnId,
			sessionId: this.sessionId,
			stopReason,
			finishReason: result.finishReason,
			tokens: result.usage,
			cost: result.cost,
			error:
				result.error && !result.cancelled
					? { category: classifyError(result.error), message: result.error }
					: undefined,
			timestamp: Date.now(),
		};
	}

	private *openMessage(
		role: "assistant" | "user",
		parentToolCallId?: string,
	): Generator<LifecycleEvent> {
		if (this.openMessageId) yield* this.closeMessage();
		const messageId = generateUUIDv7();
		this.openMessageId = messageId;
		this.openMessageParent = parentToolCallId;
		this.currentOutputIndex = this.nextOutputIndex++;
		this.nextPartIndex = 0;
		yield {
			type: "message.started",
			sessionId: this.sessionId,
			turnId: this.turnId,
			messageId,
			outputIndex: this.currentOutputIndex,
			role,
			// A parented message is a sub-agent's output — nests under its tool call,
			// not a top-level model message (see DESIGN.md D5).
			...(parentToolCallId && { parentToolCallId }),
			...(this.meta.model && { model: this.meta.model }),
			timestamp: Date.now(),
		};
	}

	private *closeMessage(): Generator<LifecycleEvent> {
		if (!this.openMessageId) return;
		yield {
			type: "message.ended",
			sessionId: this.sessionId,
			turnId: this.turnId,
			messageId: this.openMessageId,
			timestamp: Date.now(),
		};
		this.openMessageId = undefined;
		this.openMessageParent = undefined;
	}

	/** Ensure an open message whose parent matches the incoming part. A part
	 * whose `parentToolCallId` differs from the open message (main↔sub-agent, or
	 * between sibling sub-agents) starts a new message so sub-agent output is
	 * grouped under its own parented message rather than mixed into another. */
	private *ensureMessage(parentToolCallId?: string): Generator<LifecycleEvent> {
		if (this.openMessageId && this.openMessageParent !== parentToolCallId) {
			yield* this.closeMessage();
		}
		if (!this.openMessageId) yield* this.openMessage("assistant", parentToolCallId);
	}

	/** Resolve (or assign) the wire address of a part. Yields a message.started
	 * first when the part is new and no matching message is open. */
	private *addressFor(
		partId: string,
		parentToolCallId?: string,
	): Generator<LifecycleEvent, PartAddress> {
		const existing = this.partAddressById.get(partId);
		if (existing) return existing;
		yield* this.ensureMessage(parentToolCallId);
		const address: PartAddress = {
			messageId: this.openMessageId as string,
			outputIndex: this.currentOutputIndex,
			partIndex: this.nextPartIndex++,
		};
		this.partAddressById.set(partId, address);
		return address;
	}

	private *emitPart(part: Part): Generator<LifecycleEvent> {
		const address = yield* this.addressFor(part.id, part.parentToolCallId);
		// Snapshot: adapters mutate their part objects in place across
		// open/update, so we must clone at emit time or buffered consumers would
		// all observe the final state. Stamp ownership so the part is
		// self-describing on the wire.
		const snapshot = structuredClone(part);
		snapshot.sessionId = this.sessionId;
		snapshot.messageId = address.messageId;
		yield {
			type: "message.part",
			sessionId: this.sessionId,
			turnId: this.turnId,
			messageId: address.messageId,
			outputIndex: address.outputIndex,
			partIndex: address.partIndex,
			part: snapshot,
			timestamp: Date.now(),
		};
	}

	private delta(partId: string, delta: Delta): LifecycleEvent | null {
		// Deltas only ever follow a part-open, so an unknown part id means a
		// misbehaving adapter — drop rather than fabricate an address.
		const address = this.partAddressById.get(partId);
		if (!address) return null;
		return {
			type: "message.part.delta",
			sessionId: this.sessionId,
			turnId: this.turnId,
			messageId: address.messageId,
			outputIndex: address.outputIndex,
			partIndex: address.partIndex,
			partId,
			delta,
			timestamp: Date.now(),
		};
	}
}
