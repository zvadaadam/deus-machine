import {
	type ErrorCategory,
	classifyError,
	isCancellation,
	isRecoverable,
} from "../../protocol/errors.ts";
import type {
	AgentCapabilities,
	AgentHarness,
	LifecycleEvent,
	PermissionOption,
	PermissionOutcome,
	PermissionToolCall,
	RunRequest,
	StopReason,
	TokenUsage,
} from "../../protocol/index.ts";
import { DEFAULT_TOKEN_USAGE, createUserEchoParts, generateUUIDv7 } from "../../protocol/index.ts";
import type { AgentExecuteOptions, CancelResult, PermissionDecision } from "../agents/base.ts";
import type { AgentRegistry } from "../agents/registry.ts";
import { type DiagnosticHandler, emitDiagnostic } from "../diagnostics.ts";
import { TurnConflictError } from "../utils/errors.ts";
import { EventProcessor } from "./event-processor.ts";
import type { EventSink } from "./event-sink.ts";

/** What a completed turn reports back to the caller (in addition to the streamed events). */
export interface RunSummary {
	sessionId: string;
	turnId: string;
	harness: AgentHarness;
	/** Native session/thread id to persist for a future resume. */
	nativeSessionId?: string;
	/** When the turn requested a resume: whether the harness honored it. */
	resumed?: boolean;
	usage: TokenUsage;
	/** Normalized terminal status (same value as the `turn.ended` event). */
	stopReason: StopReason;
	finishReason?: string;
	cost?: number;
	error?: { category: ErrorCategory; message: string };
	cancelled: boolean;
}

/**
 * How `run()` would treat a request: execute it (`new`), or converge a retry
 * onto an already-admitted identical turn (`inflight` / `completed`).
 */
export type TurnAdmission =
	| { status: "new" }
	| { status: "inflight" }
	| { status: "completed"; summary: RunSummary };

/**
 * Deterministic JSON with sorted object keys and dropped `undefined` members —
 * the identity of a turn's input for idempotent admission. Pure JS (no
 * node:crypto): this module is part of the isolate-safe edge graph.
 */
function canonicalJson(value: unknown): string {
	if (value === null || typeof value !== "object") return JSON.stringify(value) ?? '"undefined"';
	if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
	const entries = Object.entries(value as Record<string, unknown>)
		.filter(([, v]) => v !== undefined)
		.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
		.map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`);
	return `{${entries.join(",")}}`;
}

// `:` cannot appear in either UUID, so the key is collision-free.
const turnKeyOf = (sessionId: string, turnId: string) => `${sessionId}:${turnId}`;
const inputKeyOf = (request: RunRequest) =>
	canonicalJson({ input: request.input, config: request.config });

/** The standard options offered for every brokered permission request (§6.4:
 * the broker must actually offer the `*_always` kinds the schema advertises —
 * a "don't ask again" answer becomes a standing per-session rule). */
const PERMISSION_OPTIONS: PermissionOption[] = [
	{ optionId: "allow", name: "Allow", kind: "allow_once" },
	{ optionId: "allow_always", name: "Always allow", kind: "allow_always" },
	{ optionId: "reject", name: "Reject", kind: "reject_once" },
	{ optionId: "reject_always", name: "Always reject", kind: "reject_always" },
];

interface PendingPermission {
	sessionId: string;
	/** Resolves the request and emits `permission.resolved`; await the returned
	 * promise to order that emit (the turn-end drain does, so it lands before
	 * `turn.ended`). */
	settle: (outcome: PermissionOutcome) => void | Promise<void>;
}

/**
 * The engine. Owns no transport and no harness specifics: it routes a
 * RunRequest to the right harness + adapter, drives the per-turn loop, brokers
 * permission round-trips, and streams normalized LifecycleEvents to a sink.
 */
export class AgentRuntime {
	/** Permission requests awaiting `respondPermission`, across all live turns. */
	private readonly pendingPermissions = new Map<string, PendingPermission>();
	/** Standing per-session `*_always` answers: sessionId -> toolName -> verdict. */
	private readonly alwaysDecisions = new Map<string, Map<string, "allow" | "deny">>();
	private readonly activeRuns = new Set<Promise<RunSummary>>();
	/** In-flight turns by turn key — the convergence target for retried runs. */
	private readonly inflightTurns = new Map<
		string,
		{ inputKey: string; promise: Promise<RunSummary> }
	>();
	/** Recently completed turns per session (bounded LRU) — retries converge on the stored summary. */
	private readonly completedTurns = new Map<
		string,
		Map<string, { inputKey: string; summary: RunSummary }>
	>();
	/** Per-session convergence window; old turns fall out and a stale retry would re-execute. */
	private static readonly COMPLETED_TURN_MEMORY = 16;
	private shutdownPromise?: Promise<void>;

	constructor(
		private readonly registry: AgentRegistry,
		private readonly options: { onDiagnostic?: DiagnosticHandler } = {},
	) {}

	get harnesses(): AgentHarness[] {
		return this.registry.list();
	}

	capabilities(harness: AgentHarness): AgentCapabilities {
		return this.registry.getAgent(harness).capabilities;
	}

	/**
	 * Answer a pending `permission.requested` event. Returns false when the
	 * request is unknown (already resolved, cancelled, or a sessionId mismatch).
	 */
	respondPermission(sessionId: string, requestId: string, outcome: PermissionOutcome): boolean {
		const pending = this.pendingPermissions.get(requestId);
		if (!pending || pending.sessionId !== sessionId) return false;
		void pending.settle(outcome);
		return true;
	}

	/**
	 * Probe how `run()` would admit this request WITHOUT executing anything:
	 * `new` (would run), `inflight`/`completed` (an identical request was
	 * already admitted — a retry must converge, not re-execute). Throws
	 * `TurnConflictError` when this turnId was admitted with DIFFERENT input.
	 * Wire seats use this to quick-ack a duplicate instead of starting it.
	 */
	admission(request: RunRequest): TurnAdmission {
		const inflight = this.inflightTurns.get(turnKeyOf(request.sessionId, request.turnId));
		if (inflight) {
			if (inflight.inputKey !== inputKeyOf(request)) {
				throw new TurnConflictError(request.sessionId, request.turnId);
			}
			return { status: "inflight" };
		}
		const done = this.completedTurns.get(request.sessionId)?.get(request.turnId);
		if (done) {
			if (done.inputKey !== inputKeyOf(request)) {
				throw new TurnConflictError(request.sessionId, request.turnId);
			}
			return { status: "completed", summary: done.summary };
		}
		return { status: "new" };
	}

	run(
		request: RunRequest,
		sink: EventSink,
		opts: { signal?: AbortSignal } = {},
	): Promise<RunSummary> {
		if (this.shutdownPromise) return Promise.reject(new Error("agent runtime is shutting down"));
		// Idempotent admission (the embed-tier guard a retried DO RPC needs): a
		// duplicate {sessionId, turnId} with identical input converges on the
		// original run — the in-flight promise or the memoized summary — and is
		// never executed twice. The retry's sink receives no events; the first
		// delivery (or a wire-tier replay) owns those. Same ids with different
		// input is a caller bug, surfaced loudly instead of silently re-running.
		let admission: TurnAdmission;
		try {
			admission = this.admission(request);
		} catch (error) {
			return Promise.reject(error);
		}
		if (admission.status === "completed") return Promise.resolve(admission.summary);
		const turnKey = turnKeyOf(request.sessionId, request.turnId);
		if (admission.status === "inflight") {
			// Settled between probe and read (memoized now) → recurse converges.
			return this.inflightTurns.get(turnKey)?.promise ?? this.run(request, sink, opts);
		}
		const inputKey = inputKeyOf(request);
		// Deferred one microtask so the admission maps are registered BEFORE the
		// turn emits anything: a synchronous sink that reenters run() from
		// turn.started must converge, not double-execute.
		const running = Promise.resolve().then(() => this.executeRun(request, sink, opts));
		this.inflightTurns.set(turnKey, { inputKey, promise: running });
		this.activeRuns.add(running);
		// One handler, not a .finally chain: the inflight→completed transition
		// must be atomic within a single microtask, or a concurrent admission
		// probe could observe the settled turn as still inflight.
		running.then(
			(summary) => {
				this.rememberTurn(request.sessionId, request.turnId, inputKey, summary);
				this.inflightTurns.delete(turnKey);
				this.activeRuns.delete(running);
			},
			// A rejected run is NOT memoized: it died before executing the turn
			// loop (registry/setup), so a retry is allowed to try again.
			() => {
				this.inflightTurns.delete(turnKey);
				this.activeRuns.delete(running);
			},
		);
		return running;
	}

	private rememberTurn(
		sessionId: string,
		turnId: string,
		inputKey: string,
		summary: RunSummary,
	): void {
		let perSession = this.completedTurns.get(sessionId);
		if (!perSession) {
			perSession = new Map();
			this.completedTurns.set(sessionId, perSession);
		}
		perSession.set(turnId, { inputKey, summary });
		while (perSession.size > AgentRuntime.COMPLETED_TURN_MEMORY) {
			const oldest = perSession.keys().next().value;
			if (oldest === undefined) break;
			perSession.delete(oldest);
		}
	}

	private async executeRun(
		request: RunRequest,
		sink: EventSink,
		opts: { signal?: AbortSignal },
	): Promise<RunSummary> {
		const { sessionId, turnId, input, config } = request;
		const agent = this.registry.getAgent(config.harness);
		const transformer = this.registry.getAdapter(config.harness)({ sessionId });
		const processor = new EventProcessor(sessionId, turnId, {
			harness: config.harness,
			model: config.model,
		});

		// Isolate sink failures: a misbehaving transport must never break the
		// turn's lifecycle bracketing (turn.started ... turn.ended).
		const emit = async (e: LifecycleEvent) => {
			try {
				await sink.emit(e);
			} catch (err) {
				// The turn must not fail on a misbehaving sink — but the host gets
				// to know its sink dropped an event.
				emitDiagnostic(this.options.onDiagnostic, {
					type: "sinkError",
					sessionId,
					message: `sink emit failed for ${e.type}: ${err instanceof Error ? err.message : String(err)}`,
					detail: err,
				});
			}
		};

		let nativeSessionId: string | undefined;
		let resumed: boolean | undefined;
		let sessionEmitted = false;
		const flushSession = async () => {
			if (nativeSessionId && !sessionEmitted) {
				sessionEmitted = true;
				await emit({
					type: "session.created",
					sessionId,
					nativeSessionId,
					harness: config.harness,
					model: config.model,
					...(resumed !== undefined && { resumed }),
					timestamp: Date.now(),
				});
			}
		};

		// --- permission broker (one scope per turn) ----------------------------
		const turnRequestIds = new Set<string>();
		/** Every settle()'s `permission.resolved` emission, whichever caller
		 * settled it (broker answer, external respondPermission, cancel) — the
		 * turn-end drain awaits these so `turn.ended` NEVER starts before a
		 * resolved emission completed. */
		const settleEmits: Array<Promise<void> | void> = [];
		const requestPermission = async (
			toolCall: PermissionToolCall,
			permOpts?: { signal?: AbortSignal },
		): Promise<PermissionDecision> => {
			if (permOpts?.signal?.aborted) return { decision: "cancel" };
			// A standing `*_always` rule from an earlier prompt in this session
			// answers without a round-trip (and without fake prompt events). The
			// rule carries the verdict only — an `updatedInput` edit belongs to the
			// call it was made for, never to every later call to the same tool.
			const standing = this.alwaysDecisions.get(sessionId)?.get(toolCall.toolName);
			if (standing) {
				return standing === "allow"
					? { decision: "allow" }
					: { decision: "deny", reason: "Denied by a standing rule" };
			}
			const requestId = generateUUIDv7();
			// Register BEFORE emitting so even a sink that answers synchronously
			// from its emit() finds the pending entry.
			let resolveOutcome!: (o: PermissionOutcome) => void;
			const outcomePromise = new Promise<PermissionOutcome>((resolve) => {
				resolveOutcome = resolve;
			});
			const settle = (o: PermissionOutcome): Promise<void> | void => {
				if (!this.pendingPermissions.delete(requestId)) return;
				turnRequestIds.delete(requestId);
				resolveOutcome(o);
				// Recorded so the in-run drain sequences it before turn.ended no
				// matter WHO settled (broker, respondPermission, cancel) — external
				// callers themselves ignore the returned promise.
				const emitted = emit({
					type: "permission.resolved",
					sessionId,
					turnId,
					requestId,
					outcome: o,
					timestamp: Date.now(),
				});
				settleEmits.push(emitted);
				return emitted;
			};
			this.pendingPermissions.set(requestId, { sessionId, settle });
			turnRequestIds.add(requestId);
			permOpts?.signal?.addEventListener("abort", () => void settle({ outcome: "cancelled" }), {
				once: true,
			});
			await emit({
				type: "permission.requested",
				sessionId,
				turnId,
				requestId,
				title: toolCall.title ?? `Allow tool: ${toolCall.toolName}`,
				toolCall,
				options: PERMISSION_OPTIONS,
				timestamp: Date.now(),
			});
			const outcome = await outcomePromise;
			if (outcome.outcome === "cancelled") return { decision: "cancel" };
			const selected = PERMISSION_OPTIONS.find((o) => o.optionId === outcome.optionId);
			const allowed = selected?.kind === "allow_once" || selected?.kind === "allow_always";
			// An `*_always` answer becomes a standing per-session rule: later calls
			// to the same tool skip the round-trip entirely (the user already gave
			// a durable answer — re-asking would be noise, re-emitting events would
			// fake a prompt that never happened). Cleared on session close.
			if (selected?.kind === "allow_always" || selected?.kind === "reject_always") {
				let rules = this.alwaysDecisions.get(sessionId);
				if (!rules) {
					rules = new Map();
					this.alwaysDecisions.set(sessionId, rules);
				}
				rules.set(toolCall.toolName, allowed ? "allow" : "deny");
			}
			return allowed
				? {
						decision: "allow",
						// What was approved is what runs (C1): an edited input replaces
						// the original all the way into the harness.
						...(outcome.updatedInput !== undefined && { updatedInput: outcome.updatedInput }),
					}
				: { decision: "deny", reason: "Denied by user" };
		};
		/** Cancellation / turn end resolves everything still pending as cancelled.
		 * Awaited so every `permission.resolved` is emitted before `turn.ended`. */
		const drainPermissions = async () => {
			const settles = [...turnRequestIds].map((requestId) =>
				this.pendingPermissions.get(requestId)?.settle({ outcome: "cancelled" }),
			);
			// Also the already-settled requests whose resolved emission is still in
			// flight (settle() removed them from the pending map immediately).
			await Promise.all([...settles, ...settleEmits]);
		};

		await emit({ type: "turn.started", turnId, sessionId, timestamp: Date.now() });

		// The user echo (spec §7.2): the submitted input goes back onto the stream
		// as a complete user message (outputIndex 0) before any harness output, so
		// the stream is a complete transcript and multi-client attach works.
		for (const le of processor.echoUserMessage(createUserEchoParts(input))) await emit(le);

		const options: AgentExecuteOptions = {
			sessionId,
			turnId,
			cwd: config.cwd,
			model: config.model,
			thinkingLevel: config.thinkingLevel,
			permissionMode: config.permissionMode,
			maxTurns: config.maxTurns,
			systemPromptAppend: config.systemPromptAppend,
			resumeSessionId: config.resumeSessionId,
			resumeSessionAt: config.resumeSessionAt,
			additionalDirectories: config.additionalDirectories,
			mcpServers: config.mcpServers,
			env: config.env,
			apiKey: config.apiKey,
			disableTools: config.disableTools,
			signal: opts.signal,
			onNativeSession: (id, info) => {
				// Agents report exactly once per turn (the claude fallback defers its
				// report until the surviving session is known); guard against a
				// misbehaving harness re-reporting after emission. Agents always pass
				// their honest `resumed` judgment — the runtime surfaces it only when
				// this turn actually REQUESTED a resume.
				if (sessionEmitted) return;
				nativeSessionId = id;
				if (config.resumeSessionId && info?.resumed !== undefined) resumed = info.resumed;
			},
			onPermissionRequest: requestPermission,
		};

		let cancelled = false;
		let errored: { category: ErrorCategory; message: string } | undefined;

		try {
			for await (const raw of agent.execute(input, options)) {
				await flushSession();
				if (config.includeRaw) {
					await emit({
						type: "raw",
						sessionId,
						turnId,
						harness: config.harness,
						data: raw,
						timestamp: Date.now(),
					});
				}
				for (const ae of transformer.process(raw)) {
					for (const le of processor.handle(ae)) await emit(le);
				}
			}
			await flushSession();
		} catch (err) {
			cancelled = isCancellation(err);
			if (!cancelled) {
				const category = classifyError(err);
				const message = err instanceof Error ? err.message : String(err);
				errored = { category, message };
				await emit({
					type: "error",
					turnId,
					sessionId,
					category,
					message,
					recoverable: isRecoverable(category),
					stack: err instanceof Error ? err.stack : undefined,
					timestamp: Date.now(),
				});
			}
		} finally {
			await drainPermissions();
		}

		const result = transformer.finish();
		cancelled = cancelled || Boolean(result.cancelled);
		if (result.error && !errored && !cancelled) {
			errored = { category: classifyError(new Error(result.error)), message: result.error };
		}
		const stopReason: StopReason = cancelled
			? "cancelled"
			: errored
				? "error"
				: (result.stopReason ?? "end_turn");
		const terminalResult =
			errored && !result.error ? { ...result, error: errored.message } : result;
		for (const le of processor.finish(terminalResult, stopReason)) await emit(le);

		return {
			sessionId,
			turnId,
			harness: config.harness,
			nativeSessionId,
			...(resumed !== undefined && { resumed }),
			usage: result.usage ?? DEFAULT_TOKEN_USAGE,
			stopReason,
			finishReason: result.finishReason,
			cost: result.cost,
			error: errored,
			cancelled,
		};
	}

	/**
	 * Cancel the session's in-flight turn. An idle session is a clean no-op ack
	 * (`{confirmed: true, hadTurn: false}`); `confirmed: false` means a turn
	 * existed but the harness did not acknowledge the interrupt — the agent may
	 * still be running; `turn.ended` remains the source of truth.
	 */
	async cancel(harness: AgentHarness, sessionId: string): Promise<CancelResult> {
		// Unblock any harness parked on an approval before (and regardless of)
		// the agent-level abort. `settle` removes the entry from the map itself.
		for (const pending of [...this.pendingPermissions.values()]) {
			if (pending.sessionId === sessionId) void pending.settle({ outcome: "cancelled" });
		}
		return await this.registry.getAgent(harness).cancel(sessionId);
	}

	/** Dispose one idle logical session and its harness-native resources. */
	async closeSession(harness: AgentHarness, sessionId: string): Promise<void> {
		this.completedTurns.delete(sessionId);
		this.alwaysDecisions.delete(sessionId);
		await Promise.all(
			[...this.pendingPermissions.values()]
				.filter((pending) => pending.sessionId === sessionId)
				.map((pending) => pending.settle({ outcome: "cancelled" })),
		);
		const agent = this.registry.getAgent(harness);
		if (agent.release) await agent.release(sessionId);
		else await agent.cancel(sessionId);
	}

	/** Give up on stragglers after this long; the process is exiting anyway. */
	private static readonly DEFAULT_DRAIN_TIMEOUT_MS = 10_000;

	shutdown(opts: { drainTimeoutMs?: number } = {}): Promise<void> {
		// Memoized: the first caller's timeout wins.
		this.shutdownPromise ??= this.performShutdown(
			opts.drainTimeoutMs ?? AgentRuntime.DEFAULT_DRAIN_TIMEOUT_MS,
		);
		return this.shutdownPromise;
	}

	private async performShutdown(drainTimeoutMs: number): Promise<void> {
		await Promise.all(
			[...this.pendingPermissions.values()].map((pending) =>
				pending.settle({ outcome: "cancelled" }),
			),
		);
		this.pendingPermissions.clear();
		let terminationError: unknown;
		try {
			await this.registry.terminateAll();
		} catch (error) {
			terminationError = error;
		}
		// Drain active runs, but don't let a harness that ignores its abort
		// signal hang the process's shutdown forever.
		await Promise.race([
			Promise.allSettled([...this.activeRuns]),
			new Promise<void>((resolve) => {
				const timer = setTimeout(resolve, drainTimeoutMs);
				timer.unref?.();
			}),
		]);
		this.completedTurns.clear();
		if (terminationError !== undefined) throw terminationError;
	}
}
