import type { AgentHarness, LifecycleEvent, WireEventEnvelope } from "../protocol/index.ts";

export const DEFAULT_BUFFER_SIZE = 4096;

/**
 * Per-session monotonic sequence + bounded replay buffer (DESIGN D7). Every
 * outbound event is stamped with `seq` (starting at 1) and kept in a ring
 * buffer so a reconnecting client can `events/replay({fromSeq})`. Eviction is
 * visible to clients via `firstAvailableSeq`.
 *
 * Eviction advances a head index (O(1) amortized) instead of shifting the
 * array; the dead prefix is compacted away once it reaches one full capacity,
 * bounding memory at ~2x `maxBuffer` envelopes.
 */
export class SessionLog {
	private buffer: WireEventEnvelope[] = [];
	private head = 0;
	private nextSeq: number;
	private readonly maxBuffer: number;

	constructor(
		readonly sessionId: string,
		/** The harness this session is bound to (first turn wins). */
		readonly harness: AgentHarness,
		maxBuffer = DEFAULT_BUFFER_SIZE,
		/** First seq to assign — a session reused after `session/close` continues
		 * where its previous incarnation stopped, so peers never see seq go
		 * backwards (a backwards seq reads as a duplicate and masks event loss). */
		startSeq = 1,
	) {
		// A NaN or non-positive cap would silently disable eviction and grow
		// the buffer without bound — normalize rather than trust the caller.
		this.maxBuffer = Number.isInteger(maxBuffer) && maxBuffer > 0 ? maxBuffer : DEFAULT_BUFFER_SIZE;
		this.nextSeq = Number.isInteger(startSeq) && startSeq > 0 ? startSeq : 1;
	}

	append(event: LifecycleEvent): WireEventEnvelope {
		const envelope: WireEventEnvelope = { sessionId: this.sessionId, seq: this.nextSeq++, event };
		this.buffer.push(envelope);
		if (this.buffer.length - this.head > this.maxBuffer) {
			this.head += 1;
			if (this.head >= this.maxBuffer) {
				this.buffer = this.buffer.slice(this.head);
				this.head = 0;
			}
		}
		return envelope;
	}

	/** Buffered envelopes with `seq >= fromSeq` (seq is contiguous — index math). */
	replay(fromSeq: number): WireEventEnvelope[] {
		const first = this.firstAvailableSeq;
		if (first === null) return [];
		return this.buffer.slice(this.head + Math.max(0, fromSeq - first));
	}

	/** Oldest seq still buffered, or null when nothing has been emitted. */
	get firstAvailableSeq(): number | null {
		return this.buffer[this.head]?.seq ?? null;
	}

	/** Newest seq assigned, or null when nothing has been emitted. */
	get latestSeq(): number | null {
		return this.nextSeq > 1 ? this.nextSeq - 1 : null;
	}
}
