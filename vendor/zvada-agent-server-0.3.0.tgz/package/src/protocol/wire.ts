import { z } from "zod";
import { RunConfigSchema } from "./config.ts";
import { AgentCapabilitiesSchema } from "./harness.ts";
import {
	type DecodedLifecycleEvent,
	LifecycleEventSchema,
	PermissionOutcomeSchema,
	type UnknownEvent,
	decodeLifecycleEvent,
} from "./lifecycle.ts";
import { AgentInputSchema } from "./part-input.ts";

/**
 * The standard wire (phase 2): JSON-RPC 2.0 over a newline-delimited JSON
 * stream (stdio, WebSocket, or any duplex byte channel). Requests flow
 * client -> server only; the server pushes `event` notifications. Turns are
 * quick-ack: `turn/start` acknowledges immediately and completion is observed
 * via the `turn.ended` lifecycle event, mirroring the engine's event-driven
 * model (and ACP v2's prompt lifecycle).
 */
export const WIRE_PROTOCOL_VERSION = 2;

// ---- JSON-RPC 2.0 envelopes --------------------------------------------------

export const JsonRpcIdSchema = z.union([z.string(), z.number()]);
export type JsonRpcId = z.infer<typeof JsonRpcIdSchema>;

export const JsonRpcErrorSchema = z.object({
	code: z.number().int(),
	message: z.string(),
	data: z.unknown().optional(),
});
export type JsonRpcError = z.infer<typeof JsonRpcErrorSchema>;

/** JSON-RPC error codes used on this wire (standard + implementation range). */
export const WIRE_ERROR_CODES = {
	parseError: -32700,
	invalidRequest: -32600,
	methodNotFound: -32601,
	invalidParams: -32602,
	internalError: -32603,
	/** `config.harness` is not registered/available in this server process. */
	harnessNotAvailable: -32000,
	/** The sessionId is unknown to this server process (e.g. it restarted). */
	unknownSession: -32001,
	/** The session already has an active turn — one turn per session at a time. */
	turnActive: -32002,
	/** The server is shutting down and no longer accepts turns. */
	shuttingDown: -32003,
	/** The peer requested a wire version this implementation cannot speak. */
	protocolVersionMismatch: -32004,
	/** A session/close for this session is still in flight; retry after it settles. */
	sessionClosing: -32005,
	/** A turn with this turnId already ran (or is running) with DIFFERENT input. */
	turnConflict: -32006,
} as const;

// ---- methods -----------------------------------------------------------------

export const WIRE_METHODS = {
	initialize: "initialize",
	turnStart: "turn/start",
	turnCancel: "turn/cancel",
	sessionClose: "session/close",
	permissionRespond: "permission/respond",
	eventsReplay: "events/replay",
	shutdown: "shutdown",
	/** Server -> client notification carrying one sequenced lifecycle event. */
	event: "event",
} as const;
export type WireMethod = (typeof WIRE_METHODS)[keyof typeof WIRE_METHODS];

export const WireImplementationInfoSchema = z.object({
	name: z.string(),
	version: z.string().optional(),
});
export type WireImplementationInfo = z.infer<typeof WireImplementationInfoSchema>;

export const InitializeParamsSchema = z.object({
	protocolVersion: z.number().int().positive(),
	client: WireImplementationInfoSchema.optional(),
});
export type InitializeParams = z.infer<typeof InitializeParamsSchema>;

export const InitializeResultSchema = z.object({
	protocolVersion: z.number().int().positive(),
	server: WireImplementationInfoSchema,
	/**
	 * Minted once per server PROCESS. A reconnecting client re-initializes and
	 * compares: a changed id means every session log it was tracking belongs to
	 * a dead process — adopt the fresh logs (reset cursors, resync) instead of
	 * inferring the restart from seq patterns. The handshake STATES the one
	 * fact four downstream heuristics used to guess.
	 */
	instanceId: z.string(),
	/** Capabilities per registered harness — only available harnesses appear. */
	harnesses: z.record(z.string(), AgentCapabilitiesSchema),
});
export type InitializeResult = z.infer<typeof InitializeResultSchema>;

/**
 * `turn/start` params are a RunRequest whose ids may be omitted — the server
 * mints UUIDv7s for missing ones and echoes the effective ids in the ack.
 * (The bundled client always mints ids itself so it can route events that
 * arrive before the ack's promise continuation runs.)
 */
export const TurnStartParamsSchema = z.object({
	sessionId: z.string().min(1).optional(),
	turnId: z.string().min(1).optional(),
	input: AgentInputSchema,
	config: RunConfigSchema,
});
export type TurnStartParams = z.infer<typeof TurnStartParamsSchema>;

/** Quick-ack: the turn is accepted and running; completion = `turn.ended`. */
export const TurnStartResultSchema = z.object({
	sessionId: z.string(),
	turnId: z.string(),
	/**
	 * The request converged onto an already-admitted turn with the same turnId
	 * and identical input (a retried `turn/start` after a lost ack). No second
	 * execution happened; catch up on its events via `events/replay`.
	 */
	deduplicated: z.boolean().optional(),
});
export type TurnStartResult = z.infer<typeof TurnStartResultSchema>;

export const TurnCancelParamsSchema = z.object({
	sessionId: z.string().min(1),
	/**
	 * Cancel only if THIS turn is the active one — a late cancel meant for a
	 * finished turn must not kill its successor. Omitted = session-scoped
	 * cancel of whatever is active (legacy behavior). Empty ids are rejected
	 * rather than silently treated as unstamped.
	 */
	turnId: z.string().min(1).optional(),
});
export type TurnCancelParams = z.infer<typeof TurnCancelParamsSchema>;

/**
 * Single-outcome cancel result (replaces the 0.2 two-boolean shape whose
 * combinations included illegal states):
 *  - `cancelled`      — the harness confirmed the interrupt.
 *  - `unconfirmed`    — best-effort dispatched but unacknowledged; the agent
 *    process may still be running and the turn's `turn.ended` remains the
 *    source of truth.
 *  - `no_active_turn` — nothing to cancel: the session had no active turn, or
 *    `turnId` was given and a DIFFERENT turn is active (see `activeTurnId`).
 */
export const TurnCancelResultSchema = z.discriminatedUnion("outcome", [
	z.object({ outcome: z.literal("cancelled"), turnId: z.string() }),
	z.object({ outcome: z.literal("unconfirmed"), turnId: z.string() }),
	z.object({ outcome: z.literal("no_active_turn"), activeTurnId: z.string().optional() }),
]);
export type TurnCancelResult = z.infer<typeof TurnCancelResultSchema>;

export const SessionCloseParamsSchema = z.object({ sessionId: z.string() });
export type SessionCloseParams = z.infer<typeof SessionCloseParamsSchema>;

/** `closed: false` means the server did not know the session (idempotent). */
export const SessionCloseResultSchema = z.object({ closed: z.boolean() });
export type SessionCloseResult = z.infer<typeof SessionCloseResultSchema>;

export const PermissionRespondParamsSchema = z.object({
	sessionId: z.string(),
	requestId: z.string(),
	outcome: PermissionOutcomeSchema,
});
export type PermissionRespondParams = z.infer<typeof PermissionRespondParamsSchema>;

/** `accepted: false` means the request was unknown or already resolved. */
export const PermissionRespondResultSchema = z.object({ accepted: z.boolean() });
export type PermissionRespondResult = z.infer<typeof PermissionRespondResultSchema>;

/**
 * One sequenced event as broadcast on the wire. `seq` is per-session,
 * monotonic, and starts at 1 — a client that has seen nothing replays from 1.
 * The envelope duplicates `sessionId` so consumers can route without parsing
 * the event body.
 */
export const WireEventEnvelopeSchema = z.object({
	sessionId: z.string(),
	seq: z.number().int().positive(),
	event: LifecycleEventSchema,
});
export type WireEventEnvelope = z.infer<typeof WireEventEnvelopeSchema>;

/** The routing fields of an envelope — strict, because the wire owns them. */
const WireEventEnvelopeHeaderSchema = z.object({
	sessionId: z.string(),
	seq: z.number().int().positive(),
});

/** An envelope whose event was decoded the Law-6 way (unknowns preserved). */
export interface DecodedWireEventEnvelope {
	sessionId: string;
	seq: number;
	event: DecodedLifecycleEvent | UnknownEvent;
}

/**
 * Decode one `event` notification: envelope strict, event lenient. A consumer
 * that instead drops an unknown event type does not degrade gracefully — it
 * leaves a hole where a `seq` was, and every seq-tracking client then reads
 * the next event as an unfillable gap.
 */
export function decodeWireEventEnvelope(value: unknown): DecodedWireEventEnvelope {
	const header = WireEventEnvelopeHeaderSchema.parse(value);
	return {
		sessionId: header.sessionId,
		seq: header.seq,
		event: decodeLifecycleEvent((value as { event?: unknown }).event),
	};
}

/** `events/replay` with its envelopes decoded leniently. */
export interface DecodedEventsReplayResult {
	events: DecodedWireEventEnvelope[];
	firstAvailableSeq: number | null;
	latestSeq: number | null;
}

/**
 * The replay result, decoded envelope-by-envelope. `EventsReplayResultSchema`
 * embeds the CLOSED event union, so parsing a buffer with it makes one unknown
 * event type poison the whole replay — the healing path for a gap must not be
 * the thing that cannot survive an unknown.
 */
export function decodeEventsReplayResult(value: unknown): DecodedEventsReplayResult {
	const parsed = z
		.object({
			events: z.array(z.unknown()),
			firstAvailableSeq: z.number().int().positive().nullable(),
			latestSeq: z.number().int().positive().nullable(),
		})
		.parse(value);
	return { ...parsed, events: parsed.events.map((event) => decodeWireEventEnvelope(event)) };
}

export const EventsReplayParamsSchema = z.object({
	sessionId: z.string(),
	/** Replay buffered events with `seq >= fromSeq`. */
	fromSeq: z.number().int().positive(),
});
export type EventsReplayParams = z.infer<typeof EventsReplayParamsSchema>;

/**
 * Replay is served from a bounded per-session ring buffer. When
 * `firstAvailableSeq > fromSeq`, the requested prefix was evicted and the gap
 * is unfillable — the consumer must treat its local view as stale.
 */
export const EventsReplayResultSchema = z.object({
	events: z.array(WireEventEnvelopeSchema),
	firstAvailableSeq: z.number().int().positive().nullable(),
	latestSeq: z.number().int().positive().nullable(),
});
export type EventsReplayResult = z.infer<typeof EventsReplayResultSchema>;

export const ShutdownParamsSchema = z.object({}).optional();
export const ShutdownResultSchema = z.object({});

// ---- codec -------------------------------------------------------------------

/** A decoded incoming wire line, discriminated for dispatch. */
export type WireMessage =
	| { kind: "request"; id: JsonRpcId; method: string; params?: unknown }
	| { kind: "notification"; method: string; params?: unknown }
	/** `id` is null on protocol-level errors answering unparseable requests. */
	| { kind: "response"; id: JsonRpcId | null; result?: unknown; error?: JsonRpcError }
	| { kind: "invalid"; error: string };

/** Decode one NDJSON line into a JSON-RPC message (never throws). */
export function decodeWireMessage(line: string): WireMessage {
	let raw: unknown;
	try {
		raw = JSON.parse(line);
	} catch {
		return { kind: "invalid", error: "not valid JSON" };
	}
	if (typeof raw !== "object" || raw === null || Array.isArray(raw)) {
		return { kind: "invalid", error: "not a JSON-RPC object" };
	}
	const msg = raw as Record<string, unknown>;
	if (msg.jsonrpc !== "2.0") return { kind: "invalid", error: "missing jsonrpc: '2.0'" };
	const id = JsonRpcIdSchema.safeParse(msg.id);
	if (typeof msg.method === "string") {
		return id.success
			? { kind: "request", id: id.data, method: msg.method, params: msg.params }
			: { kind: "notification", method: msg.method, params: msg.params };
	}
	if ((id.success || msg.id === null) && ("result" in msg || "error" in msg)) {
		const error = JsonRpcErrorSchema.safeParse(msg.error);
		return {
			kind: "response",
			id: id.success ? id.data : null,
			result: msg.result,
			error: error.success ? error.data : undefined,
		};
	}
	return { kind: "invalid", error: "neither request, notification, nor response" };
}

export function encodeRequest(id: JsonRpcId, method: string, params?: unknown): string {
	return JSON.stringify({ jsonrpc: "2.0", id, method, params });
}

export function encodeNotification(method: string, params?: unknown): string {
	return JSON.stringify({ jsonrpc: "2.0", method, params });
}

export function encodeResponse(id: JsonRpcId, result: unknown): string {
	return JSON.stringify({ jsonrpc: "2.0", id, result });
}

export function encodeErrorResponse(
	id: JsonRpcId | null,
	code: number,
	message: string,
	data?: unknown,
): string {
	return JSON.stringify({ jsonrpc: "2.0", id, error: { code, message, data } });
}

// ---- transport port ----------------------------------------------------------

/**
 * A duplex line channel the wire runs over. Implementations exist for stdio,
 * WebSocket, and in-memory pairs (tests). Handlers registered after close are
 * never called; `send` after close is a silent no-op.
 */
export interface WireTransport {
	send(line: string): void;
	/** Register a line handler; returns an unsubscribe function. */
	onLine(handler: (line: string) => void): () => void;
	/** Register a close handler; returns an unsubscribe function. */
	onClose(handler: (reason?: string) => void): () => void;
	close(): void;
	readonly closed: boolean;
}

/**
 * Split an inbound transport message into NDJSON lines, defensively: peers
 * may batch several lines per frame, and WebSocket implementations deliver
 * text, Uint8Array, or ArrayBuffer depending on runtime. Blank lines are
 * skipped.
 */
export function pushNdjsonLines(push: (line: string) => void, data: unknown): void {
	let text: string;
	if (typeof data === "string") text = data;
	else if (data instanceof Uint8Array) text = new TextDecoder().decode(data);
	else if (data instanceof ArrayBuffer) text = new TextDecoder().decode(new Uint8Array(data));
	else text = String(data);
	for (const line of text.split("\n")) if (line.trim()) push(line);
}

/**
 * Build a WireTransport from a raw byte-channel binding: the caller supplies
 * the outbound `send`/`close`, and pushes inbound lines / close through the
 * returned handles. Every concrete transport (stdio, WebSocket, memory pair)
 * is this bridge plus platform wiring.
 */
export function channelTransport(io: { send(line: string): void; close?(): void }): {
	transport: WireTransport;
	push(line: string): void;
	end(reason?: string): void;
} {
	const lineHandlers = new Set<(line: string) => void>();
	const closeHandlers = new Set<(reason?: string) => void>();
	let closed = false;

	const end = (reason?: string) => {
		if (closed) return;
		closed = true;
		for (const handler of [...closeHandlers]) handler(reason);
		lineHandlers.clear();
		closeHandlers.clear();
	};

	const transport: WireTransport = {
		send(line) {
			if (!closed) io.send(line);
		},
		onLine(handler) {
			lineHandlers.add(handler);
			return () => lineHandlers.delete(handler);
		},
		onClose(handler) {
			closeHandlers.add(handler);
			return () => closeHandlers.delete(handler);
		},
		close() {
			if (closed) return;
			io.close?.();
			end("closed locally");
		},
		get closed() {
			return closed;
		},
	};

	return {
		transport,
		push(line) {
			if (closed) return;
			for (const handler of [...lineHandlers]) handler(line);
		},
		end,
	};
}
