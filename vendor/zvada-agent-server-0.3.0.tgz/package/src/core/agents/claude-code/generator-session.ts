import type { Query as CCQuery, SDKMessage, SDKUserMessage } from "@anthropic-ai/claude-agent-sdk";
import type {
	Options as CCOptions,
	CanUseTool,
	McpSetServersResult,
	PermissionResult,
	PermissionUpdate,
} from "@anthropic-ai/claude-agent-sdk";
import { AsyncQueue } from "../../../protocol/index.ts";
import type { McpServerConfig } from "../../../protocol/index.ts";
import type { PermissionRequestHandler } from "../base.ts";
import { claudeToolMeta } from "../tool-meta.ts";
import {
	type ClaudeSdkOptionOverrides,
	type ClaudeSessionConfig,
	type SdkMcpServers,
	buildClaudeOptions,
} from "./options.ts";

/**
 * Pre-broker tool policy: the host's programmatic say on every tool call
 * BEFORE the interactive permission broker. Returns the SDK's own
 * `PermissionResult` (so hosts keep full native power: `updatedInput`,
 * `updatedPermissions`) or undefined to fall through to the broker.
 * Operator embed-tier only — never wire-sourced.
 */
export type ClaudeToolPolicy = (
	toolName: string,
	input: Record<string, unknown>,
	ctx: {
		sessionId: string;
		toolUseId: string;
		agentId?: string;
		/** Aborts when the turn is cancelled — a policy that waits on a remote approval must race this. */
		signal: AbortSignal;
		/** SDK permission-update suggestions; return them as `updatedPermissions` to honor an "always allow". */
		suggestions?: PermissionUpdate[];
		/** File path that triggered the request (e.g. access outside allowed directories). */
		blockedPath?: string;
		/** The SDK's explanation for why this permission request fired, when it gives one. */
		decisionReason?: string;
	},
) => PermissionResult | undefined | Promise<PermissionResult | undefined>;

/** SDK lifecycle hooks factory (decision-capable); runs once at session spawn. */
export type ClaudeHooksFactory = (ctx: {
	sessionId: string;
	currentTurnId: () => string | undefined;
}) => CCOptions["hooks"];

/** Embed-tier extras threaded from ClaudeCodeAgentOptions into each session. */
/** Why a live claude session's subprocess ended (see `onSessionEnd`). */
export type ClaudeSessionEndReason = "idle" | "replaced" | "released" | "shutdown";

export interface ClaudeSessionExtras {
	/** Factory for in-process MCP servers; invoked ONCE at session spawn. */
	sdkMcpServers?: (ctx: {
		sessionId: string;
		cwd: string;
	}) => SdkMcpServers | Promise<SdkMcpServers>;
	toolPolicy?: ClaudeToolPolicy;
	/** See ClaudeHooksFactory — a Stop hook may return `{decision: "block"}`. */
	hooks?: ClaudeHooksFactory;
	/**
	 * Operator escape hatch: raw SDK option overrides merged over the engine's
	 * options at session spawn (embed-tier only — never wire-sourced). The
	 * ClaudeSdkOptionOverrides type excludes engine-wired fields.
	 */
	sdkOptions?: (ctx: {
		sessionId: string;
		cwd: string;
	}) => ClaudeSdkOptionOverrides | Promise<ClaudeSdkOptionOverrides>;
}

type SessionState = "starting" | "idle" | "busy" | "terminated";
type ClaudeContent = SDKUserMessage["message"]["content"];

/** Per-turn handle: iterate `events` until the turn's `result` arrives (or the turn errors). */
export interface ClaudeEventTap {
	readonly events: AsyncIterable<SDKMessage>;
	detach(): void;
}

/**
 * Wraps one long-lived Claude `query()` call. The prompt input is an AsyncQueue
 * that stays open across turns, so the same subprocess (and its context) is
 * reused turn to turn. A background loop reads SDK output and routes it to the
 * current turn's tap; the `result` event marks the turn boundary.
 *
 * Lifecycle: starting → idle ⇄ busy → terminated.
 */
export class ClaudeGeneratorSession {
	private state: SessionState = "starting";
	private config: ClaudeSessionConfig;

	private readonly promptQueue = new AsyncQueue<SDKUserMessage>();
	private query: CCQuery | null = null;
	/** Set per turn (inside sendMessage, after the idle wait) for hook contexts. */
	currentTurnId?: string;
	/** Resolved once at spawn; re-merged into every hot-swap. */
	private sdkServers?: SdkMcpServers;
	private nativeSessionId: string | null = null;

	private currentTap: AsyncQueue<SDKMessage> | null = null;
	private readonly idleWaiters: Array<() => void> = [];

	/**
	 * The engine's permission broker for the CURRENT turn. Mutable because the
	 * SDK's `canUseTool` is fixed at spawn while the handler changes per turn
	 * (the long-lived query outlives any one run). Unset (e.g. a turn driven
	 * outside the runtime) auto-allows — mode-level gating still applies.
	 */
	permissionHandler?: PermissionRequestHandler;

	private idleTimer: ReturnType<typeof setTimeout> | null = null;
	private readonly idleTimeoutMs: number;

	constructor(
		readonly id: string,
		config: ClaudeSessionConfig,
		private readonly onTerminated?: (reason: ClaudeSessionEndReason) => void,
		private readonly extras?: ClaudeSessionExtras,
	) {
		this.config = { ...config };
		this.idleTimeoutMs = config.idleTimeoutMs ?? 5 * 60_000;
	}

	get currentState(): SessionState {
		return this.state;
	}
	get currentSessionId(): string | null {
		return this.nativeSessionId;
	}
	get currentConfig(): Readonly<ClaudeSessionConfig> {
		return this.config;
	}

	/** Hot-swap the model without losing context (Claude `setModel`). */
	async setModel(model: string | undefined): Promise<void> {
		if (this.state === "terminated" || !this.query) return;
		await this.query.setModel(model);
		this.config = { ...this.config, model };
	}

	/**
	 * Hot-swap the wire-configured MCP servers on the LIVE session (no restart,
	 * context intact). In-process servers are re-merged so a swap can never drop
	 * the host's own tools; `currentConfig` is synced so the next turn's
	 * hot-swap check doesn't re-apply.
	 */
	async setMcpServers(
		servers: Record<string, McpServerConfig>,
	): Promise<McpSetServersResult | undefined> {
		if (this.state === "terminated" || !this.query) return undefined;
		const result = await this.query.setMcpServers({ ...servers, ...this.sdkServers });
		const failed = Object.entries(result.errors ?? {});
		if (failed.length) {
			// Do NOT sync config: the fingerprint stays different, so the next
			// turn retries instead of reporting a failed set as attached.
			throw new Error(
				`mcp servers failed to connect: ${failed.map(([n, e]) => `${n} (${e})`).join(", ")}`,
			);
		}
		this.config = { ...this.config, mcpServers: servers };
		return result;
	}

	async start(): Promise<void> {
		if (this.state !== "starting") throw new Error(`Cannot start in state: ${this.state}`);
		const sdk = await import("@anthropic-ai/claude-agent-sdk");
		this.sdkServers = await this.extras?.sdkMcpServers?.({
			sessionId: this.id,
			cwd: this.config.cwd,
		});
		const options = buildClaudeOptions(
			this.config,
			this.sdkServers,
			await this.extras?.sdkOptions?.({ sessionId: this.id, cwd: this.config.cwd }),
		);
		if (this.extras?.hooks) {
			options.hooks = this.extras.hooks({
				sessionId: this.id,
				currentTurnId: () => this.currentTurnId,
			});
		}
		// Bridge the SDK's approval callback to the engine's permission broker.
		// The closure reads the mutable per-turn handler set by the agent.
		options.canUseTool = createCanUseTool({
			sessionId: this.id,
			policy: this.extras?.toolPolicy,
			getBroker: () => this.permissionHandler,
		});
		this.query = sdk.query({
			prompt: this.promptQueue as AsyncIterable<SDKUserMessage>,
			options,
		});
		void this.consumeEvents();
		this.state = "idle";
		this.resetIdleTimer();
	}

	/** Push a user message; returns a tap that streams this turn's events. */
	async sendMessage(content: ClaudeContent, turnId?: string): Promise<ClaudeEventTap> {
		while (this.state !== "idle") {
			if (this.state === "terminated") throw new Error("Session is terminated");
			await this.waitForIdle();
		}
		this.clearIdleTimer();
		this.state = "busy";
		// After the idle wait, so a queued turn can't relabel the in-flight one.
		this.currentTurnId = turnId;

		const tap = new AsyncQueue<SDKMessage>();
		this.currentTap = tap;
		this.promptQueue.push({
			type: "user",
			message: { role: "user", content },
			parent_tool_use_id: null,
			...(this.nativeSessionId ? { session_id: this.nativeSessionId } : {}),
		} as SDKUserMessage);

		return {
			events: tap,
			detach: () => {
				if (this.currentTap === tap) this.currentTap = null;
				tap.end();
			},
		};
	}

	/**
	 * Stop the in-flight turn without killing the session. Returns whether the
	 * interrupt was CONFIRMED: true when there was nothing to interrupt or the
	 * SDK acknowledged it; false when the round-trip timed out or failed — the
	 * subprocess may still be running its turn and the caller must report that
	 * honestly instead of assuming a clean cancel.
	 */
	async interruptTurn(timeoutMs = 2000): Promise<boolean> {
		if ((this.state !== "busy" && this.state !== "starting") || !this.query) return true;
		let timer: ReturnType<typeof setTimeout> | undefined;
		try {
			await Promise.race([
				this.query.interrupt(),
				new Promise<never>((_, reject) => {
					timer = setTimeout(() => reject(new Error("interrupt timeout")), timeoutMs);
				}),
			]);
			return true;
		} catch {
			return false; // best-effort dispatched, unconfirmed
		} finally {
			clearTimeout(timer); // the losing racer must not keep the loop alive
		}
	}

	async terminate(reason: ClaudeSessionEndReason = "released"): Promise<void> {
		if (this.state === "terminated") return;
		this.clearIdleTimer();
		this.state = "terminated";
		const query = this.query;
		this.query = null;
		this.promptQueue.end();
		this.currentTap?.end();
		this.currentTap = null;
		for (const w of this.idleWaiters) w();
		this.idleWaiters.length = 0;
		try {
			// The SDK documents close() as the forceful subprocess/MCP cleanup path.
			query?.close();
		} finally {
			try {
				this.onTerminated?.(reason);
			} catch {
				// Observer failures (incl. the host's onSessionEnd) must never make
				// terminate() reject — the idle timer calls it unawaited.
			}
		}
	}

	private async consumeEvents(): Promise<void> {
		if (!this.query) return;
		try {
			for await (const event of this.query) {
				if (event.type === "system" && event.subtype === "init" && event.session_id) {
					this.nativeSessionId = event.session_id;
				}
				this.currentTap?.push(event);
				if (event.type === "result") this.onTurnComplete();
			}
		} catch (err) {
			this.currentTap?.fail(err);
		} finally {
			await this.terminate();
		}
	}

	private onTurnComplete(): void {
		this.currentTap?.end();
		this.currentTap = null;
		this.state = "idle";
		this.resetIdleTimer();
		this.idleWaiters.shift()?.();
	}

	private waitForIdle(timeoutMs = 60_000): Promise<void> {
		return new Promise<void>((resolve, reject) => {
			if (this.state === "idle") return resolve();
			if (this.state === "terminated") return reject(new Error("terminated while waiting"));
			const timer = setTimeout(() => {
				const idx = this.idleWaiters.indexOf(onIdle);
				if (idx >= 0) this.idleWaiters.splice(idx, 1);
				reject(new Error("timeout waiting for idle"));
			}, timeoutMs);
			const onIdle = () => {
				clearTimeout(timer);
				resolve();
			};
			this.idleWaiters.push(onIdle);
		});
	}

	private resetIdleTimer(): void {
		this.clearIdleTimer();
		if (this.idleTimeoutMs > 0) {
			this.idleTimer = setTimeout(() => void this.terminate("idle"), this.idleTimeoutMs);
			this.idleTimer.unref?.();
		}
	}

	private clearIdleTimer(): void {
		if (this.idleTimer) {
			clearTimeout(this.idleTimer);
			this.idleTimer = null;
		}
	}
}

/**
 * The SDK approval callback: host `toolPolicy` first (full native
 * PermissionResult power), then the engine's interactive broker. The SDK
 * passes a REAL `toolUseID` (>=0.2.138), so brokered requests correlate to
 * their tool parts exactly.
 */
export function createCanUseTool(deps: {
	sessionId: string;
	policy?: ClaudeToolPolicy;
	getBroker: () => PermissionRequestHandler | undefined;
}): CanUseTool {
	return async (toolName, input, options) => {
		const { signal, toolUseID, agentID, suggestions, blockedPath, decisionReason } = options;
		const verdict = await deps.policy?.(toolName, input, {
			sessionId: deps.sessionId,
			toolUseId: toolUseID,
			agentId: agentID,
			signal,
			suggestions,
			blockedPath,
			decisionReason,
		});
		if (verdict) return verdict;
		const handler = deps.getBroker();
		if (!handler) return { behavior: "allow", updatedInput: input };
		const decision = await handler(
			{
				toolCallId: toolUseID,
				toolName,
				rawInput: input,
				...claudeToolMeta(toolName, input),
			},
			{ signal },
		);
		return decision.decision === "allow"
			? // What was approved is what runs: an edited input from the broker
				// replaces the original (C1 — silent divergence between the approved
				// and executed input is the worst failure mode in an approval path).
				{ behavior: "allow", updatedInput: decision.updatedInput ?? input }
			: {
					behavior: "deny",
					message: (decision.decision === "deny" && decision.reason) || "Denied by user",
					interrupt: decision.decision === "cancel",
				};
	};
}
