// The Law-6 membership tests, kept in one zod-free module.
//
// A guard is a string comparison against a frozen list — but when it lives
// next to the schema it guards, importing it pulls zod (and the whole part /
// event union) into the importer's bundle. Browser consumers pay ~100kB to ask
// "is this part type one I know?". These are re-exported from `./index.ts`
// (nothing moved for `@zvada/agent-server/protocol` importers) and are also
// reachable directly as `@zvada/agent-server/protocol/guards`, which is
// guaranteed zod-free at runtime (`test/protocol/zod-free.test.ts` walks the
// transitive import graph).
//
// Type-only imports below are erased at compile time and cost nothing at
// runtime — the modules they name are never loaded by this one.
import type { DecodedLifecycleEvent, UnknownEvent } from "./lifecycle.ts";
import type { Part, UnknownPart } from "./parts.ts";

export const PART_TYPES = ["text", "reasoning", "tool", "image", "file"] as const;

export function isKnownPartType(type: unknown): type is (typeof PART_TYPES)[number] {
	return typeof type === "string" && (PART_TYPES as readonly string[]).includes(type);
}

export function isUnknownPart(part: Part | UnknownPart): part is UnknownPart {
	return !isKnownPartType(part.type);
}
// No per-type guards for known parts: `p.type === "text"` narrows natively.

export const LIFECYCLE_EVENT_TYPES = [
	"session.created",
	"session.ended",
	"turn.started",
	"message.started",
	"message.part",
	"message.part.delta",
	"message.ended",
	"turn.ended",
	"session.usage",
	"session.compaction",
	"error",
	"permission.requested",
	"permission.resolved",
	"raw",
] as const;

export function isKnownLifecycleEventType(
	type: unknown,
): type is (typeof LIFECYCLE_EVENT_TYPES)[number] {
	return typeof type === "string" && (LIFECYCLE_EVENT_TYPES as readonly string[]).includes(type);
}

export function isUnknownEvent(event: DecodedLifecycleEvent | UnknownEvent): event is UnknownEvent {
	return !isKnownLifecycleEventType((event as { type: string }).type);
}
