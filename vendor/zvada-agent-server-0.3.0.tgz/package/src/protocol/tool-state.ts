import { z } from "zod";
import { MetaSchema } from "./meta.ts";
import { EpochMsSchema, TimeSpanSchema } from "./time.ts";
import { openVocabulary } from "./vocabulary.ts";

/**
 * Runtime tool lifecycle: a tool call moves pending -> in_progress ->
 * completed | failed | cancelled (ACP ToolCallStatus verbatim, incl. v2's
 * `cancelled`). `pending` carries the partial (streaming) JSON input before it
 * parses; the other states carry the fully-parsed input object. `cancelled` is
 * the terminal for tools in flight when a turn is cancelled — the reducer
 * applies it implicitly at `turn.ended{stopReason:"cancelled"}`; producers MAY
 * also emit the terminal snapshot explicitly.
 *
 * The status set is a STRUCTURAL discriminator (each status has its own
 * payload), so the union below is closed; new statuses are protocol additions,
 * not extensions.
 */
export const RUNTIME_TOOL_STATUSES = [
	"pending",
	"in_progress",
	"completed",
	"failed",
	"cancelled",
] as const;
export type RuntimeToolStatus = (typeof RUNTIME_TOOL_STATUSES)[number];

/**
 * What a tool call does, normalized across harnesses — ACP's ToolKind taxonomy
 * verbatim, plus `task` (subagent spawn; ACP has no subagent concept). Lets a
 * consumer pick an icon / verb without knowing provider-native tool names.
 *
 * OPEN vocabulary (Law 3): unknown non-`_` values are reserved for this
 * protocol and MUST be preserved; `_`-prefixed values are adapter/product
 * extensions. Display groupings (e.g. edit|delete|move -> a "write" card) are
 * consumer maps, not wire vocabulary.
 */
export const TOOL_KINDS = [
	"read",
	"edit",
	"delete",
	"move",
	"search",
	"execute",
	"think",
	"fetch",
	"switch_mode",
	"task",
	"other",
] as const;
export type ToolKind = (typeof TOOL_KINDS)[number] | (string & {});
export const ToolKindSchema = openVocabulary<ToolKind>();

/** A file location a tool call touches — lets UIs "follow along". (ACP shape.) */
export const ToolLocationSchema = z.object({
	path: z.string(),
	line: z.number().optional(),
});
export type ToolLocation = z.infer<typeof ToolLocationSchema>;

/**
 * Structured, display-grade tool output. Three-audience doctrine:
 * `ToolStateCompleted.output` (string) is the MODEL-facing factual record and
 * universal rendering fallback; `content` is the display-grade structured
 * view; `metadata` is the machine channel (exitCode, ...).
 */
export const ToolResultContentSchema = z.discriminatedUnion("type", [
	z.object({ type: z.literal("text"), text: z.string(), _meta: MetaSchema }),
	z.object({
		type: z.literal("image"),
		/** Base64-encoded bytes. */
		data: z.string(),
		mimeType: z.string(),
		_meta: MetaSchema,
	}),
	z.object({
		type: z.literal("diff"),
		path: z.string(),
		/** Absent for file creation. */
		oldText: z.string().optional(),
		newText: z.string(),
		_meta: MetaSchema,
	}),
	z.object({
		type: z.literal("terminal"),
		/** Display anchor only — a separate ID domain from toolCallId. */
		terminalId: z.string(),
		_meta: MetaSchema,
	}),
]);
export type ToolResultContent = z.infer<typeof ToolResultContentSchema>;

export const ToolStatePendingSchema = z.object({
	status: z.literal("pending"),
	/** Raw streamed JSON input — possibly invalid; parse best-effort for early render. */
	partialInput: z.string(),
	_meta: MetaSchema,
});
export type ToolStatePending = z.infer<typeof ToolStatePendingSchema>;

export const ToolStateInProgressSchema = z.object({
	status: z.literal("in_progress"),
	input: z.record(z.string(), z.unknown()),
	title: z.string().optional(),
	time: z.object({ start: EpochMsSchema }),
	_meta: MetaSchema,
});
export type ToolStateInProgress = z.infer<typeof ToolStateInProgressSchema>;

export const ToolStateCompletedSchema = z.object({
	status: z.literal("completed"),
	input: z.record(z.string(), z.unknown()),
	/** Model-facing factual record; always present as the rendering fallback. */
	output: z.string(),
	/** Display-grade structured output, when expressible (diffs, images, terminals). */
	content: z.array(ToolResultContentSchema).optional(),
	/** Machine channel: harness-native extras (e.g. `exitCode`). */
	metadata: z.record(z.string(), z.unknown()).optional(),
	title: z.string().optional(),
	time: TimeSpanSchema,
	_meta: MetaSchema,
});
export type ToolStateCompleted = z.infer<typeof ToolStateCompletedSchema>;

export const ToolStateFailedSchema = z.object({
	status: z.literal("failed"),
	input: z.record(z.string(), z.unknown()),
	error: z.string(),
	time: TimeSpanSchema,
	_meta: MetaSchema,
});
export type ToolStateFailed = z.infer<typeof ToolStateFailedSchema>;

export const ToolStateCancelledSchema = z.object({
	status: z.literal("cancelled"),
	input: z.record(z.string(), z.unknown()),
	time: TimeSpanSchema,
	_meta: MetaSchema,
});
export type ToolStateCancelled = z.infer<typeof ToolStateCancelledSchema>;

export const ToolStateSchema = z.discriminatedUnion("status", [
	ToolStatePendingSchema,
	ToolStateInProgressSchema,
	ToolStateCompletedSchema,
	ToolStateFailedSchema,
	ToolStateCancelledSchema,
]);
export type ToolState = z.infer<typeof ToolStateSchema>;
