import { createHash } from "node:crypto";

function canonicalize(value: unknown): unknown {
	if (Array.isArray(value)) return value.map(canonicalize);
	if (value && typeof value === "object") {
		return Object.fromEntries(
			Object.entries(value as Record<string, unknown>)
				.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
				.map(([key, item]) => [key, canonicalize(item)]),
		);
	}
	return value;
}

/** Stable, non-reversible identity for config that may contain credentials. */
export function configFingerprint(value: unknown): string {
	const canonical = JSON.stringify(canonicalize(value)) ?? "undefined";
	return createHash("sha256").update(canonical).digest("hex");
}
