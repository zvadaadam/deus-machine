/** A real upstream key + base URL, keyed by an opaque proxy session id. */
export interface ApiKeyEntry {
	apiKey: string;
	upstreamBaseUrl: string;
}

/**
 * In-memory map of proxy-session → real credentials. The agent subprocess is
 * given a placeholder key and pointed at the local proxy; the proxy swaps in the
 * real key from this store before forwarding upstream, so the key never lives in
 * the subprocess environment. (BYOK pattern from the echo/agnt sidecars.)
 */
export class ApiKeyStore {
	private readonly entries = new Map<string, ApiKeyEntry>();

	set(sessionId: string, apiKey: string, upstreamBaseUrl = "https://api.anthropic.com"): void {
		this.entries.set(sessionId, { apiKey, upstreamBaseUrl });
	}

	get(sessionId: string): ApiKeyEntry | undefined {
		return this.entries.get(sessionId);
	}

	delete(sessionId: string): void {
		this.entries.delete(sessionId);
	}

	clear(): void {
		this.entries.clear();
	}
}

/** Shared default store used by `createAnthropicProxy` when none is supplied. */
export const apiKeyStore = new ApiKeyStore();
