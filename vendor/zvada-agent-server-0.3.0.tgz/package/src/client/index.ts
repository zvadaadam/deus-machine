// @zvada/agent-server/client — typed client for the agent-server wire.
// The only package a remote consumer needs to import.

export {
	AgentServerClient,
	type AgentServerClientOptions,
	ConnectionClosedError,
	EventGapError,
	type TurnHandle,
	WireRequestError,
} from "./client.ts";
export {
	connectTransport,
	type SpawnServerOptions,
	socketTransport,
	spawnTransport,
	type WebSocketLike,
} from "./transports.ts";
