import { type AcpLaunch, parseAcpLaunch } from "./client.ts";

/**
 * Advisory catalog of well-known ACP agents — UX sugar, not wire vocabulary
 * (like MODEL_CATALOG). On the wire the harness is always `acp`; these names
 * let entry points offer "pi" or "gemini" as first-class choices and expand
 * them to launch commands at the operator edge. Anything not listed here runs
 * via an explicit launch command — any ACP-compatible agent works.
 */
export const KNOWN_ACP_AGENTS: Record<string, { label: string; launch: AcpLaunch }> = {
	pi: {
		label: "pi.dev (Pi coding agent, via the pi-acp adapter)",
		launch: { command: "npx", args: ["-y", "pi-acp"] },
	},
	gemini: {
		label: "Gemini CLI (native ACP mode)",
		launch: { command: "gemini", args: ["--acp"] },
	},
};

/**
 * Resolve an operator spec that is either a known agent name (`"pi"`) or a
 * raw launch command (`"npx -y pi-acp"`). The canonical resolver behind
 * `--acp-agent` and `$AGENT_SERVER_ACP_AGENT`.
 */
export function resolveAcpLaunch(spec: string | undefined): AcpLaunch | undefined {
	if (!spec) return undefined;
	return KNOWN_ACP_AGENTS[spec.trim()]?.launch ?? parseAcpLaunch(spec);
}
