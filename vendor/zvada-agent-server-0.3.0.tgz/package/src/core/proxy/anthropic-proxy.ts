import { type DiagnosticHandler, emitDiagnostic } from "../diagnostics.ts";
import { type ApiKeyStore, apiKeyStore } from "./api-key-store.ts";

/** Placeholder key handed to the agent subprocess; swapped for the real one here. */
export const PROXY_PLACEHOLDER_KEY = "sk-proxy-managed";

/** Minimal fetch shape (`globalThis.fetch` qualifies; injectable for tests/platforms). */
export type FetchLike = (
	input: string | URL | Request,
	init?: RequestInit & { duplex?: "half" },
) => Promise<Response>;

export interface AnthropicProxyOptions {
	/** Store to resolve real credentials from. Defaults to the shared `apiKeyStore`. */
	store?: ApiKeyStore;
	/** Path prefix the proxy is mounted under. Default `/proxy/anthropic`. */
	pathPrefix?: string;
	/** Fetch implementation (test seam / platform override). Default `globalThis.fetch`. */
	fetch?: FetchLike;
	/** Notified on upstream 401/403 — the STORED key is bad, not the placeholder. */
	onDiagnostic?: DiagnosticHandler;
}

/**
 * A framework-agnostic, Web-standard `(Request) => Promise<Response>` handler
 * implementing the BYOK Anthropic proxy. Mount it in any server (Bun, Hono,
 * Workers, Node 18+). Requests come in at `{prefix}/{sessionId}/{...path}`; the
 * handler looks up the real key for `sessionId`, swaps the `x-api-key` header,
 * and forwards to the configured upstream. Responses are NOT passed through
 * verbatim — two host-runtime bugs require reshaping (both hit Claude Code as
 * its API client, found in agnt's production sidecar):
 *   - SSE bodies are pumped through a `TransformStream`: Bun's HTTP server
 *     mishandles direct ReadableStream passthrough for SSE and the node
 *     client sees a premature "terminated".
 *   - Non-SSE responses drop `content-encoding`/`content-length`/
 *     `transfer-encoding`: fetch already decompressed the body, so the
 *     original headers make the client gunzip plain bytes (ZlibError).
 *
 * Point the agent at it with:
 *   ANTHROPIC_BASE_URL=http://localhost:PORT/proxy/anthropic/<sessionId>
 *   ANTHROPIC_API_KEY=sk-proxy-managed
 * and register the real key via `apiKeyStore.set(sessionId, realKey)`.
 */
export function createAnthropicProxy(
	options: AnthropicProxyOptions = {},
): (request: Request) => Promise<Response> {
	const store = options.store ?? apiKeyStore;
	const prefix = options.pathPrefix ?? "/proxy/anthropic";

	return async function handle(request: Request): Promise<Response> {
		const url = new URL(request.url);
		const tail = url.pathname.startsWith(prefix)
			? url.pathname.slice(prefix.length).replace(/^\//, "")
			: "";
		const slash = tail.indexOf("/");
		const sessionId = slash === -1 ? tail : tail.slice(0, slash);
		const subPath = slash === -1 ? "" : tail.slice(slash);

		const entry = sessionId ? store.get(sessionId) : undefined;
		if (!entry) {
			return new Response(
				JSON.stringify({
					type: "error",
					error: { type: "authentication_error", message: "unknown proxy session" },
				}),
				{ status: 401, headers: { "content-type": "application/json" } },
			);
		}

		const headers = new Headers(request.headers);
		headers.set("x-api-key", entry.apiKey);
		headers.delete("authorization");
		headers.delete("host");
		headers.delete("content-length");

		const init: RequestInit & { duplex?: "half" } = {
			method: request.method,
			headers,
			body: request.body,
			redirect: "manual",
		};
		// Required when forwarding a streaming request body on fetch.
		if (request.body) init.duplex = "half";

		const doFetch: FetchLike = options.fetch ?? (globalThis.fetch as FetchLike);
		let upstream: Response;
		try {
			upstream = await doFetch(`${entry.upstreamBaseUrl}${subPath}${url.search}`, init);
		} catch (error) {
			// An unreachable upstream must surface as a structured API error the
			// agent can classify, not a host-framework 500 with an opaque body.
			return new Response(
				JSON.stringify({
					type: "error",
					error: {
						type: "api_error",
						message: error instanceof Error ? error.message : "proxy request failed",
					},
				}),
				{ status: 502, headers: { "content-type": "application/json" } },
			);
		}

		if (upstream.status === 401 || upstream.status === 403) {
			emitDiagnostic(options.onDiagnostic, {
				type: "proxyUpstreamAuth",
				sessionId,
				message: `upstream rejected the stored key for session ${sessionId} (${upstream.status})`,
				detail: { status: upstream.status },
			});
		}

		const contentType = upstream.headers.get("content-type") ?? "";
		// Media type only — parameters (charset) stripped, case-insensitive, so
		// `text/event-streamish` or a parameter VALUE never selects SSE handling.
		const mediaType = (contentType.split(";", 1)[0] ?? "").trim().toLowerCase();
		if (mediaType === "text/event-stream" && upstream.body) {
			// Pumped through a fresh stream — see the header comment for why raw
			// passthrough breaks on Bun. pipeTo (not a manual read/write loop) so a
			// downstream disconnect propagates cancellation to the upstream body
			// and the socket is released instead of held open.
			const { readable, writable } = new TransformStream<Uint8Array, Uint8Array>();
			void upstream.body.pipeTo(writable).catch(() => {
				// downstream went away or upstream died — both ends settled by pipeTo
			});
			return new Response(readable, {
				status: upstream.status,
				headers: { "content-type": "text/event-stream", "cache-control": "no-cache" },
			});
		}

		const responseHeaders = new Headers(upstream.headers);
		responseHeaders.delete("content-encoding");
		responseHeaders.delete("content-length");
		responseHeaders.delete("transfer-encoding");
		return new Response(upstream.body, {
			status: upstream.status,
			statusText: upstream.statusText,
			headers: responseHeaders,
		});
	};
}
