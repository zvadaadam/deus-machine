import type { LifecycleEvent } from "../../protocol/index.ts";

/**
 * The single output port of the engine. A consumer implements `emit` to forward
 * normalized events wherever they need to go (WebSocket, SSE, stdout, a buffer).
 * The engine never assumes a transport.
 */
export interface EventSink {
	emit(event: LifecycleEvent): void | Promise<void>;
}

/** Build a sink from a plain callback. */
export function callbackSink(fn: (event: LifecycleEvent) => void | Promise<void>): EventSink {
	return { emit: fn };
}

/** A sink that accumulates events in memory — handy for tests and batch runs. */
export class CollectingSink implements EventSink {
	readonly events: LifecycleEvent[] = [];

	emit(event: LifecycleEvent): void {
		this.events.push(event);
	}

	byType<T extends LifecycleEvent["type"]>(type: T): Extract<LifecycleEvent, { type: T }>[] {
		return this.events.filter((e): e is Extract<LifecycleEvent, { type: T }> => e.type === type);
	}
}

/** Fan out to several sinks at once. */
export function teeSink(...sinks: EventSink[]): EventSink {
	return {
		async emit(event) {
			for (const sink of sinks) await sink.emit(event);
		},
	};
}
