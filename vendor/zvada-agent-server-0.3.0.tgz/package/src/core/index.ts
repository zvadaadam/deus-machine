// @zvada/agent-server/core — harness-agnostic agent execution engine.

// Runtime
export { AgentRuntime, type RunSummary, type TurnAdmission } from "./runtime/agent-runtime.ts";
export { type DiagnosticHandler, type EngineDiagnostic, emitDiagnostic } from "./diagnostics.ts";
export {
	type EventSink,
	callbackSink,
	CollectingSink,
	teeSink,
} from "./runtime/event-sink.ts";
export { EventProcessor } from "./runtime/event-processor.ts";

// Agent abstraction
export {
	type Agent,
	type AgentExecuteOptions,
	type CancelResult,
	type RawAgentEvent,
	BaseAgent,
} from "./agents/base.ts";
export { AgentRegistry } from "./agents/registry.ts";
export {
	type ErrorCategory,
	ERROR_CATEGORIES,
	classifyError,
	isRecoverable,
	isCancellation,
} from "../protocol/errors.ts";

// Adapter contract
export type {
	AdapterEvent,
	AdapterFactory,
	EventTransformer,
	TransformResult,
} from "./agents/types.ts";

// CLI provisioning
export {
	CLI_TOOLS,
	type CliTool,
	CliProvisioner,
	DEFAULT_PINS,
	type PlatformInfo,
	type ProvisionMode,
	type ProvisionOptions,
	type ProvisionerDeps,
	type ResolvedCli,
	detectPlatform,
	toolForHarness,
} from "./provision/index.ts";

// Harnesses
export {
	ClaudeCodeAgent,
	type ClaudeCodeAgentOptions,
} from "./agents/claude-code/claude-agent.ts";
export type { ClaudeSdkOptionOverrides, SdkMcpServers } from "./agents/claude-code/options.ts";
export type {
	ClaudeHooksFactory,
	ClaudeSessionEndReason,
	ClaudeSessionExtras,
	ClaudeToolPolicy,
} from "./agents/claude-code/generator-session.ts";
export {
	ClaudeCodeTransformer,
	createClaudeCodeTransformer,
} from "./agents/claude-code/adapter.ts";
export {
	CodexSdkAgent,
	type CodexSdkAgentOptions,
} from "./agents/codex-sdk/codex-sdk-agent.ts";
export { CodexSdkTransformer, createCodexSdkTransformer } from "./agents/codex-sdk/adapter.ts";
export {
	CodexAppServerAgent,
	type CodexAppServerAgentOptions,
} from "./agents/codex-app-server/codex-app-server-agent.ts";
export {
	CodexAppServerTransformer,
	createCodexAppServerTransformer,
} from "./agents/codex-app-server/adapter.ts";
export {
	CodexAppServerClient,
	type CodexNotification,
} from "./agents/codex-app-server/client.ts";
export {
	AcpAgent,
	type AcpAgentOptions,
} from "./agents/acp/acp-agent.ts";
export { AcpTransformer, createAcpTransformer } from "./agents/acp/adapter.ts";
export {
	AcpClient,
	type AcpClientOptions,
	type AcpLaunch,
	parseAcpLaunch,
} from "./agents/acp/client.ts";
export { KNOWN_ACP_AGENTS, resolveAcpLaunch } from "./agents/acp/known-agents.ts";

// Presets
export {
	type CreateRegistryOptions,
	createAgentRegistry,
	createAgentRuntime,
} from "./presets.ts";

// Utils
export {
	AgentServerError,
	AgentExecutionError,
	CliNotFoundError,
	CliProvisionError,
	HarnessNotFoundError,
	TurnConflictError,
} from "./utils/errors.ts";

// Re-export the wire contract for convenience.
export * from "../protocol/index.ts";
