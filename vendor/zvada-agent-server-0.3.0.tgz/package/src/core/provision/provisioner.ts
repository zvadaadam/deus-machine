import { randomBytes } from "node:crypto";
import {
	chmodSync,
	existsSync,
	lstatSync,
	mkdirSync,
	readFileSync,
	readdirSync,
	realpathSync,
} from "node:fs";
import { chmod, mkdir, readdir, rename, rm } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { CliNotFoundError, CliProvisionError } from "../utils/errors.ts";
import { extractTarGz } from "./extract.ts";
import { DEFAULT_NPM_REGISTRY, downloadWithIntegrity, fetchDist } from "./npm.ts";
import { type CliTool, DEFAULT_PINS } from "./pins.ts";
import {
	type PlatformInfo,
	claudePackageSuffix,
	codexPackageSuffix,
	detectPlatform,
	findOnPath,
} from "./platform.ts";

/**
 * How CLIs are obtained (see DESIGN/README "CLI provisioning"):
 * - `auto` (default): explicit override → host install → managed cache →
 *   download the pinned build. Zero-config everywhere, self-healing in bare
 *   sandboxes, no download when the machine already has the CLI.
 * - `pinned`: override → managed cache → download. Never trusts host installs
 *   — every process in a fleet runs the exact tested CLI build.
 * - `system`: override → host install only. Never downloads (air-gapped /
 *   "my machine, my CLIs").
 */
export type ProvisionMode = "auto" | "pinned" | "system";

export interface ProvisionOptions {
	/** Defaults to `$AGENT_SERVER_PROVISION`, then `auto`. */
	mode?: ProvisionMode;
	/**
	 * Where managed CLIs live. Defaults to `$AGENT_SERVER_CACHE_DIR`, then
	 * `$XDG_CACHE_HOME/agent-server/cli`, then `~/.cache/agent-server/cli`.
	 */
	cacheDir?: string;
	/** npm registry base URL. Defaults to `$AGENT_SERVER_NPM_REGISTRY`, then npmjs. */
	registry?: string;
	/** Version pins overriding this release's defaults (see `DEFAULT_PINS`). */
	pins?: Partial<Record<CliTool, string>>;
	/**
	 * Explicit CLI paths — the operator escape hatch. Defaults to
	 * `$CLAUDE_CLI_PATH` / `$CODEX_CLI_PATH`. Never sourced from the wire:
	 * letting a remote client pick the spawned executable would be RCE.
	 */
	overrides?: Partial<Record<CliTool, string>>;
	/** Progress/diagnostic lines. Defaults to stderr. */
	log?: (line: string) => void;
}

/** Where a resolved CLI came from — logged once so runs are diagnosable. */
export interface ResolvedCli {
	path: string;
	source: "override" | "host" | "cache" | "downloaded";
	version?: string;
}

/** Process/machine seams, injectable so the policy is testable offline. */
export interface ProvisionerDeps {
	fetch?: typeof fetch;
	platform?: PlatformInfo;
	env?: Record<string, string | undefined>;
	extract?: (tgzPath: string, destDir: string) => Promise<void>;
	/** Replace host-install discovery (SDK sibling package / PATH scan). */
	hostResolve?: (tool: CliTool) => ResolvedCli | undefined;
}

const OVERRIDE_ENV: Record<CliTool, string> = {
	claude: "CLAUDE_CLI_PATH",
	codex: "CODEX_CLI_PATH",
};

const MODES: readonly ProvisionMode[] = ["auto", "pinned", "system"];

/** What to download for one tool on one platform. */
interface ToolPackage {
	name: string;
	/** Exact version string the registry knows (codex encodes platform here). */
	registryVersion: string;
	/** Human/tool version (cache directory key). */
	version: string;
	suffix: string;
}

function defaultLog(line: string): void {
	console.error(`[agent-server] ${line}`);
}

/**
 * Locate an installed package by walking `node_modules` upward from `fromDir`,
 * returning its real directory. Deliberately not `require.resolve`: ESM-only
 * packages (codex-sdk) have no require condition and none of these packages
 * export `./package.json`, so exports maps would veto perfectly good installs.
 * The realpath matters under isolated stores (bun): a package's own deps are
 * siblings of its *store* location, not of the symlink consumers see.
 */
function findPackageDir(name: string, fromDir: string): string | undefined {
	let dir = fromDir;
	while (true) {
		const candidate = join(dir, "node_modules", ...name.split("/"));
		if (existsSync(join(candidate, "package.json"))) {
			try {
				return realpathSync(candidate);
			} catch {
				return undefined;
			}
		}
		const parent = dirname(dir);
		if (parent === dir) return undefined;
		dir = parent;
	}
}

/** Where this package lives on disk — the walk anchor. Virtual inside compiled
 * binaries ($bunfs), where every walk misses and pins take over. NOTE: this
 * must not mention `import.meta` — consumers bundle these sources to CJS,
 * where that token is a parse error (and older bundlers don't rewrite it). */
function moduleDir(): string {
	// CJS bundle output: anchor at the bundle location.
	if (typeof __dirname !== "undefined") return __dirname;
	try {
		// Bun/ESM: resolve our own manifest through the module graph (Bun
		// provides `require` in ESM; "./package.json" is an explicit export).
		return dirname(require.resolve("@zvada/agent-server/package.json"));
	} catch {
		return process.cwd();
	}
}

/**
 * Resolves the native CLIs the harnesses spawn (`claude`, `codex`) and — in
 * managed modes — downloads the pinned builds from the npm registry into a
 * local cache, verified against the registry's sha512 integrity and installed
 * atomically (staging + rename), so concurrent processes converge on one copy.
 *
 * One instance per runtime; `resolve` is memoized per tool (a failure clears
 * the memo so a transient network error doesn't poison the process).
 */
export class CliProvisioner {
	private readonly mode: ProvisionMode;
	private readonly cacheDir: string;
	private readonly registry: string;
	/** Explicit pins only — see `versionFor` for the per-tool default chain. */
	private readonly pins: Partial<Record<CliTool, string>>;
	private readonly overrides: Partial<Record<CliTool, string>>;
	private readonly log: (line: string) => void;
	private readonly fetch: typeof fetch;
	private readonly platform: PlatformInfo;
	private readonly env: Record<string, string | undefined>;
	private readonly extract: (tgzPath: string, destDir: string) => Promise<void>;
	private readonly hostResolve: (tool: CliTool) => ResolvedCli | undefined;
	private readonly memo = new Map<CliTool, Promise<ResolvedCli | undefined>>();
	private cacheRootTrusted = false;

	constructor(options: ProvisionOptions = {}, deps: ProvisionerDeps = {}) {
		this.env = deps.env ?? process.env;
		this.mode = options.mode ?? this.modeFromEnv();
		this.cacheDir =
			options.cacheDir ??
			this.env.AGENT_SERVER_CACHE_DIR ??
			join(this.env.XDG_CACHE_HOME ?? join(homedir(), ".cache"), "agent-server", "cli");
		this.registry = options.registry ?? this.env.AGENT_SERVER_NPM_REGISTRY ?? DEFAULT_NPM_REGISTRY;
		this.pins = options.pins ?? {};
		this.overrides = options.overrides ?? {};
		this.log = options.log ?? defaultLog;
		this.fetch = deps.fetch ?? fetch;
		this.platform = deps.platform ?? detectPlatform();
		this.extract = deps.extract ?? extractTarGz;
		this.hostResolve = deps.hostResolve ?? ((tool) => this.defaultHostResolve(tool));
	}

	/**
	 * Resolve a CLI per the provisioning mode. `undefined` (claude in `system`
	 * mode only) means "let the harness's own resolution speak" — the Claude SDK
	 * finds its sibling platform package and has the clearest failure message.
	 */
	resolve(tool: CliTool): Promise<ResolvedCli | undefined> {
		const memoized = this.memo.get(tool);
		if (memoized) return memoized;
		const pending = this.doResolve(tool).then((resolved) => {
			if (resolved) {
				this.log(`${tool} CLI: ${resolved.path} (${resolved.source}${withVersion(resolved)})`);
			}
			return resolved;
		});
		this.memo.set(tool, pending);
		pending.catch(() => this.memo.delete(tool));
		return pending;
	}

	/** Warm the managed cache with the pinned build (the `install` command). */
	async install(tool: CliTool): Promise<ResolvedCli> {
		return this.ensureInstalled(tool);
	}

	private async doResolve(tool: CliTool): Promise<ResolvedCli | undefined> {
		const override = this.overrides[tool] ?? this.env[OVERRIDE_ENV[tool]];
		if (override) {
			if (!existsSync(override)) {
				throw new CliProvisionError(
					`${tool} CLI override points to a missing file: ${override} ` +
						`(from ${this.overrides[tool] ? "options.overrides" : `$${OVERRIDE_ENV[tool]}`})`,
				);
			}
			return { path: override, source: "override" };
		}

		if (this.mode !== "pinned") {
			const host = this.hostResolve(tool);
			if (host) return host;
			if (this.mode === "system") {
				if (tool === "codex") {
					throw new CliNotFoundError(
						"codex",
						`install it, set $${OVERRIDE_ENV.codex}, or use provision mode "auto"`,
					);
				}
				return undefined;
			}
		}

		return this.ensureInstalled(tool);
	}

	/**
	 * Host install discovery. Both tools prefer the JS SDK's own vendored
	 * platform package (the lockfile-paired build the SDK would spawn itself);
	 * codex additionally falls back to PATH for machines that installed the CLI
	 * system-wide without the SDK (the app-server harness needs no SDK).
	 */
	private defaultHostResolve(tool: CliTool): ResolvedCli | undefined {
		if (tool === "codex") {
			const vendored = this.codexVendoredOnDisk();
			if (vendored) return vendored;
			const path = findOnPath("codex", this.env, this.platform.platform);
			return path ? { path, source: "host" } : undefined;
		}
		const sdk = this.claudeSdkOnDisk();
		if (!sdk) return undefined;
		const suffix = claudePackageSuffix(this.platform);
		const platformDir = findPackageDir(`@anthropic-ai/claude-agent-sdk-${suffix}`, sdk.dir);
		if (!platformDir) return undefined;
		const path = join(platformDir, this.claudeBinaryName(sdk.dir, suffix));
		return existsSync(path) ? { path, source: "host", version: sdk.version } : undefined;
	}

	/**
	 * The codex build vendored by `@openai/codex-sdk` (its `@openai/codex`
	 * dependency ships `vendor/<target>/bin/codex`) — the same two-hop
	 * resolution the SDK's own `findCodexPath` performs, so managed resolution
	 * never shadows the pair the SDK was published against.
	 */
	private codexVendoredOnDisk(): ResolvedCli | undefined {
		try {
			const sdkDir = findPackageDir("@openai/codex-sdk", moduleDir());
			if (!sdkDir) return undefined;
			const codexDir = findPackageDir("@openai/codex", sdkDir);
			if (!codexDir) return undefined;
			const suffix = codexPackageSuffix(this.platform);
			const platformDir = findPackageDir(`@openai/codex-${suffix}`, codexDir);
			if (!platformDir) return undefined;
			const vendorRoot = join(platformDir, "vendor");
			for (const entry of readdirSync(vendorRoot)) {
				const path = this.binaryIn("codex", join(vendorRoot, entry));
				if (path) {
					const raw = (
						JSON.parse(readFileSync(join(platformDir, "package.json"), "utf8")) as {
							version?: string;
						}
					).version;
					const version = raw?.replace(`-${suffix}`, "");
					return { path, source: "host", ...(version ? { version } : {}) };
				}
			}
			return undefined;
		} catch {
			return undefined;
		}
	}

	/**
	 * The installed Claude SDK, when resolvable on disk. Its version drives both
	 * host resolution and the download pin, so the JS ↔ native-CLI pair can
	 * never skew. Unresolvable inside compiled binaries — pins take over there.
	 */
	private claudeSdkOnDisk(): { dir: string; version?: string } | undefined {
		try {
			const dir = findPackageDir("@anthropic-ai/claude-agent-sdk", moduleDir());
			if (!dir) return undefined;
			const pkg = JSON.parse(readFileSync(join(dir, "package.json"), "utf8")) as {
				version?: string;
			};
			return { dir, version: pkg.version };
		} catch {
			return undefined;
		}
	}

	/** Binary filename from the SDK's manifest (`claude` / `claude.exe`). */
	private claudeBinaryName(sdkDir: string, suffix: string): string {
		try {
			const manifest = JSON.parse(readFileSync(join(sdkDir, "manifest.json"), "utf8")) as {
				platforms?: Record<string, { binary?: string }>;
			};
			return manifest.platforms?.[suffix]?.binary ?? "claude";
		} catch {
			return "claude";
		}
	}

	/**
	 * The version to download: an explicit pin always wins; claude then prefers
	 * the on-disk SDK's version (the pair that actually runs) over the release
	 * default, which only decides inside compiled binaries.
	 *
	 * Deliberately mode-independent: even `pinned` follows the installed SDK
	 * for claude, because "deterministic" means the tested JS ↔ CLI *pair* —
	 * downloading the release-default CLI under a newer installed SDK would
	 * manufacture exactly the skew this module exists to prevent. Operators
	 * who want byte-identical fleets pin explicitly (and align the SDK).
	 */
	private versionFor(tool: CliTool): string {
		const explicit = this.pins[tool];
		if (explicit) return explicit;
		if (tool === "claude") return this.claudeSdkOnDisk()?.version ?? DEFAULT_PINS.claude;
		return DEFAULT_PINS.codex;
	}

	private packageFor(tool: CliTool): ToolPackage {
		const version = this.versionFor(tool);
		if (tool === "claude") {
			const suffix = claudePackageSuffix(this.platform);
			return {
				name: `@anthropic-ai/claude-agent-sdk-${suffix}`,
				registryVersion: version,
				version,
				suffix,
			};
		}
		const suffix = codexPackageSuffix(this.platform);
		return { name: "@openai/codex", registryVersion: `${version}-${suffix}`, version, suffix };
	}

	/**
	 * First binary candidate under an installed directory. Regular files only
	 * (lstat): a symlink here could redirect the spawn — and the post-install
	 * `chmod` — at a path outside the tree we verified.
	 */
	private binaryIn(tool: CliTool, dir: string): string | undefined {
		const candidates =
			tool === "claude"
				? ["claude", "claude.exe"]
				: [join("bin", "codex"), join("bin", "codex.exe")];
		for (const candidate of candidates) {
			const path = join(dir, candidate);
			try {
				if (lstatSync(path).isFile()) return path;
			} catch {
				// not here — try the next candidate
			}
		}
		return undefined;
	}

	/**
	 * Trust gate on the cache root, mirroring the Claude SDK's own temp-dir
	 * defense: install paths are predictable (public versions + platform), so
	 * under a shared/pre-created directory another local user could plant the
	 * binary we spawn. Create `0o700`, require our own uid, and tighten a
	 * looser mode (earlier runs created it with the umask). POSIX-only — on
	 * Windows the default cache locations are already per-user.
	 */
	private ensureTrustedCacheRoot(): void {
		if (this.cacheRootTrusted) return;
		mkdirSync(this.cacheDir, { recursive: true, mode: 0o700 });
		if (typeof process.getuid === "function") {
			const stat = lstatSync(this.cacheDir);
			if (!stat.isDirectory()) {
				throw new CliProvisionError(
					`Cache dir ${this.cacheDir} is not a directory (planted symlink?) — refusing to use it`,
				);
			}
			if (stat.uid !== process.getuid()) {
				throw new CliProvisionError(
					`Cache dir ${this.cacheDir} is owned by uid ${stat.uid}, expected ${process.getuid()} — refusing to use it`,
				);
			}
			if ((stat.mode & 0o777) !== 0o700) chmodSync(this.cacheDir, 0o700);
		}
		this.cacheRootTrusted = true;
	}

	/** The directory inside an extracted tarball that becomes the install. */
	private async payloadDir(tool: CliTool, extractedRoot: string): Promise<string> {
		if (tool === "claude") {
			const dir = join(extractedRoot, "package");
			if (existsSync(dir)) return dir;
			throw new CliProvisionError("claude tarball has no package/ directory");
		}
		// codex vendors per-target trees: package/vendor/<rust-triple>/bin/codex.
		// Install the whole tree — the CLI expects its vendored rg/zsh siblings.
		const vendor = join(extractedRoot, "package", "vendor");
		const entries = existsSync(vendor) ? await readdir(vendor) : [];
		for (const entry of entries) {
			const dir = join(vendor, entry);
			if (this.binaryIn(tool, dir)) return dir;
		}
		throw new CliProvisionError("codex tarball has no vendor/<target>/bin/codex");
	}

	private async ensureInstalled(tool: CliTool): Promise<ResolvedCli> {
		this.ensureTrustedCacheRoot();
		const pkg = this.packageFor(tool);
		const dir = join(this.cacheDir, tool, `${pkg.version}-${pkg.suffix}`);
		const cached = this.binaryIn(tool, dir);
		if (cached) return { path: cached, source: "cache", version: pkg.version };

		this.log(`downloading ${tool} ${pkg.version} (${pkg.suffix}) from ${this.registry}…`);
		const startedAt = Date.now();
		const staging = join(
			this.cacheDir,
			".tmp",
			`${tool}-${pkg.version}-${process.pid}-${randomBytes(4).toString("hex")}`,
		);
		await mkdir(staging, { recursive: true });
		try {
			const dist = await fetchDist(this.registry, pkg.name, pkg.registryVersion, this.fetch);
			const tgz = join(staging, "package.tgz");
			const bytes = await downloadWithIntegrity(dist.tarball, tgz, dist.integrity, this.fetch);
			const extracted = join(staging, "x");
			await mkdir(extracted);
			await this.extract(tgz, extracted);
			const payload = await this.payloadDir(tool, extracted);

			await mkdir(dirname(dir), { recursive: true });
			try {
				await rename(payload, dir);
			} catch (error) {
				// Lost an install race with another process. The directory is
				// version-keyed, so the winner's tree is what we would have written.
				if (!this.binaryIn(tool, dir)) throw error;
			}
			const path = this.binaryIn(tool, dir);
			if (!path) {
				throw new CliProvisionError(`downloaded ${pkg.name}@${pkg.registryVersion} has no binary`);
			}
			await chmod(path, 0o755);
			const seconds = ((Date.now() - startedAt) / 1000).toFixed(1);
			const mb = (bytes / 1024 / 1024).toFixed(0);
			this.log(`installed ${tool} ${pkg.version} → ${dir} (${mb} MB in ${seconds}s)`);
			return { path, source: "downloaded", version: pkg.version };
		} finally {
			await rm(staging, { recursive: true, force: true });
		}
	}

	private modeFromEnv(): ProvisionMode {
		const raw = this.env.AGENT_SERVER_PROVISION;
		if (raw === undefined || raw === "") return "auto";
		if ((MODES as readonly string[]).includes(raw)) return raw as ProvisionMode;
		throw new CliProvisionError(
			`Invalid $AGENT_SERVER_PROVISION: ${raw} (expected ${MODES.join(" | ")})`,
		);
	}
}

function withVersion(resolved: ResolvedCli): string {
	return resolved.version ? ` ${resolved.version}` : "";
}
