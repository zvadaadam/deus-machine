import { type AgentRuntime, TurnConflictError, callbackSink } from "../core/index.ts";
import {
	type AgentCapabilities,
	type AgentHarness,
	EventsReplayParamsSchema,
	InitializeParamsSchema,
	type InitializeResult,
	type JsonRpcId,
	PermissionRespondParamsSchema,
	type RunRequest,
	SessionCloseParamsSchema,
	TurnCancelParamsSchema,
	type TurnCancelResult,
	TurnStartParamsSchema,
	WIRE_ERROR_CODES,
	WIRE_METHODS,
	WIRE_PROTOCOL_VERSION,
	type WireEventEnvelope,
	type WireImplementationInfo,
	type WireTransport,
	classifyError,
	decodeWireMessage,
	encodeErrorResponse,
	encodeNotification,
	encodeResponse,
	generateUUIDv7,
} from "../protocol/index.ts";
import { DEFAULT_BUFFER_SIZE, SessionLog } from "./session-log.ts";

/** Structural slice of a ZodError — keeps zod out of this package's deps. */
interface ValidationError {
	issues: ReadonlyArray<{ path: ReadonlyArray<PropertyKey>; message: string }>;
}

export interface AgentServerOptions {
	/** Replay ring-buffer size per session (envelopes). */
	bufferSize?: number;
	/** Reported in the `initialize` result. */
	info?: WireImplementationInfo;
	/** Called once a `shutdown` request has been acked and the runtime drained. */
	onShutdown?: () => void;
}

/**
 * The wire binding (phase 2): serves the engine over JSON-RPC 2.0 on any
 * number of attached transports. Requests flow client -> server only; every
 * lifecycle event is stamped with a per-session monotonic `seq`, buffered for
 * `events/replay`, and broadcast to all attached transports as an `event`
 * notification. `turn/start` is quick-ack: the response only accepts the turn;
 * completion is the `turn.ended` event. One active turn per session.
 */
export class AgentServer {
	private readonly transports = new Set<WireTransport>();
	private readonly sessions = new Map<string, SessionLog>();
	private readonly activeTurns = new Map<string, { turnId: string; harness: AgentHarness }>();
	private readonly closingSessions = new Set<string>();
	/** Last assigned seq of closed sessions, so a reused id continues
	 * monotonically. Memory: one number per closed-and-never-reused session id —
	 * unbounded only across a server lifetime with unbounded distinct ids, the
	 * same order of growth already accepted for `sessions`. */
	private readonly retiredSeqs = new Map<string, number>();
	private readonly observers = new Set<(envelope: WireEventEnvelope) => void>();
	private shuttingDown = false;

	constructor(
		private readonly runtime: AgentRuntime,
		private readonly options: AgentServerOptions = {},
	) {}

	/** Serve the wire on a transport; returns a detach function. */
	attach(transport: WireTransport): () => void {
		this.transports.add(transport);
		const offLine = transport.onLine((line) => void this.handleLine(transport, line));
		const detach = () => {
			offLine();
			this.transports.delete(transport);
		};
		transport.onClose(detach);
		return detach;
	}

	/**
	 * Observe every broadcast envelope in-process; returns an unsubscribe.
	 *
	 * The same sequenced envelopes the transports receive, already appended to
	 * the session log — a host that embeds the server (to keep its own session
	 * bookkeeping, mirror events into a DB, trigger follow-up work) gets them
	 * as decoded objects instead of attaching a fake transport and parsing its
	 * own wire back out of NDJSON.
	 *
	 * Synchronous and isolated: an observer that throws is swallowed, exactly
	 * like a faulty transport or a failing sink — an event is a fact that
	 * already happened, and a consumer's bug must not unwind the broadcast for
	 * everyone else. Do the slow part yourself (queue it, don't block here).
	 */
	onEvent(observer: (envelope: WireEventEnvelope) => void): () => void {
		this.observers.add(observer);
		return () => this.observers.delete(observer);
	}

	/** Cancel all turns, terminate harnesses, and close every transport. */
	async shutdown(): Promise<void> {
		if (this.shuttingDown) return;
		this.shuttingDown = true;
		// Drain first so cancelled turns still broadcast their turn.ended.
		await this.runtime.shutdown();
		for (const transport of [...this.transports]) transport.close();
		this.options.onShutdown?.();
	}

	private async handleLine(transport: WireTransport, line: string): Promise<void> {
		if (!line.trim()) return;
		const msg = decodeWireMessage(line);
		if (msg.kind === "invalid") {
			transport.send(encodeErrorResponse(null, WIRE_ERROR_CODES.parseError, msg.error));
			return;
		}
		// Clients only send requests on this wire; stray notifications/responses
		// are tolerated and dropped.
		if (msg.kind !== "request") return;
		try {
			await this.handleRequest(transport, msg.id, msg.method, msg.params);
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			transport.send(encodeErrorResponse(msg.id, WIRE_ERROR_CODES.internalError, message));
		}
	}

	private async handleRequest(
		transport: WireTransport,
		id: JsonRpcId,
		method: string,
		params: unknown,
	): Promise<void> {
		switch (method) {
			case WIRE_METHODS.initialize: {
				const parsed = InitializeParamsSchema.safeParse(params ?? {});
				if (!parsed.success) return this.invalidParams(transport, id, parsed.error);
				if (parsed.data.protocolVersion !== WIRE_PROTOCOL_VERSION) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.protocolVersionMismatch,
							`unsupported protocol version: ${parsed.data.protocolVersion}`,
							{ supported: [WIRE_PROTOCOL_VERSION] },
						),
					);
				}
				const harnesses: Record<string, AgentCapabilities> = {};
				for (const harness of this.runtime.harnesses) {
					harnesses[harness] = this.runtime.capabilities(harness);
				}
				const result: InitializeResult = {
					protocolVersion: WIRE_PROTOCOL_VERSION,
					server: this.options.info ?? { name: "agent-server" },
					harnesses,
				};
				return transport.send(encodeResponse(id, result));
			}

			case WIRE_METHODS.turnStart: {
				const parsed = TurnStartParamsSchema.safeParse(params);
				if (!parsed.success) return this.invalidParams(transport, id, parsed.error);
				if (this.shuttingDown) {
					return transport.send(
						encodeErrorResponse(id, WIRE_ERROR_CODES.shuttingDown, "server is shutting down"),
					);
				}
				const { config, input } = parsed.data;
				if (!this.runtime.harnesses.includes(config.harness)) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.harnessNotAvailable,
							`harness not available: ${config.harness}`,
							{ available: this.runtime.harnesses },
						),
					);
				}
				const sessionId = parsed.data.sessionId ?? generateUUIDv7();
				const turnId = parsed.data.turnId ?? generateUUIDv7();
				if (this.closingSessions.has(sessionId)) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.sessionClosing,
							`session ${sessionId} is closing`,
						),
					);
				}
				const existing = this.sessions.get(sessionId);
				if (existing && existing.harness !== config.harness) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.invalidParams,
							`session ${sessionId} is bound to harness ${existing.harness}`,
						),
					);
				}
				// Idempotent admission, delegated to the runtime: a retried start
				// (same turnId, identical input) converges — ack again, never run
				// twice; `events/replay` serves anything the retryer missed. The
				// same turnId with different input is a caller bug → turnConflict.
				const request = { sessionId, turnId, input, config };
				try {
					if (this.runtime.admission(request).status !== "new") {
						return transport.send(encodeResponse(id, { sessionId, turnId, deduplicated: true }));
					}
				} catch (err) {
					if (err instanceof TurnConflictError) {
						return transport.send(
							encodeErrorResponse(id, WIRE_ERROR_CODES.turnConflict, err.message, { turnId }),
						);
					}
					throw err;
				}
				if (this.activeTurns.has(sessionId)) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.turnActive,
							`session ${sessionId} already has an active turn`,
							{ turnId: this.activeTurns.get(sessionId)?.turnId },
						),
					);
				}
				const log =
					existing ??
					new SessionLog(
						sessionId,
						config.harness,
						this.options.bufferSize ?? DEFAULT_BUFFER_SIZE,
						(this.retiredSeqs.get(sessionId) ?? 0) + 1,
					);
				this.retiredSeqs.delete(sessionId);
				this.sessions.set(sessionId, log);
				this.activeTurns.set(sessionId, { turnId, harness: config.harness });
				// Quick-ack before the first event can possibly be emitted.
				transport.send(encodeResponse(id, { sessionId, turnId }));
				void this.executeTurn({ sessionId, turnId, input, config }, log);
				return;
			}

			case WIRE_METHODS.turnCancel: {
				const parsed = TurnCancelParamsSchema.safeParse(params);
				if (!parsed.success) return this.invalidParams(transport, id, parsed.error);
				const active = this.activeTurns.get(parsed.data.sessionId);
				if (!active) {
					return transport.send(
						encodeResponse(id, { outcome: "no_active_turn" } satisfies TurnCancelResult),
					);
				}
				if (parsed.data.turnId && parsed.data.turnId !== active.turnId) {
					// Turn-stamped cancel for a turn that is no longer the active one —
					// refuse to kill its successor; report who IS active instead.
					return transport.send(
						encodeResponse(id, {
							outcome: "no_active_turn",
							activeTurnId: active.turnId,
						} satisfies TurnCancelResult),
					);
				}
				const { confirmed, hadTurn } = await this.runtime.cancel(
					active.harness,
					parsed.data.sessionId,
				);
				// An unacknowledged interrupt is NOT a cancel: the agent may still be
				// running and `turn.ended` stays the source of truth. `hadTurn: false`
				// while the server tracks an active turn is the pre-first-yield window
				// (between the turn/start quick-ack and the harness registering its
				// abortable turn) — the abort landed on nothing and the turn may run
				// to completion, so it must report `unconfirmed`, never a clean cancel.
				return transport.send(
					encodeResponse(id, {
						outcome: confirmed && hadTurn ? "cancelled" : "unconfirmed",
						turnId: active.turnId,
					} satisfies TurnCancelResult),
				);
			}

			case WIRE_METHODS.sessionClose: {
				const parsed = SessionCloseParamsSchema.safeParse(params);
				if (!parsed.success) return this.invalidParams(transport, id, parsed.error);
				const { sessionId } = parsed.data;
				if (this.closingSessions.has(sessionId)) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.sessionClosing,
							`session ${sessionId} is closing`,
						),
					);
				}
				const active = this.activeTurns.get(sessionId);
				if (active) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.turnActive,
							`session ${sessionId} has an active turn`,
							{ turnId: active.turnId },
						),
					);
				}
				const log = this.sessions.get(sessionId);
				if (!log) return transport.send(encodeResponse(id, { closed: false }));
				this.closingSessions.add(sessionId);
				try {
					await this.runtime.closeSession(log.harness, sessionId);
					// The terminal fact for CONNECTED subscribers (spec §6.1): they
					// learn the session is over from the stream, not from the RPC
					// result (which only the closer sees). It is deliberately NOT
					// replayable — the log is retired on the next line, so a
					// subscriber that was detached gets `unknownSession` from
					// `events/replay`, and that answer IS its terminal signal (the
					// session is gone; nothing more will ever be appended).
					this.broadcast(
						log.append({
							type: "session.ended",
							sessionId,
							reason: "released",
							timestamp: Date.now(),
						}),
					);
					if (log.latestSeq !== null) this.retiredSeqs.set(sessionId, log.latestSeq);
					if (this.sessions.get(sessionId) === log) this.sessions.delete(sessionId);
					return transport.send(encodeResponse(id, { closed: true }));
				} finally {
					this.closingSessions.delete(sessionId);
				}
			}

			case WIRE_METHODS.permissionRespond: {
				const parsed = PermissionRespondParamsSchema.safeParse(params);
				if (!parsed.success) return this.invalidParams(transport, id, parsed.error);
				const accepted = this.runtime.respondPermission(
					parsed.data.sessionId,
					parsed.data.requestId,
					parsed.data.outcome,
				);
				return transport.send(encodeResponse(id, { accepted }));
			}

			case WIRE_METHODS.eventsReplay: {
				const parsed = EventsReplayParamsSchema.safeParse(params);
				if (!parsed.success) return this.invalidParams(transport, id, parsed.error);
				const log = this.sessions.get(parsed.data.sessionId);
				if (!log) {
					return transport.send(
						encodeErrorResponse(
							id,
							WIRE_ERROR_CODES.unknownSession,
							`unknown session: ${parsed.data.sessionId}`,
						),
					);
				}
				return transport.send(
					encodeResponse(id, {
						events: log.replay(parsed.data.fromSeq),
						firstAvailableSeq: log.firstAvailableSeq,
						latestSeq: log.latestSeq,
					}),
				);
			}

			case WIRE_METHODS.shutdown: {
				transport.send(encodeResponse(id, {}));
				await this.shutdown();
				return;
			}

			default:
				return transport.send(
					encodeErrorResponse(id, WIRE_ERROR_CODES.methodNotFound, `unknown method: ${method}`),
				);
		}
	}

	private async executeTurn(request: RunRequest, log: SessionLog): Promise<void> {
		// Only release the busy mark if it still belongs to THIS turn — a newer
		// turn may have been accepted between our turn.ended broadcast and run()
		// settling, and its lock must survive our cleanup.
		const releaseTurn = () => {
			if (this.activeTurns.get(request.sessionId)?.turnId === request.turnId) {
				this.activeTurns.delete(request.sessionId);
			}
		};
		const sink = callbackSink((event) => {
			// Once turn.ended is on the wire the session is idle — clear the busy
			// mark here (not when run() settles) so clients acting on the event
			// never race the bookkeeping.
			if (event.type === "turn.ended") releaseTurn();
			this.broadcast(log.append(event));
		});
		try {
			await this.runtime.run(request, sink);
		} catch (err) {
			// runtime.run reports errors via events; a throw means it died before
			// emitting turn.ended — synthesize one so clients are never left hanging.
			const message = err instanceof Error ? err.message : String(err);
			this.broadcast(
				log.append({
					type: "turn.ended",
					sessionId: request.sessionId,
					turnId: request.turnId,
					stopReason: "error",
					error: { category: classifyError(err), message },
					timestamp: Date.now(),
				}),
			);
		} finally {
			releaseTurn();
		}
	}

	private broadcast(envelope: WireEventEnvelope): void {
		// In-process observers first: they see the same envelope, in the same
		// order, whether or not any transport is attached.
		for (const observer of [...this.observers]) {
			try {
				observer(envelope);
			} catch {
				// An observer's failure is its own; the event is already logged.
			}
		}
		const line = encodeNotification(WIRE_METHODS.event, envelope);
		for (const transport of this.transports) {
			try {
				transport.send(line);
			} catch {
				// One faulty transport must not starve the others; the event is
				// already in the session log, so the client heals via replay. The
				// one exception is `session.ended` from `session/close`, whose log
				// is retired in the same breath — a client that missed it learns the
				// session is over from `unknownSession` on replay instead.
			}
		}
	}

	private invalidParams(transport: WireTransport, id: JsonRpcId, error: ValidationError): void {
		transport.send(
			encodeErrorResponse(
				id,
				WIRE_ERROR_CODES.invalidParams,
				"invalid params",
				error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
			),
		);
	}
}
