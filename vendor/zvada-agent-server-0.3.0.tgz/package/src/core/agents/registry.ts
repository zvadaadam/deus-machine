import type { AgentHarness } from "../../protocol/index.ts";
import { HarnessNotFoundError } from "../utils/errors.ts";
import type { Agent } from "./base.ts";
import type { AdapterFactory } from "./types.ts";

/** Pairs each harness with its agent implementation and event adapter. */
export class AgentRegistry {
	private readonly agents = new Map<AgentHarness, Agent>();
	private readonly adapters = new Map<AgentHarness, AdapterFactory>();

	register(agent: Agent, adapter: AdapterFactory): this {
		this.agents.set(agent.harness, agent);
		this.adapters.set(agent.harness, adapter);
		return this;
	}

	getAgent(harness: AgentHarness): Agent {
		const agent = this.agents.get(harness);
		if (!agent) throw new HarnessNotFoundError(harness);
		return agent;
	}

	getAdapter(harness: AgentHarness): AdapterFactory {
		const adapter = this.adapters.get(harness);
		if (!adapter) throw new HarnessNotFoundError(harness);
		return adapter;
	}

	has(harness: AgentHarness): boolean {
		return this.agents.has(harness);
	}

	list(): AgentHarness[] {
		return [...this.agents.keys()];
	}

	async terminateAll(): Promise<void> {
		await Promise.all([...this.agents.values()].map((a) => a.terminateAll()));
	}
}
