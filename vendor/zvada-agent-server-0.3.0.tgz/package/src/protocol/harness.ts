import { z } from "zod";

/**
 * The agent harnesses this engine can drive:
 *  - `claude-code`        — Claude Code via @anthropic-ai/claude-agent-sdk (CLI under the hood)
 *  - `codex-sdk`          — OpenAI Codex via @openai/codex-sdk (wraps the `codex` CLI in exec mode)
 *  - `codex-app-server`   — OpenAI Codex via `codex app-server` (long-lived JSON-RPC subprocess)
 *  - `acp`                — any Agent Client Protocol v1 agent subprocess (`gemini --acp`,
 *                           `claude-code-acp`, `codex-acp`, ACP registry agents); the launch
 *                           command is operator-configured, never taken from the wire
 */
export const AGENT_HARNESSES = ["claude-code", "codex-sdk", "codex-app-server", "acp"] as const;
export type AgentHarness = (typeof AGENT_HARNESSES)[number];
export const AgentHarnessSchema = z.enum(AGENT_HARNESSES);

export function isAgentHarness(value: string): value is AgentHarness {
	return (AGENT_HARNESSES as readonly string[]).includes(value);
}

/**
 * How a harness handles changing the model mid-conversation:
 *  - `in-session`      — swap live without losing context (Claude `setModel`)
 *  - `restart-session` — must start a fresh underlying session (Codex)
 *  - `unsupported`     — model is fixed for the life of the session
 */
export const ModelSwitchModeSchema = z.enum(["in-session", "restart-session", "unsupported"]);
export type ModelSwitchMode = z.infer<typeof ModelSwitchModeSchema>;

/**
 * Declarative feature matrix per harness. Callers consult this to decide what
 * is safe to ask for (e.g. whether to expect resume, or whether a model change
 * forces a restart). Returned in the engine's session snapshot.
 */
export const AgentCapabilitiesSchema = z.object({
	/** Can feed multiple turns into one long-lived underlying session. */
	multiTurn: z.boolean(),
	/** Can resume a prior session from its native id. */
	sessionResume: z.boolean(),
	/** How a model change is handled. */
	modelSwitch: ModelSwitchModeSchema,
	/** Honors a thinking/reasoning-effort level. */
	thinkingLevels: z.boolean(),
	/** Accepts image input parts. */
	images: z.boolean(),
	/** Accepts external MCP servers. */
	mcpServers: z.boolean(),
	/** Can raise interactive `permission.requested` round-trips mid-turn. */
	permissionRequests: z.boolean(),
});
export type AgentCapabilities = z.infer<typeof AgentCapabilitiesSchema>;
