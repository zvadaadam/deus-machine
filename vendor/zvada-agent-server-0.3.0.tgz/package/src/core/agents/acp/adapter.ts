import type {
	ContentBlock,
	PromptResponse,
	SessionNotification,
	SessionUpdate,
	ToolCallContent,
	ToolCallUpdate,
} from "@agentclientprotocol/sdk";
import {
	DEFAULT_TOKEN_USAGE,
	type ReasoningPart,
	STOP_REASONS,
	type StopReason,
	type StreamContext,
	type TextPart,
	type ToolPart,
	completeToolPart,
	createReasoningPart,
	createTextPart,
	createToolPart,
	setToolMeta,
	startToolPart,
} from "../../../protocol/index.ts";
import type { AdapterEvent, EventTransformer, TransformResult } from "../types.ts";
import { isRecord, toToolLocations, toolKindOf } from "./mappings.ts";

/**
 * Parses ACP v1 raw events into AdapterEvents. The mapping is nearly identity:
 * our part vocabulary (ToolKind, tool status, locations) was aligned to ACP up
 * front (DESIGN D2), so chunks append to text/reasoning parts and
 * `tool_call`/`tool_call_update` upsert tool parts by `toolCallId`. Everything
 * arrives through the SDK connection, which zod-validates inbound payloads —
 * so the SDK's own types ARE the raw shapes (no defensive re-modelling).
 *
 * Raw events are the shapes AcpAgent yields:
 *  - `{method: "session/update", params: SessionNotification}`
 *  - `{method: "session/prompt_result", params: PromptResponse}` (synthetic —
 *    ACP returns the turn's stopReason as the prompt *response*, not as a
 *    notification, so the agent re-injects it into the event stream)
 *  - `{method: "error", params: {message}}` (synthetic, prompt failure)
 *
 * v1 `messageId` on chunks is optional: when present, a change opens a new
 * wire message; when absent the whole turn is one message (the processor
 * synthesizes the boundary).
 */
type RawEvent =
	| { method: "session/update"; params: SessionNotification }
	| { method: "session/prompt_result"; params: Partial<PromptResponse> }
	| { method: "error"; params: { message?: string } };

function stopReasonOf(value: string | undefined): StopReason | undefined {
	return value && (STOP_REASONS as readonly string[]).includes(value)
		? (value as StopReason)
		: undefined;
}

/** Flatten a tool call's content blocks (plus rawOutput) into one output string. */
function toolOutput(content: ToolCallContent[] | null | undefined, rawOutput: unknown): string {
	const texts = (content ?? [])
		.map((item) =>
			item.type === "content" && item.content.type === "text" ? item.content.text : "",
		)
		.filter(Boolean);
	if (texts.length) return texts.join("\n");
	return rawOutput !== undefined && rawOutput !== null ? JSON.stringify(rawOutput) : "";
}

type StreamSlot = "text" | "reasoning";

export class AcpTransformer implements EventTransformer<unknown> {
	private readonly ctx: StreamContext;
	private readonly toolParts = new Map<string, ToolPart>();
	private readonly streamParts = new Map<StreamSlot, TextPart | ReasoningPart>();
	/** messageId of the currently open wire message (undefined = implicit single message). */
	private currentMessageId?: string;
	private messageOpen = false;

	private stopReason?: StopReason;
	private finishReason?: string;
	private error?: string;

	constructor(ctx: { sessionId: string }) {
		this.ctx = { sessionId: ctx.sessionId, messageId: "" };
	}

	process(raw: unknown): AdapterEvent[] {
		const event = raw as RawEvent;
		switch (event.method) {
			case "session/update":
				return this.onUpdate(event.params.update);
			case "session/prompt_result":
				this.stopReason = stopReasonOf(event.params.stopReason);
				this.finishReason = event.params.stopReason;
				return this.finalizeStreamingParts();
			case "error":
				this.error = event.params.message ?? "acp agent error";
				this.finishReason = "error";
				// A failed prompt still closes any parts left streaming.
				return this.finalizeStreamingParts();
			default:
				return [];
		}
	}

	finish(): TransformResult {
		// ACP v1 has no per-turn token usage (the end-turn-token-usage RFD is
		// still draft); `usage_update` is a context-window gauge, not a bill.
		return {
			usage: { ...DEFAULT_TOKEN_USAGE },
			stopReason: this.stopReason,
			finishReason: this.finishReason,
			error: this.error,
		};
	}

	private onUpdate(update: SessionUpdate): AdapterEvent[] {
		switch (update.sessionUpdate) {
			case "agent_message_chunk":
				return this.chunk("text", update.content, update.messageId);
			case "agent_thought_chunk":
				return this.chunk("reasoning", update.content, update.messageId);
			case "tool_call":
				return this.toolCall(update);
			case "tool_call_update":
				return this.toolCallUpdate(update);
			case "usage_update": {
				// ACP's stable context gauge maps 1:1 onto session.usage. ACP cost is
				// {amount, currency}; ours is a bare USD number — map USD only.
				const usd = update.cost?.currency === "USD" ? update.cost.amount : undefined;
				return [
					{
						kind: "usage",
						used: update.used,
						size: update.size,
						...(usd !== undefined && { cost: usd }),
					},
				];
			}
			default:
				// plan / available_commands / current_mode / config_option /
				// session_info / usage updates have no part representation yet;
				// `includeRaw` consumers still see them.
				return [];
		}
	}

	private chunk(
		slot: StreamSlot,
		content: ContentBlock,
		messageId: string | null | undefined,
	): AdapterEvent[] {
		if (content.type !== "text" || !content.text) return [];
		const events: AdapterEvent[] = [...this.rolloverMessage(messageId ?? undefined)];
		let part = this.streamParts.get(slot);
		if (!part) {
			part =
				slot === "text"
					? createTextPart(this.ctx, "", true)
					: createReasoningPart(this.ctx, "", true);
			this.streamParts.set(slot, part);
			events.push({ kind: "part-open", part });
		}
		part.text += content.text;
		events.push(
			slot === "text"
				? { kind: "text-delta", partId: part.id, text: content.text }
				: { kind: "reasoning-delta", partId: part.id, text: content.text },
		);
		return events;
	}

	private toolCall(update: ToolCallUpdate): AdapterEvent[] {
		if (this.toolParts.has(update.toolCallId)) return this.toolCallUpdate(update); // duplicate open
		const part = this.openTool(update);
		const events: AdapterEvent[] = [{ kind: "part-open", part }];
		if (this.applyToolUpdate(part, update)) events.push({ kind: "part-update", part });
		return events;
	}

	private toolCallUpdate(update: ToolCallUpdate): AdapterEvent[] {
		// Update before (or without) its tool_call — open a part so nothing is lost.
		const part = this.toolParts.get(update.toolCallId) ?? this.openTool(update);
		this.applyToolUpdate(part, update);
		return [{ kind: "part-update", part }];
	}

	private openTool(update: ToolCallUpdate): ToolPart {
		const part = createToolPart(
			this.ctx,
			update.toolCallId,
			update.name ?? update.title ?? "tool",
			isRecord(update.rawInput) ? update.rawInput : {},
			{
				kind: toolKindOf(update.kind),
				title: update.title ?? undefined,
				locations: toToolLocations(update.locations),
			},
		);
		this.toolParts.set(update.toolCallId, part);
		return part;
	}

	/** Fold an update's meta/input/status into the part; true when it just completed. */
	private applyToolUpdate(part: ToolPart, update: ToolCallUpdate): boolean {
		setToolMeta(part, {
			kind: toolKindOf(update.kind),
			title: update.title ?? undefined,
			locations: toToolLocations(update.locations),
		});
		const terminal = part.state.status === "completed" || part.state.status === "failed";
		if (terminal) return false;
		if (isRecord(update.rawInput)) {
			if (part.state.status === "pending") startToolPart(part, update.rawInput);
			else part.state.input = update.rawInput;
		}
		if (update.status !== "completed" && update.status !== "failed") return false;
		completeToolPart(part, {
			output: toolOutput(update.content, update.rawOutput),
			isError: update.status === "failed",
		});
		return true;
	}

	/** A new v1 `messageId` closes the current wire message and opens the next. */
	private rolloverMessage(messageId: string | undefined): AdapterEvent[] {
		if (!messageId) {
			// No id: everything belongs to one implicit message; open it lazily so
			// the assistant role is explicit (parts still work without it).
			if (this.messageOpen) return [];
			this.messageOpen = true;
			return [{ kind: "message-start", role: "assistant" }];
		}
		if (messageId === this.currentMessageId) return [];
		const events: AdapterEvent[] = [];
		if (this.messageOpen) {
			events.push(...this.finalizeStreamingParts(), { kind: "message-end" });
		}
		this.currentMessageId = messageId;
		this.messageOpen = true;
		this.streamParts.clear();
		events.push({ kind: "message-start", role: "assistant" });
		return events;
	}

	/** Mark still-streaming text/reasoning parts done (turn or message boundary). */
	private finalizeStreamingParts(): AdapterEvent[] {
		const events: AdapterEvent[] = [];
		for (const part of this.streamParts.values()) {
			if (part.state === "streaming") {
				part.state = "done";
				events.push({ kind: "part-update", part });
			}
		}
		return events;
	}
}

export function createAcpTransformer(ctx: { sessionId: string }): EventTransformer {
	return new AcpTransformer(ctx);
}
