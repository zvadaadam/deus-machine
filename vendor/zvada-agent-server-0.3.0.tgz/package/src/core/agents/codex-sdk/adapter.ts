import {
	DEFAULT_TOKEN_USAGE,
	type Part,
	type ReasoningPart,
	type StopReason,
	type StreamContext,
	type TextPart,
	type TokenUsage,
	type ToolPart,
	completeToolPart,
	createReasoningPart,
	createTextPart,
	createToolPart,
} from "../../../protocol/index.ts";
import {
	type CodexToolDescriptor,
	type CodexToolItem,
	codexToolDescriptor,
} from "../codex-items.ts";
import type { AdapterEvent, EventTransformer, TransformResult } from "../types.ts";

/**
 * Parses `@openai/codex-sdk` ThreadEvents into AdapterEvents.
 *
 * Codex streams at item granularity (item.started/updated/completed), not token
 * by token. For agent_message/reasoning items we still synthesize text deltas by
 * diffing successive snapshots, so downstream consumers get incremental text.
 * command_execution / file_change / mcp_tool_call / web_search items become tool
 * parts that complete when the item reaches a terminal status.
 */

type Phase = "started" | "updated" | "completed";

/** One SDK thread item: the shared codex tool vocabulary plus streaming fields. */
interface ThreadItem extends CodexToolItem {
	type: string;
	text?: string;
	message?: string;
}
interface CodexEvent {
	type: string;
	thread_id?: string;
	item?: ThreadItem;
	usage?: {
		input_tokens?: number;
		cached_input_tokens?: number;
		output_tokens?: number;
		reasoning_output_tokens?: number;
	};
	error?: { message?: string };
	message?: string;
}

export class CodexSdkTransformer implements EventTransformer<unknown> {
	private readonly ctx: StreamContext;
	private readonly partByItem = new Map<string, Part>();
	private readonly textLenByItem = new Map<string, number>();

	private usage: TokenUsage = { ...DEFAULT_TOKEN_USAGE };
	private stopReason?: StopReason;
	private finishReason?: string;
	private error?: string;

	constructor(ctx: { sessionId: string }) {
		this.ctx = { sessionId: ctx.sessionId, messageId: "" };
	}

	process(raw: unknown): AdapterEvent[] {
		const ev = raw as CodexEvent;
		switch (ev.type) {
			case "item.started":
				return ev.item ? this.handleItem(ev.item, "started") : [];
			case "item.updated":
				return ev.item ? this.handleItem(ev.item, "updated") : [];
			case "item.completed":
				return ev.item ? this.handleItem(ev.item, "completed") : [];
			case "turn.completed": {
				// Completion supersedes earlier stream notices: codex emits non-fatal
				// diagnostics (retry / skills-context-budget notices) as `error`
				// events; the fatal signal is `turn.failed`, which arrives *instead*
				// of completion.
				this.error = undefined;
				this.finishReason = "completed";
				this.stopReason = "end_turn";
				if (!ev.usage) return [];
				this.usage = {
					input: ev.usage.input_tokens ?? 0,
					output: ev.usage.output_tokens ?? 0,
					reasoning: ev.usage.reasoning_output_tokens ?? 0,
					cache: { read: ev.usage.cached_input_tokens ?? 0, write: 0 },
				};
				// The SDK reports usage only at turn end; input covers the full prompt
				// context, so it doubles as the context gauge.
				const used =
					(ev.usage.input_tokens ?? 0) +
					(ev.usage.cached_input_tokens ?? 0) +
					(ev.usage.output_tokens ?? 0);
				return [{ kind: "usage", used }];
			}
			case "turn.failed":
				this.error = ev.error?.message ?? "codex turn failed";
				return [];
			case "error":
				this.error = ev.message ?? "codex stream error";
				return [];
			default:
				return [];
		}
	}

	finish(): TransformResult {
		return {
			usage: this.usage,
			stopReason: this.stopReason,
			finishReason: this.finishReason,
			error: this.error,
		};
	}

	private handleItem(item: ThreadItem, phase: Phase): AdapterEvent[] {
		switch (item.type) {
			case "agent_message":
				return this.handleText(item, phase, "text");
			case "reasoning":
				return this.handleText(item, phase, "reasoning");
			case "error":
				this.error = item.message ?? "codex item error";
				return [];
			default: {
				// command_execution / file_change / mcp_tool_call / web_search share
				// one descriptor vocabulary; unknown item types produce nothing.
				const d = codexToolDescriptor(item.type);
				return d ? this.handleTool(item, phase, d) : [];
			}
		}
	}

	private handleText(item: ThreadItem, phase: Phase, kind: "text" | "reasoning"): AdapterEvent[] {
		const events: AdapterEvent[] = [];
		let part = this.partByItem.get(item.id) as TextPart | ReasoningPart | undefined;
		const isNew = !part;
		if (!part) {
			part =
				kind === "text"
					? createTextPart(this.ctx, "", true)
					: createReasoningPart(this.ctx, "", true);
			this.partByItem.set(item.id, part);
			this.textLenByItem.set(item.id, 0);
		}
		// Open the part only while it will keep streaming. When the item is already
		// complete on first sight (Codex often sends only `item.completed`), emit a
		// single finalized snapshot below: pushing both part-open and part-update
		// for the same in-place-mutated object doubles the text, since the processor
		// clones each at emit time and by then both read as "done".
		if (isNew && phase !== "completed") events.push({ kind: "part-open", part });

		const text = item.text ?? "";
		const prevLen = this.textLenByItem.get(item.id) ?? 0;
		if (text.length > prevLen) {
			const suffix = text.slice(prevLen);
			part.text = text;
			this.textLenByItem.set(item.id, text.length);
			// Skip the delta for an item that's already complete on first sight: it
			// never opened a part, so the processor would drop the orphan delta
			// anyway. The finalized part-update below carries the full text.
			if (!(isNew && phase === "completed")) {
				events.push(
					kind === "text"
						? { kind: "text-delta", partId: part.id, text: suffix }
						: { kind: "reasoning-delta", partId: part.id, text: suffix },
				);
			}
		}

		if (phase === "completed") {
			part.text = text || part.text;
			part.state = "done";
			events.push({ kind: "part-update", part });
		}
		return events;
	}

	private handleTool(item: ThreadItem, phase: Phase, d: CodexToolDescriptor): AdapterEvent[] {
		const events: AdapterEvent[] = [];
		let part = this.partByItem.get(item.id) as ToolPart | undefined;
		const isNew = !part;
		if (!part) {
			part = createToolPart(this.ctx, item.id, d.toolName(item), d.input(item), d.meta(item));
			this.partByItem.set(item.id, part);
		}
		// As in handleText: skip the open when the tool is already complete on
		// arrival, so we emit one finalized snapshot rather than two aliased ones.
		if (isNew && phase !== "completed") events.push({ kind: "part-open", part });
		if (phase === "completed") {
			completeToolPart(part, d.result(item));
			events.push({ kind: "part-update", part });
		}
		return events;
	}
}

export function createCodexSdkTransformer(ctx: { sessionId: string }): EventTransformer {
	return new CodexSdkTransformer(ctx);
}
