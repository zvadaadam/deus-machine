import {
	AsyncQueue,
	type DecodedEventsReplayResult,
	type DecodedLifecycleEvent,
	type DecodedWireEventEnvelope,
	type InitializeResult,
	InitializeResultSchema,
	type JsonRpcId,
	type PermissionOutcome,
	PermissionRespondResultSchema,
	SessionCloseResultSchema,
	ShutdownResultSchema,
	type TurnCancelResult,
	TurnCancelResultSchema,
	type TurnEndedEvent,
	type TurnStartParams,
	TurnStartResultSchema,
	type UnknownEvent,
	WIRE_ERROR_CODES,
	WIRE_METHODS,
	WIRE_PROTOCOL_VERSION,
	type WireImplementationInfo,
	type WireTransport,
	createSeqCursor,
	decodeEventsReplayResult,
	decodeWireEventEnvelope,
	decodeWireMessage,
	encodeRequest,
	generateUUIDv7,
	isUnknownEvent,
} from "../protocol/index.ts";
import {
	type SpawnServerOptions,
	type WebSocketLike,
	connectTransport,
	socketTransport,
	spawnTransport,
} from "./transports.ts";

/** The server answered a request with a JSON-RPC error. */
export class WireRequestError extends Error {
	override readonly name = "WireRequestError";
	constructor(
		readonly code: number,
		message: string,
		readonly data?: unknown,
	) {
		super(message);
	}
}

/** The transport dropped (and reconnection, if enabled, gave up). */
export class ConnectionClosedError extends Error {
	override readonly name = "ConnectionClosedError";
}

/**
 * Events were lost irrecoverably: the replay window was evicted or the server
 * restarted. The consumer's local view of the session is stale.
 */
export class EventGapError extends Error {
	override readonly name = "EventGapError";
}

/**
 * A running turn: consume `events` (ends after `turn.ended`) or await `result`.
 *
 * `events` yields `UnknownEvent`s too (Law 6): a newer server's event type is
 * delivered in order rather than dropped, so consumers persist and forward it.
 * Narrow with `isUnknownEvent` before switching on a known `type`;
 * `reduceConversation` already accepts the union as-is.
 */
export interface TurnHandle {
	sessionId: string;
	turnId: string;
	events: AsyncIterableIterator<DecodedLifecycleEvent | UnknownEvent>;
	result: Promise<TurnEndedEvent>;
}

export interface AgentServerClientOptions {
	/**
	 * Redial and replay missed events on transport drop. Defaults to true for
	 * `connect`, false for `spawn`/`attach` (a respawned server is a new
	 * process with empty session state).
	 */
	reconnect?: boolean;
	maxReconnectAttempts?: number;
	/** Base reconnect delay; grows exponentially, capped at 10s. */
	reconnectDelayMs?: number;
	requestTimeoutMs?: number;
	/** Attempts to heal one sequence gap before failing its turn. Default 3. */
	maxReplayAttempts?: number;
	/** Delay between failed replay requests. Defaults to reconnectDelayMs. */
	replayRetryDelayMs?: number;
	/** Sent in `initialize`. */
	clientInfo?: WireImplementationInfo;
}

interface PendingRequest {
	resolve: (raw: unknown) => void;
	reject: (error: unknown) => void;
	timer: ReturnType<typeof setTimeout>;
}

interface InternalTurn {
	turnId: string;
	queue: AsyncQueue<DecodedLifecycleEvent | UnknownEvent>;
	resolveResult: (event: TurnEndedEvent) => void;
	rejectResult: (error: unknown) => void;
}

interface ResultSchema<T> {
	safeParse(raw: unknown): { success: true; data: T } | { success: false };
}

/**
 * `events/replay` decoded the Law-6 way. Using `EventsReplayResultSchema`
 * here would embed the closed event union in the very path that heals a gap,
 * so a single unknown event type in the buffer would fail the replay, retry,
 * and take the turn handle down with an `EventGapError`.
 */
const REPLAY_RESULT: ResultSchema<DecodedEventsReplayResult> = {
	safeParse(raw) {
		try {
			return { success: true, data: decodeEventsReplayResult(raw) };
		} catch {
			return { success: false };
		}
	},
};

type TransportFactory = () => Promise<WireTransport> | WireTransport;

/**
 * Typed client for the agent-server wire. Turns are quick-ack: `runTurn`
 * resolves once the server accepts the turn and hands back an async iterable
 * that yields every lifecycle event for the session, ending with `turn.ended`.
 * Per-session `seq` is tracked so duplicates are dropped, in-stream gaps are
 * healed via `events/replay`, and — in `connect` mode — a dropped socket is
 * redialed and resynced transparently.
 */
export class AgentServerClient {
	private transport: WireTransport | null = null;
	private nextId = 1;
	private readonly pending = new Map<JsonRpcId, PendingRequest>();
	/** Per-session seq discipline — the shared `/protocol` implementation. */
	private readonly cursor = createSeqCursor();
	private readonly heldBack = new Map<string, DecodedWireEventEnvelope[]>();
	/** The server process behind the transport, learned at `initialize`. */
	private serverInstanceId: string | undefined;
	private readonly syncing = new Set<string>();
	private readonly eventHandlers = new Set<(envelope: DecodedWireEventEnvelope) => void>();
	private readonly turnBySession = new Map<string, InternalTurn>();
	private initializePromise: Promise<InitializeResult> | null = null;
	private closed = false;
	private reconnecting = false;

	private constructor(
		private readonly factory: TransportFactory,
		private readonly options: AgentServerClientOptions,
		private readonly reconnectEnabled: boolean,
	) {}

	/**
	 * Bring your own transport: the factory is invoked for the initial
	 * connection and for every reconnect attempt (reconnect defaults to true).
	 */
	static async fromTransportFactory(
		factory: TransportFactory,
		options: AgentServerClientOptions = {},
	): Promise<AgentServerClient> {
		const client = new AgentServerClient(factory, options, options.reconnect ?? true);
		await client.openTransport();
		return client;
	}

	/** Spawn an agent-server subprocess and talk over its stdio. */
	static async spawn(
		spawnOpts: SpawnServerOptions,
		options: AgentServerClientOptions = {},
	): Promise<AgentServerClient> {
		const client = new AgentServerClient(
			() => spawnTransport(spawnOpts),
			options,
			options.reconnect ?? false,
		);
		await client.openTransport();
		return client;
	}

	/** Dial a listening agent-server (reconnects by default). */
	static async connect(
		url: string,
		options: AgentServerClientOptions = {},
	): Promise<AgentServerClient> {
		const client = new AgentServerClient(
			() => connectTransport(url),
			options,
			options.reconnect ?? true,
		);
		await client.openTransport();
		return client;
	}

	/** Wrap an already-connected socket (e.g. the accepted end of a dial-out). */
	static async attach(
		socket: WebSocketLike | WireTransport,
		options: AgentServerClientOptions = {},
	): Promise<AgentServerClient> {
		const transport = "onLine" in socket ? socket : socketTransport(socket);
		let used = false;
		const client = new AgentServerClient(
			() => {
				if (used) throw new ConnectionClosedError("attached socket cannot be re-opened");
				used = true;
				return transport;
			},
			options,
			false,
		);
		await client.openTransport();
		return client;
	}

	// ---- public API --------------------------------------------------------

	/** Handshake (memoized). Called lazily by `runTurn`/`startTurn`. */
	initialize(): Promise<InitializeResult> {
		this.initializePromise ??= this.request(
			WIRE_METHODS.initialize,
			{ protocolVersion: WIRE_PROTOCOL_VERSION, client: this.options.clientInfo },
			InitializeResultSchema,
		)
			.then((result) => {
				if (result.protocolVersion !== WIRE_PROTOCOL_VERSION) {
					throw new WireRequestError(
						WIRE_ERROR_CODES.protocolVersionMismatch,
						`server selected unsupported protocol version: ${result.protocolVersion}`,
						{ supported: [WIRE_PROTOCOL_VERSION] },
					);
				}
				// The restart question, answered by the handshake instead of
				// inferred from seq patterns: a changed instanceId means every
				// session log we were tracking belongs to a dead process.
				if (this.serverInstanceId !== undefined && this.serverInstanceId !== result.instanceId) {
					this.adoptFreshLogs();
				}
				this.serverInstanceId = result.instanceId;
				return result;
			})
			.catch((err) => {
				this.initializePromise = null;
				throw err;
			});
		return this.initializePromise;
	}

	/**
	 * The server process we were talking to is gone; its logs died with it.
	 * Drop every per-session cursor and queue so the reconnect resync replays
	 * each fresh log from seq 1. Local views may be stale relative to the fresh
	 * logs; consumers with durable state resnapshot on their side.
	 */
	private adoptFreshLogs(): void {
		// Active turns first: their logs died with the old process, and no fresh
		// log will ever emit THEIR turn.ended — an un-failed handle hangs forever
		// (a session id the fresh process happens to reuse would even feed it
		// someone else's events).
		for (const sessionId of [...this.turnBySession.keys()]) {
			this.failTurn(
				sessionId,
				new EventGapError(
					`server instance changed; the turn's session log died with the old process`,
				),
			);
		}
		for (const sessionId of this.cursor.sessions()) this.cursor.reset(sessionId);
		this.heldBack.clear();
	}

	/**
	 * Start a turn and stream it. Ids are minted client-side when omitted so
	 * events arriving around the ack are never dropped.
	 */
	async runTurn(params: TurnStartParams): Promise<TurnHandle> {
		await this.initialize();
		const sessionId = params.sessionId ?? generateUUIDv7();
		const turnId = params.turnId ?? generateUUIDv7();
		if (this.turnBySession.has(sessionId)) {
			throw new Error(`session ${sessionId} already has an active turn`);
		}
		const queue = new AsyncQueue<DecodedLifecycleEvent | UnknownEvent>();
		let resolveResult!: (event: TurnEndedEvent) => void;
		let rejectResult!: (error: unknown) => void;
		const result = new Promise<TurnEndedEvent>((resolve, reject) => {
			resolveResult = resolve;
			rejectResult = reject;
		});
		// Consumers may only iterate `events`; don't surface an unhandled rejection.
		result.catch(() => undefined);
		this.turnBySession.set(sessionId, { turnId, queue, resolveResult, rejectResult });
		try {
			await this.request(
				WIRE_METHODS.turnStart,
				{ ...params, sessionId, turnId },
				TurnStartResultSchema,
			);
		} catch (err) {
			this.turnBySession.delete(sessionId);
			queue.fail(err);
			rejectResult(err);
			throw err;
		}
		return { sessionId, turnId, events: queue, result };
	}

	/** Quick-ack only — observe the turn via `onEvent` / `replay`. */
	async startTurn(params: TurnStartParams): Promise<{ sessionId: string; turnId: string }> {
		await this.initialize();
		return this.request(WIRE_METHODS.turnStart, params, TurnStartResultSchema);
	}

	/** Answer a `permission.requested` event. */
	async respondPermission(
		sessionId: string,
		requestId: string,
		outcome: PermissionOutcome,
	): Promise<boolean> {
		const { accepted } = await this.request(
			WIRE_METHODS.permissionRespond,
			{ sessionId, requestId, outcome },
			PermissionRespondResultSchema,
		);
		return accepted;
	}

	/**
	 * Cancel the session's active turn; resolves once cancellation propagated.
	 * Pass `turnId` to make the cancel turn-stamped: a late cancel meant for a
	 * finished turn then returns `{outcome: "no_active_turn", activeTurnId}`
	 * instead of killing the turn that replaced it. `{outcome: "unconfirmed"}`
	 * means the harness did not acknowledge the interrupt — the agent may still
	 * be running; `turn.ended` remains the source of truth.
	 */
	cancelTurn(sessionId: string, turnId?: string): Promise<TurnCancelResult> {
		return this.request(
			WIRE_METHODS.turnCancel,
			{ sessionId, ...(turnId !== undefined ? { turnId } : {}) },
			TurnCancelResultSchema,
		);
	}

	/** Release an idle session's replay history and harness-native resources. */
	async closeSession(sessionId: string): Promise<boolean> {
		if (this.turnBySession.has(sessionId)) {
			throw new Error(`cannot close session ${sessionId} while its turn is active`);
		}
		const { closed } = await this.request(
			WIRE_METHODS.sessionClose,
			{ sessionId },
			SessionCloseResultSchema,
		);
		// Keep the seq watermark: the server continues a reused id's seq where the
		// closed incarnation stopped, so post-reuse events stay contiguous for this
		// client too. A genuine server restart surfaces as a transport drop, and the
		// resync's unknownSession path resets the watermark then.
		this.heldBack.delete(sessionId);
		this.syncing.delete(sessionId);
		return closed;
	}

	/** Fetch buffered events (`seq >= fromSeq`) without touching seq tracking. */
	replay(sessionId: string, fromSeq: number): Promise<DecodedEventsReplayResult> {
		return this.request(WIRE_METHODS.eventsReplay, { sessionId, fromSeq }, REPLAY_RESULT);
	}

	/** Firehose of sequenced events across all sessions (post-dedupe, in order). */
	onEvent(handler: (envelope: DecodedWireEventEnvelope) => void): () => void {
		this.eventHandlers.add(handler);
		return () => this.eventHandlers.delete(handler);
	}

	/** Ask the server to shut down, then close this client. */
	async shutdownServer(): Promise<void> {
		await this.request(WIRE_METHODS.shutdown, {}, ShutdownResultSchema).catch(() => undefined);
		await this.close();
	}

	async close(): Promise<void> {
		if (this.closed) return;
		this.closed = true;
		const reason = new ConnectionClosedError("client closed");
		this.failPending(reason);
		this.failAllTurns(reason);
		this.transport?.close();
		this.transport = null;
	}

	// ---- transport lifecycle -----------------------------------------------

	private async openTransport(): Promise<void> {
		const transport = await this.factory();
		if (this.closed) {
			transport.close();
			throw new ConnectionClosedError("client closed while connecting");
		}
		if (transport.closed) throw new ConnectionClosedError("transport opened already closed");
		this.transport = transport;
		transport.onLine((line) => this.handleLine(line));
		transport.onClose((reason) => this.handleTransportClose(transport, reason));
	}

	private handleTransportClose(transport: WireTransport, reason?: string): void {
		// A late close from a superseded transport must not tear down the current one.
		if (this.transport !== transport) return;
		this.transport = null;
		this.failPending(new ConnectionClosedError(reason ?? "connection closed"));
		if (this.closed) return;
		if (!this.reconnectEnabled) {
			this.closed = true;
			this.failAllTurns(new ConnectionClosedError(reason ?? "connection closed"));
			return;
		}
		void this.reconnectLoop();
	}

	private async reconnectLoop(): Promise<void> {
		if (this.reconnecting) return;
		this.reconnecting = true;
		const maxAttempts = this.options.maxReconnectAttempts ?? 8;
		const base = this.options.reconnectDelayMs ?? 250;
		try {
			for (let attempt = 0; attempt < maxAttempts && !this.closed; attempt++) {
				await sleep(Math.min(10_000, base * 2 ** Math.min(attempt, 5)));
				if (this.closed) break;
				try {
					await this.openTransport();
					if (this.closed || !this.transport) continue;
					// Re-handshake: the transport may have reconnected to a DIFFERENT
					// process (or a different build). A version mismatch fails loudly
					// here instead of silently mixing dialects, and a changed
					// instanceId adopts the fresh logs before any resync runs.
					this.initializePromise = null;
					await this.initialize();
					if (this.closed || !this.transport) continue;
					// Heal every tracked session — including turns that saw no event
					// before the drop (or none after it): without a resync they would
					// never receive their turn.ended and would hang forever.
					const sessionIds = new Set([...this.cursor.sessions(), ...this.turnBySession.keys()]);
					for (const sessionId of sessionIds) void this.syncSession(sessionId);
					if (!this.transport) continue;
					return;
				} catch {
					// next attempt
				}
			}
			if (!this.closed) {
				this.closed = true;
				this.failAllTurns(new ConnectionClosedError("reconnect failed"));
			}
		} finally {
			this.reconnecting = false;
		}
	}

	// ---- inbound dispatch ----------------------------------------------------

	private handleLine(line: string): void {
		const msg = decodeWireMessage(line);
		if (msg.kind === "response") {
			if (msg.id === null) return; // protocol-level error for an unparseable line
			const pending = this.pending.get(msg.id);
			if (!pending) return;
			this.pending.delete(msg.id);
			clearTimeout(pending.timer);
			if (msg.error)
				pending.reject(new WireRequestError(msg.error.code, msg.error.message, msg.error.data));
			else pending.resolve(msg.result);
			return;
		}
		if (msg.kind === "notification" && msg.method === WIRE_METHODS.event) {
			try {
				// Law 6: an unknown event TYPE is preserved and still advances seq.
				// Only a malformed envelope or a malformed KNOWN event lands here —
				// a server bug, which must not be papered over by advancing past it.
				this.handleEnvelope(decodeWireEventEnvelope(msg.params));
			} catch {
				// undeliverable; the next event's seq gap raises it honestly
			}
		}
	}

	/**
	 * Seq discipline: drop duplicates, deliver contiguous, hold back and heal
	 * gaps via replay. Events are always delivered in seq order per session.
	 * The verdicts come from the shared `SeqCursor`; this method owns only what
	 * a client does about them (queue, replay, deliver).
	 */
	private handleEnvelope(envelope: DecodedWireEventEnvelope): void {
		const sessionId = envelope.sessionId;
		// While a replay is in flight, every envelope queues: the drain re-runs
		// the cursor over the merged (replayed + live) backlog in seq order.
		if (this.syncing.has(sessionId)) {
			this.holdBack(sessionId, envelope);
			return;
		}
		switch (this.cursor.advance(sessionId, envelope.seq)) {
			case "duplicate":
				return; // e.g. a replay overlap
			case "reset":
				// Defense-in-depth. Real restarts are detected by the handshake
				// (`instanceId` at re-initialize) before any envelope flows — this
				// arm fires only if a fresh log appears with NO transport drop,
				// which no current topology produces. If it does: the queue is
				// dead-log state, the fresh frame is authoritative.
				this.heldBack.delete(sessionId);
				this.deliver(envelope);
				return;
			case "deliver":
				this.deliver(envelope);
				this.drainHeld(sessionId);
				return;
			case "gap":
				this.holdBack(sessionId, envelope);
				void this.syncSession(sessionId);
				return;
		}
	}

	private holdBack(sessionId: string, envelope: DecodedWireEventEnvelope): void {
		const held = this.heldBack.get(sessionId) ?? [];
		held.push(envelope);
		this.heldBack.set(sessionId, held);
	}

	private drainHeld(sessionId: string): void {
		const held = this.heldBack.get(sessionId);
		if (!held?.length) return;
		held.sort((a, b) => a.seq - b.seq);
		while (held.length) {
			const next = held[0] as DecodedWireEventEnvelope;
			// `gap` leaves the cursor untouched, so breaking here is safe: the
			// envelope stays queued for the replay that fills the hole.
			const verdict = this.cursor.advance(sessionId, next.seq);
			if (verdict === "gap") break;
			held.shift();
			if (verdict === "reset") {
				// Defense-in-depth only (see the reset arm in handleEnvelope):
				// drop the queue, deliver the fresh frame, resync for its tail.
				held.length = 0;
				this.deliver(next);
				void this.syncSession(sessionId);
				break;
			}
			if (verdict !== "duplicate") this.deliver(next);
		}
		if (!held.length) this.heldBack.delete(sessionId);
	}

	private async syncSession(sessionId: string): Promise<void> {
		if (this.syncing.has(sessionId) || this.closed || !this.transport) return;
		this.syncing.add(sessionId);
		try {
			const maxAttempts = Math.max(1, this.options.maxReplayAttempts ?? 3);
			const retryDelay = this.options.replayRetryDelayMs ?? this.options.reconnectDelayMs ?? 250;
			for (let attempt = 1; attempt <= maxAttempts && !this.closed && this.transport; attempt++) {
				const fromSeq = this.cursor.last(sessionId) + 1;
				try {
					const replayed = await this.replay(sessionId, fromSeq);
					if (replayed.firstAvailableSeq !== null && replayed.firstAvailableSeq > fromSeq) {
						// The prefix was evicted — the gap is unfillable. Fail the turn
						// handle (its part reconstruction is broken) and jump forward.
						this.failTurn(
							sessionId,
							new EventGapError(
								`events ${fromSeq}..${replayed.firstAvailableSeq - 1} for session ${sessionId} were evicted`,
							),
						);
						this.cursor.seek(sessionId, replayed.firstAvailableSeq - 1);
					}
					for (const envelope of replayed.events) this.holdBack(sessionId, envelope);
					break;
				} catch (err) {
					if (err instanceof WireRequestError && err.code === WIRE_ERROR_CODES.unknownSession) {
						this.failTurn(
							sessionId,
							new EventGapError(`session ${sessionId} is unknown to the server (restarted?)`),
						);
						this.cursor.reset(sessionId);
						this.heldBack.delete(sessionId);
						break;
					}
					if (!this.transport || this.closed) break; // reconnect performs a fresh resync
					if (attempt === maxAttempts) {
						this.failTurn(
							sessionId,
							new EventGapError(
								`failed to replay events from ${fromSeq} for session ${sessionId} after ${maxAttempts} attempts`,
							),
						);
						this.heldBack.delete(sessionId);
						break;
					}
					await sleep(retryDelay);
				}
			}
		} finally {
			this.syncing.delete(sessionId);
		}
		this.drainHeld(sessionId);
	}

	/** Dispatch an envelope the cursor already accepted (it owns the watermark). */
	private deliver(envelope: DecodedWireEventEnvelope): void {
		for (const handler of [...this.eventHandlers]) {
			try {
				handler(envelope);
			} catch {
				// consumer handler errors must not break dispatch
			}
		}
		const turn = this.turnBySession.get(envelope.sessionId);
		if (!turn) return;
		const event = envelope.event;
		turn.queue.push(event);
		if (!isUnknownEvent(event) && event.type === "turn.ended" && event.turnId === turn.turnId) {
			this.turnBySession.delete(envelope.sessionId);
			turn.resolveResult(event);
			turn.queue.end();
		}
	}

	private failTurn(sessionId: string, error: Error): void {
		const turn = this.turnBySession.get(sessionId);
		if (!turn) return;
		this.turnBySession.delete(sessionId);
		turn.rejectResult(error);
		turn.queue.fail(error);
	}

	private failAllTurns(error: Error): void {
		for (const sessionId of [...this.turnBySession.keys()]) this.failTurn(sessionId, error);
	}

	private failPending(error: Error): void {
		for (const [, pending] of this.pending) {
			clearTimeout(pending.timer);
			pending.reject(error);
		}
		this.pending.clear();
	}

	// ---- outbound ------------------------------------------------------------

	private request<T>(method: string, params: unknown, schema: ResultSchema<T>): Promise<T> {
		if (this.closed) return Promise.reject(new ConnectionClosedError("client closed"));
		const transport = this.transport;
		if (!transport) return Promise.reject(new ConnectionClosedError("not connected"));
		const id = this.nextId++;
		const timeoutMs = this.options.requestTimeoutMs ?? 30_000;
		return new Promise<T>((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending.delete(id);
				reject(
					new WireRequestError(WIRE_ERROR_CODES.internalError, `request timed out: ${method}`),
				);
			}, timeoutMs);
			this.pending.set(id, {
				resolve: (raw) => {
					const parsed = schema.safeParse(raw);
					if (parsed.success) resolve(parsed.data);
					else
						reject(
							new WireRequestError(WIRE_ERROR_CODES.internalError, `malformed ${method} result`),
						);
				},
				reject,
				timer,
			});
			try {
				transport.send(encodeRequest(id, method, params));
			} catch (error) {
				clearTimeout(timer);
				this.pending.delete(id);
				reject(error);
			}
		});
	}
}

function sleep(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
