import { z } from "zod";

/**
 * A UI-authored span over the text (mentions, pills, inline references) that
 * survives the round trip through the model, the user echo, and persistence.
 * The model sees plain text; `byteRange` is [start, end) over the UTF-8 bytes
 * of the parent `text`.
 */
export const TextElementSchema = z.object({
	byteRange: z.tuple([z.number().int().nonnegative(), z.number().int().nonnegative()]),
	/** Human-readable placeholder for the element, displayed in the UI. */
	placeholder: z.string().optional(),
});
export type TextElement = z.infer<typeof TextElementSchema>;

/** Inbound user content for a turn: plain text, or multimodal blocks. */
export const TextPartInputSchema = z.object({
	type: z.literal("text"),
	id: z.string().optional(),
	text: z.string().min(1),
	elements: z.array(TextElementSchema).optional(),
});
export type TextPartInput = z.infer<typeof TextPartInputSchema>;

export const ImagePartInputSchema = z
	.object({
		type: z.literal("image"),
		id: z.string().optional(),
		/** Either a URL or base64 `data` (one is required). */
		url: z.string().min(1).optional(),
		data: z.string().min(1).optional(),
		mimeType: z.string(),
		filename: z.string().optional(),
	})
	.refine((part) => (part.data !== undefined) !== (part.url !== undefined), {
		// Exactly one, matching the OUTPUT part schemas' `exactlyOneSource`: an
		// input carrying both would echo as a part every consumer's decode
		// rejects — the ambiguity dies at the boundary, not on the stream.
		message: "image input requires exactly one of data | url",
	});
export type ImagePartInput = z.infer<typeof ImagePartInputSchema>;

export const FilePartInputSchema = z
	.object({
		type: z.literal("file"),
		id: z.string().optional(),
		url: z.string().min(1).optional(),
		data: z.string().min(1).optional(),
		mimeType: z.string(),
		filename: z.string().optional(),
	})
	.refine((part) => (part.data !== undefined) !== (part.url !== undefined), {
		message: "file input requires exactly one of data | url",
	});
export type FilePartInput = z.infer<typeof FilePartInputSchema>;

export const PartInputSchema = z.discriminatedUnion("type", [
	TextPartInputSchema,
	ImagePartInputSchema,
	FilePartInputSchema,
]);
export type PartInput = z.infer<typeof PartInputSchema>;

/** A turn's input is either a bare string or a list of typed parts. */
export const AgentInputSchema = z.union([z.string(), z.array(PartInputSchema)]);
export type AgentInput = z.infer<typeof AgentInputSchema>;

/**
 * Decode an untrusted value (an HTTP body, a queue message, a DB column) into
 * an `AgentInput`, or throw with a message that names the offending path.
 *
 * The schema is the contract; a hand-rolled decoder in front of it is where
 * tolerance for shapes the engine never accepted creeps in (`content` arrays,
 * bare `{text}` objects) and where the error a product shows its user
 * degrades to "invalid input". (An empty STRING is valid input — deliberately:
 * "continue" semantics belong to the product, not the schema.)
 */
export function parseAgentInput(value: unknown): AgentInput {
	const parsed = AgentInputSchema.safeParse(value);
	if (parsed.success) return parsed.data;
	// A union failure's own message is just "Invalid input" — the useful paths
	// and messages live one level down, in the per-branch issue lists.
	const flattened = parsed.error.issues.flatMap((issue) =>
		issue.code === "invalid_union" ? issue.errors.flat() : [issue],
	);
	const detail = flattened
		.map((issue) => `${issue.path.length ? `${issue.path.join(".")}: ` : ""}${issue.message}`)
		.join("; ");
	throw new Error(`invalid agent input: ${detail}`, { cause: parsed.error });
}

/** Collapse an AgentInput down to the text the model sees first. */
export function inputToText(input: AgentInput): string {
	if (typeof input === "string") return input;
	return input
		.filter((p): p is TextPartInput => p.type === "text")
		.map((p) => p.text)
		.join("\n\n");
}
