import type { Part, StopReason, TokenUsage } from "../../protocol/index.ts";

/**
 * The normalized intermediate an adapter emits while consuming raw harness
 * events. The engine's EventProcessor turns these into wire `LifecycleEvent`s,
 * assigning message/part indices and ids. Keeping deltas here (rather than
 * diffing snapshots downstream) lets each adapter express its harness's exact
 * streaming granularity — token-level for Claude / Codex app-server,
 * item-level for the Codex SDK.
 */
export type AdapterEvent =
	| { kind: "message-start"; role: "assistant" | "user" }
	| { kind: "message-end" }
	/** A new part appears (streaming text begins, a tool call opens, etc.). */
	| { kind: "part-open"; part: Part }
	/** A full new snapshot of an existing part (tool -> running/completed, text finalized). */
	| { kind: "part-update"; part: Part }
	| { kind: "text-delta"; partId: string; text: string }
	| { kind: "reasoning-delta"; partId: string; text: string }
	| {
			kind: "tool-input-delta";
			partId: string;
			toolCallId: string;
			toolName: string;
			input: string;
	  }
	/** Context-window gauge snapshot (→ `session.usage`). */
	| { kind: "usage"; used: number; size?: number; cost?: number }
	/** History-compaction boundary (→ the `session.compaction` entity). */
	| { kind: "compacted"; trigger?: string; preTokens?: number; postTokens?: number };

/** Terminal result of a turn, surfaced on `turn.ended`. */
export interface TransformResult {
	usage: TokenUsage;
	/** Normalized terminal status, when the harness reported one. The engine
	 * overrides with `cancelled`/`error` based on what it observed. */
	stopReason?: StopReason;
	/** Raw provider finish string, passed through untouched. */
	finishReason?: string;
	cost?: number;
	error?: string;
	cancelled?: boolean;
}

/**
 * Per-turn stateful translator from one harness's raw events to AdapterEvents.
 * Created fresh per turn (it holds streaming part state).
 */
export interface EventTransformer<TEvent = unknown> {
	process(event: TEvent): AdapterEvent[];
	finish(): TransformResult;
}

export type AdapterFactory = (ctx: { sessionId: string }) => EventTransformer;
