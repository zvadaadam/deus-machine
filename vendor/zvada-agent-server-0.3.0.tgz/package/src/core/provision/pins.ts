import type { AgentHarness } from "../../protocol/index.ts";

/**
 * The managed CLIs. Each native harness maps onto exactly one of these; the
 * `acp` harness maps onto none (its agent binaries are arbitrary third-party
 * commands the operator supplies, not something we pin or download).
 */
export const CLI_TOOLS = ["claude", "codex"] as const;
export type CliTool = (typeof CLI_TOOLS)[number];

/**
 * The CLI versions this engine release is tested against — the versions
 * `agent-server install` (and on-demand provisioning) downloads.
 *
 * - `claude` is the version of the `@anthropic-ai/claude-agent-sdk-<platform>`
 *   packages, which carry the native CLI matched to the SDK JS we bundle. It
 *   MUST track the lockfile's claude-agent-sdk version (a test enforces this);
 *   bump both together. When the SDK is resolvable on disk, its real installed
 *   version wins over this pin so the pair can never skew.
 * - `codex` is the `@openai/codex` platform-package version the
 *   codex-app-server adapter's protocol snapshot was verified against (see
 *   CLAUDE.md "Verifying harness protocols"). Bump after re-verifying. Note
 *   the codex-sdk harness normally never reaches this pin: host resolution
 *   prefers the build vendored by the installed `@openai/codex-sdk` (its own
 *   pair). The pin governs downloads (compiled binaries / bare sandboxes /
 *   `pinned` mode); embedders wanting an exact codex-sdk pairing there can
 *   set `provision.pins.codex` to their SDK's vendored version.
 */
export const DEFAULT_PINS: Record<CliTool, string> = {
	claude: "0.3.168",
	// 0.146.1 re-verified 2026-08-06: generate-ts snapshot carries our full
	// surface unchanged (thread/turn/item methods, tokenUsage w/ window,
	// approvals) and a live turn ran clean incl. the gpt-5.6-sol default.
	codex: "0.146.1",
};

/**
 * Which managed CLI a harness runs on — `undefined` for unmanaged harnesses
 * (`acp`). Exhaustive by construction: adding a harness fails to compile here
 * until someone decides whether it is provisioner-managed.
 */
const TOOL_FOR_HARNESS: Record<AgentHarness, CliTool | undefined> = {
	"claude-code": "claude",
	"codex-sdk": "codex",
	"codex-app-server": "codex",
	acp: undefined,
};

export function toolForHarness(harness: AgentHarness): CliTool | undefined {
	return TOOL_FOR_HARNESS[harness];
}
