#!/usr/bin/env bun
// agent-server — run the engine as a standalone wire server.
//
//   agent-server                      # NDJSON JSON-RPC over stdio (default)
//   agent-server --listen 4747       # accept WebSocket clients on a port
//   agent-server --dial ws://host/p  # dial out to a consumer and reconnect
//   agent-server --harness a,b       # restrict registered harnesses
//   agent-server --acp-agent "npx -y pi-acp"  # enable the acp harness
//   agent-server --acp --harness claude-code  # BE an ACP agent on stdio (for Zed etc.)
//   agent-server --buffer 8192       # replay buffer size per session
//   agent-server install             # prefetch the pinned agent CLIs
//
// All logs go to stderr; stdout is reserved for the wire in stdio mode.
import {
	KNOWN_ACP_AGENTS,
	type ProvisionMode,
	createAgentRuntime,
	resolveAcpLaunch,
} from "../core/index.ts";
import { isAgentHarness } from "../protocol/index.ts";
import { AgentServer } from "./agent-server.ts";
import { runInstall } from "./install.ts";
import { dial, listen, stdioTransport } from "./transports.ts";

const VERSION = "0.1.0";

interface Args {
	command: "serve" | "install";
	mode: "stdio" | "listen" | "dial" | "acp";
	listen?: { hostname?: string; port: number };
	dialUrl?: string;
	harnesses?: string[];
	acpAgent?: string;
	bufferSize?: number;
	provisionMode?: ProvisionMode;
}

function usage(exitCode: number): never {
	console.error(
		[
			"usage: agent-server [install] [--listen [host:]port | --dial <ws-url>] [options]",
			"",
			"  (default)              serve NDJSON JSON-RPC on stdio",
			"  --acp                  speak ACP v1 on stdio instead (be the agent)",
			"  install                download the pinned agent CLIs into the managed cache",
			"                         (always downloads — run at image build time to erase",
			"                         sandbox cold starts; --provision applies to serving only)",
			"  --listen [host:]port   accept WebSocket clients",
			"  --dial <ws-url>        dial out to a consumer (auto-reconnect)",
			"  --harness <a,b>        restrict harnesses (default: all installed)",
			"  --provision <mode>     CLI provisioning: auto | pinned | system (default auto)",
			"  --buffer <n>           replay buffer size per session (default 4096)",
			"  --version, --help",
			"",
			"env: CLAUDE_CLI_PATH / CODEX_CLI_PATH (explicit binaries),",
			"     AGENT_SERVER_PROVISION, AGENT_SERVER_CACHE_DIR, AGENT_SERVER_NPM_REGISTRY",
		].join("\n"),
	);
	process.exit(exitCode);
}

function parseArgs(argv: string[]): Args {
	const args: Args = { command: "serve", mode: "stdio" };
	for (let i = 0; i < argv.length; i++) {
		const arg = argv[i] as string;
		const next = () => {
			const v = argv[++i];
			if (v === undefined) usage(1);
			return v;
		};
		if (arg === "install" && i === 0) args.command = "install";
		else if (arg === "--stdio") args.mode = "stdio";
		else if (arg === "--acp") args.mode = "acp";
		else if (arg === "--listen") {
			args.mode = "listen";
			const [a, b] = next().split(":");
			args.listen = b !== undefined ? { hostname: a, port: Number(b) } : { port: Number(a) };
			if (!Number.isInteger(args.listen.port)) usage(1);
		} else if (arg === "--dial") {
			args.mode = "dial";
			args.dialUrl = next();
		} else if (arg === "--harness") args.harnesses = next().split(",").filter(Boolean);
		else if (arg === "--provision") {
			const mode = next();
			if (mode !== "auto" && mode !== "pinned" && mode !== "system") usage(1);
			args.provisionMode = mode;
		} else if (arg === "--buffer") {
			args.bufferSize = Number(next());
			if (!Number.isInteger(args.bufferSize) || args.bufferSize <= 0) usage(1);
		} else if (arg === "--version") {
			console.log(VERSION);
			process.exit(0);
		} else if (arg === "--help") usage(0);
		else usage(1);
	}
	return args;
}

const args = parseArgs(process.argv.slice(2));

const harnesses = args.harnesses?.map((h) => {
	if (isAgentHarness(h)) return h;
	if (KNOWN_ACP_AGENTS[h]) {
		// Friendly ACP agent names ("pi", "gemini") ride the acp harness.
		args.acpAgent ??= h;
		return "acp" as const;
	}
	console.error(`unknown harness: ${h}`);
	process.exit(1);
});
const provision = args.provisionMode ? { mode: args.provisionMode } : {};
const acpLaunch = resolveAcpLaunch(args.acpAgent ?? process.env.AGENT_SERVER_ACP_AGENT);
if (harnesses?.includes("acp") && !acpLaunch) {
	console.error('the acp harness needs an agent: --harness pi|gemini or --acp-agent "<spec>"');
	process.exit(1);
}

if (args.command === "install") {
	try {
		// install always downloads to the managed cache; --provision (a serving
		// concern) is deliberately not forwarded.
		const results = await runInstall({ harnesses });
		for (const { tool, cli } of results) {
			console.error(`${tool} ${cli.version ?? ""} ready: ${cli.path} (${cli.source})`);
		}
		process.exit(0);
	} catch (error) {
		console.error(`install failed: ${error instanceof Error ? error.message : String(error)}`);
		process.exit(1);
	}
}

const runtime = createAgentRuntime({
	...(harnesses ? { harnesses } : {}),
	...(acpLaunch ? { acp: { resolveLaunch: () => acpLaunch } } : {}),
	provision,
});

let shutdown: () => void;
if (args.mode === "acp") {
	// Speak ACP v1 on stdio: this process IS the agent (Zed-spawnable).
	const { serveAcpStdio } = await import("./acp/binding.ts");
	const frontedHarness = harnesses?.[0] ?? "claude-code";
	const connection = await serveAcpStdio({ runtime, harness: frontedHarness, version: VERSION });
	console.error(`agent-server ${VERSION} speaking ACP v1 on stdio (harness: ${frontedHarness})`);
	shutdown = () => void runtime.shutdown().then(() => process.exit(0));
	// Client hung up — shut down cleanly (mirrors the stdio wire transport).
	void connection.closed.then(() => shutdown());
} else {
	const server = new AgentServer(runtime, {
		bufferSize: args.bufferSize,
		info: { name: "agent-server", version: VERSION },
		onShutdown: () => process.exit(0),
	});
	shutdown = () => void server.shutdown();

	if (args.mode === "listen") {
		const bound = listen(server, args.listen);
		console.error(`agent-server ${VERSION} listening on ${bound.url}`);
	} else if (args.mode === "dial") {
		dial(server, args.dialUrl as string, {
			onStateChange: (state) => console.error(`agent-server dial ${args.dialUrl}: ${state}`),
		});
	} else {
		const transport = stdioTransport();
		server.attach(transport);
		// Parent hung up — shut down cleanly.
		transport.onClose(() => shutdown());
	}
}

for (const signal of ["SIGINT", "SIGTERM"] as const) {
	process.on(signal, () => shutdown());
}
