/** The slice of a session a SessionStore manages: a closable client + idle timer. */
export interface StoredSession {
	client: { closed: boolean; close(): void };
	idleTimer?: ReturnType<typeof setTimeout>;
}

/**
 * Per-logical-session bookkeeping shared by subprocess-backed harnesses
 * (codex-app-server, acp): the sessionId → session map, idle-eviction timers,
 * self-healing when a client dies underneath us, and whole-store teardown.
 * Harnesses own what a session *is*; this owns when one goes away.
 */
export class SessionStore<S extends StoredSession> {
	private readonly sessions = new Map<string, S>();

	get(sessionId: string): S | undefined {
		return this.sessions.get(sessionId);
	}

	set(sessionId: string, session: S): void {
		this.sessions.set(sessionId, session);
	}

	values(): IterableIterator<S> {
		return this.sessions.values();
	}

	/** Self-heal: drop the mapping when this exact client closed underneath us. */
	dropIfCurrent(sessionId: string, client: S["client"]): void {
		const current = this.sessions.get(sessionId);
		if (current && current.client === client) {
			this.clearIdle(current);
			this.sessions.delete(sessionId);
		}
	}

	/** Tear down one session: cancel its idle timer, unmap it, close its client. */
	close(sessionId: string): void {
		const session = this.sessions.get(sessionId);
		if (!session) return;
		this.clearIdle(session);
		this.sessions.delete(sessionId);
		session.client.close();
	}

	/** Tear down every session (process shutdown). */
	closeAll(): void {
		for (const session of this.sessions.values()) {
			this.clearIdle(session);
			session.client.close();
		}
		this.sessions.clear();
	}

	/** Shut the session down after `idleMs` unless another turn claims it first. */
	armIdle(sessionId: string, session: S, idleMs: number): void {
		this.clearIdle(session);
		session.idleTimer = setTimeout(() => {
			if (this.sessions.get(sessionId) !== session) return;
			this.sessions.delete(sessionId);
			session.client.close();
		}, idleMs);
		session.idleTimer.unref?.();
	}

	clearIdle(session: S): void {
		if (session.idleTimer) {
			clearTimeout(session.idleTimer);
			session.idleTimer = undefined;
		}
	}
}
