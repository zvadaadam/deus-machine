import { spawn as nodeSpawn } from "node:child_process";
import { createInterface } from "node:readline";
import { type WireTransport, channelTransport, pushNdjsonLines } from "../protocol/index.ts";

export interface SpawnServerOptions {
	command: string;
	args?: string[];
	cwd?: string;
	env?: Record<string, string>;
}

/**
 * Spawn an agent-server subprocess and talk NDJSON over its stdio
 * (deus-machine's model). The child's stderr passes through to ours.
 */
export function spawnTransport(opts: SpawnServerOptions): WireTransport {
	const child = nodeSpawn(opts.command, opts.args ?? [], {
		cwd: opts.cwd,
		env: opts.env ? { ...process.env, ...opts.env } : process.env,
		stdio: ["pipe", "pipe", "inherit"],
	});
	if (!child.stdin || !child.stdout) throw new Error("failed to open child stdio pipes");
	const stdin = child.stdin;
	const { transport, push, end } = channelTransport({
		send: (line) => void stdin.write(`${line}\n`),
		close: () => void child.kill(),
	});
	const rl = createInterface({ input: child.stdout, terminal: false });
	rl.on("line", push);
	child.on("exit", (code) => end(`server exited (code ${code ?? "signal"})`));
	child.on("error", (err) => end(err.message));
	// A dead server pipe (EPIPE) must route through the close path — an
	// unhandled stream 'error' would crash the consumer process instead.
	stdin.on("error", (err: Error) => end(`server stdin error: ${err.message}`));
	child.stdout.on("error", (err: Error) => end(`server stdout error: ${err.message}`));
	return transport;
}

/** Dial a listening agent-server; resolves once the socket is open. */
export function connectTransport(url: string): Promise<WireTransport> {
	return new Promise((resolve, reject) => {
		const ws = new WebSocket(url);
		const { transport, push, end } = channelTransport({
			send: (line) => void ws.send(line),
			close: () => ws.close(),
		});
		let opened = false;
		ws.addEventListener("open", () => {
			opened = true;
			resolve(transport);
		});
		ws.addEventListener("message", (ev) => pushNdjsonLines(push, ev.data));
		ws.addEventListener("close", () => {
			if (!opened) reject(new Error(`websocket connect failed: ${url}`));
			end("socket closed");
		});
		// A close event always follows; nothing to do here.
		ws.addEventListener("error", () => {});
	});
}

/**
 * The subset of a WebSocket this package needs — matches browser/Bun/Node and
 * Cloudflare Workers sockets alike.
 */
export interface WebSocketLike {
	send(data: string): void;
	close(): void;
	addEventListener(type: "message" | "close", listener: (event: { data?: unknown }) => void): void;
}

/**
 * Wrap an already-accepted socket (echo's model: the sandboxed server dialed
 * out to us and this is the accepted end).
 */
export function socketTransport(socket: WebSocketLike): WireTransport {
	const { transport, push, end } = channelTransport({
		send: (line) => socket.send(line),
		close: () => socket.close(),
	});
	socket.addEventListener("message", (ev) => pushNdjsonLines(push, ev.data));
	socket.addEventListener("close", () => end("socket closed"));
	return transport;
}
