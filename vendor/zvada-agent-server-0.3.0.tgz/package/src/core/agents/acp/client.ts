import { type ChildProcess, spawn } from "node:child_process";
import { Readable, Writable } from "node:stream";
import type {
	AgentNotificationMethod,
	AgentNotificationParamsByMethod,
	AgentRequestMethod,
	AgentRequestParamsByMethod,
	AgentRequestResponsesByMethod,
	ClientConnection,
	RequestPermissionRequest,
	RequestPermissionResponse,
	SessionNotification,
} from "@agentclientprotocol/sdk";

/**
 * How to start one ACP agent subprocess. Operator-level only — the wire never
 * carries commands (same rule as `resolveCliPath`): an attacker who controls
 * the launch command controls code execution on the host.
 */
export interface AcpLaunch {
	command: string;
	args?: string[];
	/** Extra env layered onto the subprocess (over process.env). */
	env?: Record<string, string>;
}

/**
 * Parse an operator-supplied launch spec (`"npx -y pi-acp"`) into an AcpLaunch.
 * Naive whitespace split — no shell quoting; env vars come from the caller.
 * The canonical parser for `--acp-agent` flags / `$AGENT_SERVER_ACP_AGENT`.
 */
export function parseAcpLaunch(spec: string | undefined): AcpLaunch | undefined {
	const [command, ...args] = spec?.trim().split(/\s+/).filter(Boolean) ?? [];
	if (!command) return undefined;
	return { command, ...(args.length && { args }) };
}

export type SessionUpdateHandler = (notification: SessionNotification) => void;

/** Answers agent→client `session/request_permission`. Absent handler → cancelled. */
export type AcpPermissionHandler = (
	request: RequestPermissionRequest,
) => Promise<RequestPermissionResponse>;

export interface AcpClientOptions {
	launch: AcpLaunch;
	cwd: string;
	/** Per-session env on top of the launch env (RunConfig.env). */
	env?: Record<string, string>;
	clientName?: string;
}

/**
 * One ACP agent subprocess + its SDK connection. The engine talks to any
 * ACP v1 agent through this: JSON-RPC framing, routing, and schema types come
 * from `@agentclientprotocol/sdk` (dynamic-imported, optional peer dep);
 * this wrapper owns the child process, close fan-out, and the mutable
 * per-turn handlers (the SDK app's handlers are fixed at connect time, so
 * they dispatch through this class's current fields — mirroring the
 * codex-app-server client's `setRequestHandler` pattern).
 */
export class AcpClient {
	private proc?: ChildProcess;
	private connection?: ClientConnection;
	private readonly updateHandlers = new Set<SessionUpdateHandler>();
	private readonly closeHandlers = new Set<(error?: Error) => void>();
	private permissionHandler?: AcpPermissionHandler;
	private exited = false;

	private constructor(private readonly opts: AcpClientOptions) {}

	/** Spawn the agent and connect. Fails if `@agentclientprotocol/sdk` is absent. */
	static async create(opts: AcpClientOptions): Promise<AcpClient> {
		const client = new AcpClient(opts);
		await client.start();
		return client;
	}

	onSessionUpdate(handler: SessionUpdateHandler): () => void {
		this.updateHandlers.add(handler);
		return () => this.updateHandlers.delete(handler);
	}

	/** Install the answerer for permission round-trips (set once per session;
	 * per-turn context lives inside the handler's own closure). */
	setPermissionHandler(handler: AcpPermissionHandler | undefined): void {
		this.permissionHandler = handler;
	}

	onClose(handler: (error?: Error) => void): () => void {
		this.closeHandlers.add(handler);
		return () => this.closeHandlers.delete(handler);
	}

	get closed(): boolean {
		return this.exited;
	}

	/**
	 * Send a request to the agent (`initialize`, `session/new`, `session/prompt`, …).
	 * `timeoutMs` bounds the wait for handshake-style requests — a spawned-but-wedged
	 * agent must not stall the turn forever. The SDK's `cancellationSignal` is
	 * cooperative (the peer still decides when to respond), so the local race is
	 * what actually enforces the deadline. Turn-long requests (`session/prompt`)
	 * pass no timeout.
	 */
	async request<M extends AgentRequestMethod>(
		method: M,
		params: AgentRequestParamsByMethod[M],
		timeoutMs?: number,
	): Promise<AgentRequestResponsesByMethod[M]> {
		if (!this.connection || this.exited) throw new Error("acp agent not running");
		const agent = this.connection.agent;
		if (!timeoutMs) return agent.request(method, params);
		const abort = new AbortController();
		let timer: ReturnType<typeof setTimeout> | undefined;
		const deadline = new Promise<never>((_, reject) => {
			timer = setTimeout(() => {
				abort.abort();
				reject(new Error(`acp agent '${method}' timed out after ${timeoutMs}ms`));
			}, timeoutMs);
			timer.unref?.();
		});
		try {
			return await Promise.race([
				agent.request(method, params, { cancellationSignal: abort.signal }),
				deadline,
			]);
		} finally {
			if (timer) clearTimeout(timer);
		}
	}

	/** Send a notification to the agent (`session/cancel`). */
	async notify<M extends AgentNotificationMethod>(
		method: M,
		params: AgentNotificationParamsByMethod[M],
	): Promise<void> {
		if (!this.connection || this.exited) return;
		await this.connection.agent.notify(method, params);
	}

	close(): void {
		const proc = this.proc;
		const wasOpen = !this.exited;
		this.exited = true;
		this.proc = undefined;
		this.connection?.close();
		this.connection = undefined;
		if (proc && !proc.killed) proc.kill("SIGTERM");
		if (wasOpen) this.notifyClosed();
	}

	private async start(): Promise<void> {
		const acp = await import("@agentclientprotocol/sdk");
		const { launch } = this.opts;
		const proc = spawn(launch.command, launch.args ?? [], {
			cwd: this.opts.cwd,
			env: { ...process.env, ...launch.env, ...this.opts.env },
			stdio: ["pipe", "pipe", "pipe"],
		});
		this.proc = proc;
		if (!proc.stdin || !proc.stdout) {
			proc.kill("SIGTERM");
			throw new Error("acp agent subprocess has no stdio");
		}
		// Drain stderr so the agent can't block on a full pipe; its logs are not ours.
		proc.stderr?.on("data", () => {});
		proc.on("error", (err) => this.onExit(err));
		proc.on("exit", (code, signal) =>
			this.onExit(new Error(`acp agent exited (code=${code} signal=${signal})`)),
		);

		const stream = acp.ndJsonStream(
			Writable.toWeb(proc.stdin),
			// Kept cast: embedders compile these sources under their own tsconfig,
			// and older lib.dom types Readable.toWeb as ReadableStream<any>.
			Readable.toWeb(proc.stdout) as unknown as ReadableStream<Uint8Array>,
		);
		this.connection = acp
			.client({ name: this.opts.clientName ?? "agent-server" })
			.onRequest("session/request_permission", async (ctx): Promise<RequestPermissionResponse> => {
				const handler = this.permissionHandler;
				if (!handler) return { outcome: { outcome: "cancelled" } };
				return handler(ctx.params);
			})
			.onNotification("session/update", (ctx) => {
				for (const handler of this.updateHandlers) handler(ctx.params);
			})
			.connect(stream);
		// A closed connection without a process exit (stream error) still ends the
		// client; a rejected `closed` must not become an unhandled rejection.
		this.connection.closed.then(
			() => this.onExit(new Error("acp connection closed")),
			(err: unknown) =>
				this.onExit(err instanceof Error ? err : new Error(`acp connection failed: ${err}`)),
		);
	}

	private onExit(error: Error): void {
		if (this.exited) return;
		this.exited = true;
		this.connection?.close(error);
		this.connection = undefined;
		this.notifyClosed(error);
	}

	private notifyClosed(error?: Error): void {
		for (const handler of this.closeHandlers) handler(error);
		this.closeHandlers.clear();
	}
}
