import { z } from "zod";

/**
 * A single, harness-agnostic reasoning dial. Each harness maps it to its own
 * native control: Claude -> adaptive `thinking` + `effort`; Codex ->
 * `ReasoningEffort`.
 */
export const THINKING_LEVELS = ["off", "low", "medium", "high", "xhigh"] as const;
export type ThinkingLevel = (typeof THINKING_LEVELS)[number];
export const ThinkingLevelSchema = z.enum(THINKING_LEVELS);
export const DEFAULT_THINKING_LEVEL: ThinkingLevel = "medium";

export function isThinkingLevel(v: string): v is ThinkingLevel {
	return (THINKING_LEVELS as readonly string[]).includes(v);
}

/** Codex reasoning-effort string for a level (matches the `ReasoningEffort` enum). */
export type CodexReasoningEffort = "minimal" | "low" | "medium" | "high" | "xhigh";
export function codexReasoningEffort(level: ThinkingLevel): CodexReasoningEffort {
	switch (level) {
		case "off":
			return "minimal";
		case "low":
			return "low";
		case "medium":
			return "medium";
		case "high":
			return "high";
		case "xhigh":
			return "xhigh";
	}
}
