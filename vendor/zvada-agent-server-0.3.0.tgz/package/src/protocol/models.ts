import type { AgentHarness } from "./harness.ts";
import type { ThinkingLevel } from "./thinking.ts";

/**
 * Advisory catalog of known-good models per harness. `model` on a RunConfig is
 * a free-form string (harnesses pass it through), so unlisted models still work;
 * this catalog drives UIs/pickers and supplies sensible per-harness defaults.
 */
export interface ModelInfo {
	readonly id: string;
	readonly harness: AgentHarness;
	readonly label: string;
	readonly thinking: readonly ThinkingLevel[];
}

const ALL: readonly ThinkingLevel[] = ["off", "low", "medium", "high", "xhigh"];

export const MODEL_CATALOG: readonly ModelInfo[] = [
	// Claude (the claude CLI also accepts the bare aliases "sonnet"/"opus"/"haiku").
	{ id: "sonnet", harness: "claude-code", label: "Claude Sonnet (latest)", thinking: ALL },
	{ id: "opus", harness: "claude-code", label: "Claude Opus (latest)", thinking: ALL },
	{ id: "haiku", harness: "claude-code", label: "Claude Haiku (latest)", thinking: ALL },
	// Codex (shared between codex-sdk and codex-app-server).
	{ id: "gpt-5.5", harness: "codex-sdk", label: "GPT-5.5", thinking: ALL },
	{ id: "gpt-5.5-codex", harness: "codex-sdk", label: "GPT-5.5 Codex", thinking: ALL },
	{ id: "gpt-5.5", harness: "codex-app-server", label: "GPT-5.5", thinking: ALL },
	{ id: "gpt-5.5-codex", harness: "codex-app-server", label: "GPT-5.5 Codex", thinking: ALL },
];

/**
 * Default model per harness. `undefined` means "let the harness/CLI use its own
 * configured default" (Codex reads `~/.codex/config.toml`).
 */
export const DEFAULT_MODELS: Record<AgentHarness, string | undefined> = {
	"claude-code": "sonnet",
	"codex-sdk": undefined,
	"codex-app-server": undefined,
	// ACP v1 has no portable model parameter (selection is agent-defined via
	// config options), so the target agent always uses its own default.
	acp: undefined,
};

export function modelsForHarness(harness: AgentHarness): readonly ModelInfo[] {
	return MODEL_CATALOG.filter((m) => m.harness === harness);
}
