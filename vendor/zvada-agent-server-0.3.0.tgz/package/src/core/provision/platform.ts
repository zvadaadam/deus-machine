import { constants, accessSync, existsSync } from "node:fs";
import { delimiter, join } from "node:path";

/** The facts about this machine that pick a CLI build. Injectable in tests. */
export interface PlatformInfo {
	/** `process.platform` value (darwin | linux | win32 | …). */
	platform: string;
	/** `process.arch` value (arm64 | x64 | …). */
	arch: string;
	/** linux only: glibc absent (Alpine et al.) — selects `-musl` builds. */
	musl: boolean;
}

/**
 * Musl detection mirrors the Claude SDK's own check: a Node process report
 * without `glibcVersionRuntime` means musl. Runtimes without process.report
 * (or partial implementations) fall back to the Alpine marker file.
 */
function isMusl(): boolean {
	if (process.platform !== "linux") return false;
	try {
		const report = process.report?.getReport?.() as
			| { header?: { glibcVersionRuntime?: string } }
			| undefined;
		if (report?.header) return !report.header.glibcVersionRuntime;
	} catch {
		// fall through to the filesystem heuristic
	}
	return existsSync("/etc/alpine-release");
}

export function detectPlatform(): PlatformInfo {
	return { platform: process.platform, arch: process.arch, musl: isMusl() };
}

/**
 * Suffix of `@anthropic-ai/claude-agent-sdk-<suffix>` — the platform package
 * carrying the native `claude` binary. Claude ships dedicated musl builds.
 */
export function claudePackageSuffix(p: PlatformInfo): string {
	return `${p.platform}-${p.arch}${p.musl ? "-musl" : ""}`;
}

/**
 * Suffix of `@openai/codex@<version>-<suffix>` — codex publishes platform
 * builds as version suffixes of the main package. Its linux builds are static
 * (musl) already, so there is no separate musl variant.
 */
export function codexPackageSuffix(p: PlatformInfo): string {
	return `${p.platform}-${p.arch}`;
}

/** Locate an executable on PATH (the `which` we can unit-test and run anywhere). */
export function findOnPath(
	name: string,
	env: Record<string, string | undefined> = process.env,
	platform: string = process.platform,
): string | undefined {
	const paths = (env.PATH ?? "").split(delimiter).filter(Boolean);
	const names = platform === "win32" ? [`${name}.exe`, `${name}.cmd`, name] : [name];
	for (const dir of paths) {
		for (const file of names) {
			const candidate = join(dir, file);
			try {
				accessSync(candidate, constants.X_OK);
				return candidate;
			} catch {
				// not here — keep walking
			}
		}
	}
	return undefined;
}
