import type { SDKMessage, SDKUserMessage } from "@anthropic-ai/claude-agent-sdk";
import type { McpSetServersResult } from "@anthropic-ai/claude-agent-sdk";
import type { AgentCapabilities, AgentInput, McpServerConfig } from "../../../protocol/index.ts";
import { type DiagnosticHandler, emitDiagnostic } from "../../diagnostics.ts";
import type { AgentExecuteOptions, CancelResult, RawAgentEvent } from "../base.ts";
import { BaseAgent } from "../base.ts";
import type {
	ClaudeHooksFactory,
	ClaudeSessionEndReason,
	ClaudeSessionExtras,
	ClaudeToolPolicy,
} from "./generator-session.ts";
import type { ClaudeSessionConfig } from "./options.ts";
import { ClaudeSessionManager } from "./session-manager.ts";

type ClaudeContent = SDKUserMessage["message"]["content"];

const CAPABILITIES: AgentCapabilities = {
	multiTurn: true,
	sessionResume: true,
	modelSwitch: "in-session",
	thinkingLevels: true,
	images: true,
	mcpServers: true,
	permissionRequests: true,
};

/** Convert our normalized input into Claude's message content. */
function toClaudeContent(input: AgentInput): ClaudeContent {
	if (typeof input === "string") return input;
	const blocks = input.map((part) => {
		if (part.type === "text") return { type: "text", text: part.text };
		const source = part.url
			? { type: "url", url: part.url }
			: { type: "base64", media_type: part.mimeType, data: part.data ?? "" };
		// `file` inputs (PDFs etc.) are document blocks, not images.
		return { type: part.type === "file" ? "document" : "image", source };
	});
	// Kept cast: the SDK's block sources require literal media_type unions
	// ("image/jpeg" | ... and "application/pdf") while our PartInput carries an
	// open string mimeType, so these blocks cannot satisfy the union as typed.
	return blocks as unknown as ClaudeContent;
}

/**
 * The SDK shape of a hard resume failure: the turn dies with
 * `error_during_execution` and a null stop reason before any output. (An
 * interrupt produces the same result message — callers must also check that no
 * interrupt was requested.)
 */
export function claudeResumeFailed(event: unknown): boolean {
	const msg = event as { type?: string; subtype?: string; stop_reason?: unknown };
	return (
		msg.type === "result" && msg.subtype === "error_during_execution" && msg.stop_reason === null
	);
}

function sessionConfigFrom(
	options: AgentExecuteOptions,
	cliPath: string | undefined,
): ClaudeSessionConfig {
	return {
		cwd: options.cwd,
		additionalDirectories: options.additionalDirectories,
		model: options.model,
		thinkingLevel: options.thinkingLevel,
		permissionMode: options.permissionMode,
		maxTurns: options.maxTurns,
		systemPromptAppend: options.systemPromptAppend,
		resumeSessionId: options.resumeSessionId,
		resumeSessionAt: options.resumeSessionAt,
		mcpServers: options.mcpServers,
		env: options.env,
		apiKey: options.apiKey,
		disableTools: options.disableTools === true,
		cliPath,
	};
}

export interface ClaudeCodeAgentOptions {
	/**
	 * Resolve the `claude` binary to spawn (typically the provisioner's,
	 * memoized). `undefined` defers to the SDK's own platform-package
	 * resolution. Operator-level only — never sourced from the wire.
	 */
	resolveCliPath?: () => Promise<string | undefined>;
	/**
	 * In-process MCP servers to attach to every session (the SDK's
	 * `createSdkMcpServer` output). Called once per session spawn. Operator
	 * embed-tier only — never wire-sourced; instances win name conflicts with
	 * wire-configured servers.
	 */
	sdkMcpServers?: ClaudeSessionExtras["sdkMcpServers"];
	/**
	 * Pre-broker tool policy (SDK PermissionResult or undefined = fall through
	 * to the interactive broker). Operator embed-tier only.
	 */
	toolPolicy?: ClaudeToolPolicy;
	/** SDK lifecycle hooks factory (decision-capable). Operator embed-tier only. */
	hooks?: ClaudeHooksFactory;
	/**
	 * Called exactly once when a live session's subprocess ends, with why:
	 * `idle` (idle-timeout eviction), `replaced` (config change forced a
	 * restart), `released` (explicit release/close), `shutdown`
	 * (terminateAll). The seam for host-managed per-session resources — BYOK
	 * proxy keys, recorders — instead of re-deriving termination from side
	 * effects. NOTE: `replaced` sessions usually respawn immediately with
	 * context preserved; drop only resources bound to the dead subprocess.
	 */
	onSessionEnd?: (sessionId: string, reason: ClaudeSessionEndReason) => void;
	/** Operational diagnostics (interrupt timeouts, resume fallbacks). */
	onDiagnostic?: DiagnosticHandler;
	/**
	 * Raw SDK option overrides merged over the engine's options at session
	 * spawn (embedder escape hatch for SDK surface the engine does not model:
	 * disallowedTools, forwardSubagentText, extraArgs, ...). Operator
	 * embed-tier only — never wire-sourced.
	 */
	sdkOptions?: ClaudeSessionExtras["sdkOptions"];
}

/**
 * Claude Code harness. Reuses a warm `query()` per logical session for fast
 * in-session multi-turn and model hot-swap; falls back to SDK `resume` when a
 * session must be reconstructed (e.g. after idle eviction or across processes).
 */
export class ClaudeCodeAgent extends BaseAgent {
	readonly harness = "claude-code" as const;
	readonly capabilities = CAPABILITIES;
	private readonly manager: ClaudeSessionManager;

	constructor(private readonly agentOptions: ClaudeCodeAgentOptions = {}) {
		super();
		this.manager = new ClaudeSessionManager(agentOptions.onSessionEnd);
	}

	private sessionExtras(): ClaudeSessionExtras {
		return {
			sdkMcpServers: this.agentOptions.sdkMcpServers,
			toolPolicy: this.agentOptions.toolPolicy,
			hooks: this.agentOptions.hooks,
			sdkOptions: this.agentOptions.sdkOptions,
		};
	}

	async *execute(
		input: AgentInput,
		options: AgentExecuteOptions,
	): AsyncIterableIterator<RawAgentEvent> {
		const controller = this.trackTurn(options.sessionId, options.signal);
		try {
			const cliPath = await this.agentOptions.resolveCliPath?.();
			const content = toClaudeContent(input);

			// Attempt 0 honors resumeSessionId. The SDK does not degrade a bad
			// resume id into a fresh session — it fails the whole turn (result
			// error_during_execution before any output) — so a classified resume
			// failure is swallowed and the turn reruns ONCE on a fresh session,
			// reported as resumed:false (the structured fallback signal, acp parity).
			for (let attempt = 0; attempt < 2; attempt++) {
				if (controller.signal.aborted) break;
				const resuming = attempt === 0 && Boolean(options.resumeSessionId);
				const session = await this.manager.getOrCreate(
					options.sessionId,
					{
						...sessionConfigFrom(options, cliPath),
						...(resuming ? {} : { resumeSessionId: undefined, resumeSessionAt: undefined }),
					},
					this.sessionExtras(),
				);

				let reported = false;
				const report = (id: string) => {
					if (reported) return;
					reported = true;
					options.onNativeSession?.(id, { resumed: resuming });
				};
				// Resume turns defer the report until output proves the resume held —
				// a doomed attempt's id is never reported. Other turns report as soon
				// as an id is known.
				if (!resuming && session.currentSessionId) report(session.currentSessionId);

				// `sendMessage` waits until the session is idle (any prior turn
				// drained), then marks it busy — so installing the per-turn permission
				// handler AFTER it resolves can't clobber a still-running turn's
				// handler. The SDK processes the turn on later async tasks, so the
				// handler is in place before canUseTool can fire.
				const tap = await session.sendMessage(content, options.turnId);
				session.permissionHandler = options.onPermissionRequest;
				// An abort that landed while we were spawning/sending has no listener
				// yet — interrupt directly, then arm the listener for later aborts.
				if (controller.signal.aborted) void session.interruptTurn();
				controller.signal.addEventListener("abort", () => void session.interruptTurn(), {
					once: true,
				});

				let sawOutput = false;
				let resumeFailed = false;
				for await (const event of tap.events) {
					const msg = event as { type?: string; session_id?: string };
					if (msg.type === "assistant" || msg.type === "stream_event") sawOutput = true;
					if (resuming && !sawOutput && !controller.signal.aborted && claudeResumeFailed(event)) {
						resumeFailed = true;
						continue;
					}
					if (msg.session_id && (!resuming || sawOutput)) report(msg.session_id);
					yield event as RawAgentEvent;
				}

				if (!resumeFailed) break;
				emitDiagnostic(this.agentOptions.onDiagnostic, {
					type: "resumeFallback",
					sessionId: options.sessionId,
					message: `resume of ${options.resumeSessionId} failed; re-running on a fresh session`,
					detail: { resumeSessionId: options.resumeSessionId },
				});
				await this.manager.terminate(options.sessionId);
			}

			// Ground truth for the adapter: an interrupted turn and a turn that
			// failed during execution (e.g. a bad resume id) end with the SAME
			// result shape (error_during_execution, null stop_reason). Only the
			// agent knows whether an interrupt was actually requested.
			if (controller.signal.aborted) yield { type: "turn_interrupted" };
		} finally {
			this.endTurn(options.sessionId, controller);
		}
	}

	/**
	 * Hot-swap the live session's wire MCP servers without a restart (context
	 * intact). Returns false when the session isn't live. In-process servers
	 * are preserved across swaps.
	 */
	async setMcpServers(
		sessionId: string,
		servers: Record<string, McpServerConfig>,
	): Promise<McpSetServersResult | undefined> {
		return this.manager.setMcpServers(sessionId, servers);
	}

	override async cancel(sessionId: string): Promise<CancelResult> {
		// Abort FIRST: the controller ends the engine's execute loop, so this
		// turn classifies as cancelled even when the generator drains to a
		// natural end before the SDK interrupt lands (the abort-order race that
		// could surface a clean user cancel as `error`/`end_turn`). The SDK
		// interrupt then stops the underlying turn; its round-trip is what
		// confirms the cancel.
		const session = this.manager.get(sessionId);
		const base = await super.cancel(sessionId);
		if (!session || !base.hadTurn) return base;
		const interrupted = await session.interruptTurn();
		if (!interrupted) {
			emitDiagnostic(this.agentOptions.onDiagnostic, {
				type: "interruptTimeout",
				sessionId,
				message: "cancel dispatched but the SDK interrupt was not acknowledged in time",
			});
		}
		return { confirmed: interrupted, hadTurn: true };
	}

	override async release(sessionId: string): Promise<void> {
		await super.release(sessionId);
		await this.manager.terminate(sessionId);
	}

	override async terminateAll(): Promise<void> {
		await super.terminateAll();
		await this.manager.terminateAll();
	}
}
