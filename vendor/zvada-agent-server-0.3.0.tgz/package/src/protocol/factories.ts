import { generateUUIDv7 } from "./ids.ts";
import type { AgentInput } from "./part-input.ts";
import type { Part, ReasoningPart, SubagentMetadata, TextPart, ToolPart } from "./parts.ts";
import type { ToolKind, ToolLocation, ToolResultContent } from "./tool-state.ts";

/** Context an adapter threads through while building parts for one message. */
export interface StreamContext {
	sessionId: string;
	messageId: string;
	parentToolCallId?: string;
}

/** Optional normalized metadata for a tool part (see ToolPart). */
export interface ToolMeta {
	kind?: ToolKind;
	title?: string;
	locations?: ToolLocation[];
	/** Present when this tool spawns a subagent (implies kind "task"). */
	subagent?: SubagentMetadata;
}

export function createTextPart(ctx: StreamContext, text: string, streaming = true): TextPart {
	return {
		id: generateUUIDv7(),
		sessionId: ctx.sessionId,
		messageId: ctx.messageId,
		...(ctx.parentToolCallId && { parentToolCallId: ctx.parentToolCallId }),
		type: "text",
		text,
		state: streaming ? "streaming" : "done",
	};
}

export function createReasoningPart(
	ctx: StreamContext,
	text: string,
	streaming = true,
): ReasoningPart {
	return {
		id: generateUUIDv7(),
		sessionId: ctx.sessionId,
		messageId: ctx.messageId,
		...(ctx.parentToolCallId && { parentToolCallId: ctx.parentToolCallId }),
		type: "reasoning",
		text,
		state: streaming ? "streaming" : "done",
	};
}

function toolBase(ctx: StreamContext, toolCallId: string, toolName: string, meta?: ToolMeta) {
	return {
		id: generateUUIDv7(),
		sessionId: ctx.sessionId,
		messageId: ctx.messageId,
		...(ctx.parentToolCallId && { parentToolCallId: ctx.parentToolCallId }),
		type: "tool" as const,
		toolCallId,
		toolName,
		...(meta?.subagent ? { kind: "task" as const } : meta?.kind ? { kind: meta.kind } : {}),
		...(meta?.title && { title: meta.title }),
		...(meta?.locations?.length && { locations: meta.locations }),
		...(meta?.subagent && { subagent: meta.subagent }),
	};
}

export function createToolPart(
	ctx: StreamContext,
	toolCallId: string,
	toolName: string,
	input: Record<string, unknown>,
	meta?: ToolMeta,
): ToolPart {
	return {
		...toolBase(ctx, toolCallId, toolName, meta),
		state: { status: "in_progress", input, time: { start: Date.now() } },
	};
}

/** A tool call whose input is still streaming in (partial JSON not yet parseable). */
export function createPendingToolPart(
	ctx: StreamContext,
	toolCallId: string,
	toolName: string,
	meta?: ToolMeta,
): ToolPart {
	return {
		...toolBase(ctx, toolCallId, toolName, meta),
		state: { status: "pending", partialInput: "" },
	};
}

/** Mutates a pending tool part into `in_progress` once its input has fully parsed. */
export function startToolPart(part: ToolPart, input: Record<string, unknown>): void {
	if (part.state.status === "pending") {
		part.state = { status: "in_progress", input, time: { start: Date.now() } };
	}
}

/** Appends a streamed JSON fragment to a still-pending tool part. */
export function appendToolInput(part: ToolPart, partialJson: string): void {
	if (part.state.status === "pending") {
		part.state.partialInput += partialJson;
	}
}

/** Attach/refresh normalized metadata on an existing tool part. */
export function setToolMeta(part: ToolPart, meta: ToolMeta): void {
	if (meta.subagent) {
		part.subagent = meta.subagent;
		part.kind = "task";
	} else if (meta.kind) {
		part.kind = meta.kind;
	}
	if (meta.title) part.title = meta.title;
	if (meta.locations?.length) part.locations = meta.locations;
}

/** Mutates a tool part into its terminal `completed`/`failed` state. */
export function completeToolPart(
	part: ToolPart,
	result: {
		output: string;
		isError?: boolean;
		title?: string;
		/** Display-grade structured output (diffs, images, terminals). */
		content?: ToolResultContent[];
		/** Machine channel: harness-native extras (e.g. exitCode). */
		metadata?: Record<string, unknown>;
	},
): void {
	const start = part.state.status === "in_progress" ? part.state.time.start : Date.now();
	const input = "input" in part.state ? part.state.input : {};
	part.state = result.isError
		? { status: "failed", input, error: result.output, time: { start, end: Date.now() } }
		: {
				status: "completed",
				input,
				output: result.output,
				...(result.title !== undefined && { title: result.title }),
				...(result.content?.length && { content: result.content }),
				...(result.metadata && { metadata: result.metadata }),
				time: { start, end: Date.now() },
			};
}

/**
 * The user echo's message id, derived from the turn id.
 *
 * A DELIBERATE, documented exception to Law 8 (engine-minted UUIDv7): the echo
 * is not new information, it is the caller's own input played back, and one
 * turn has exactly one echo message. Deriving the id means a consumer can
 * predict the echo byte-for-byte from the `turnId` it minted — so an
 * optimistically-rendered prompt bubble IS the echo (same id, same parts)
 * instead of a look-alike that has to be reconciled and swapped. The
 * reconcile-by-turnId dance every product wrote is what this replaces.
 *
 * Ids stay opaque to peers: nothing may parse structure out of them. This is a
 * PRODUCER rule (how the engine mints), matched by a consumer helper — not a
 * licence to infer turn ids from message ids elsewhere.
 *
 * Two consequences of NOT being UUIDv7, for consumers that leaned on Law 8's
 * side effects: echo ids do not TIME-SORT against UUIDv7 ids (`echo-` sorts
 * after every hex digit — never order by id), and they do not fit uuid-typed
 * columns or id-derived timestamps (`createdAtFromUUID7(echoId)` is 0 — derive
 * the echo's time from its TURN id, which is UUIDv7 and is embedded verbatim).
 */
export function echoMessageId(turnId: string): string {
	return `echo-${turnId}`;
}

/** The id of the echo part at `index` — same derivation, same predictability. */
export function echoPartId(turnId: string, index: number): string {
	return `echo-${turnId}-${index}`;
}

/**
 * Build the parts for the user echo (spec §7.2) from a turn's input. Part ids
 * are derived from the turn (see `echoPartId`), so the whole echo message is
 * predictable from `{turnId, input}` alone. The EventProcessor stamps
 * `sessionId`/`messageId` at emit time. Text `elements` spans ride `_meta`
 * (the part vocabulary stays output-shaped; the spans are UI-authored
 * annotations).
 */
export function createUserEchoParts(input: AgentInput, turnId: string): Part[] {
	const items = typeof input === "string" ? [{ type: "text" as const, text: input }] : input;
	const parts: Part[] = [];
	for (let index = 0; index < items.length; index++) {
		const item = items[index] as (typeof items)[number];
		const base = { id: echoPartId(turnId, index), sessionId: "", messageId: "" };
		if (item.type === "text") {
			parts.push({
				...base,
				type: "text",
				text: item.text,
				state: "done",
				...("elements" in item && item.elements?.length
					? { _meta: { elements: item.elements } }
					: {}),
			});
		} else if (item.type === "image") {
			parts.push({
				...base,
				type: "image",
				...(item.data !== undefined && { data: item.data }),
				...(item.url !== undefined && { url: item.url }),
				mimeType: item.mimeType,
			});
		} else {
			parts.push({
				...base,
				type: "file",
				...(item.data !== undefined && { data: item.data }),
				...(item.url !== undefined && { url: item.url }),
				mimeType: item.mimeType,
				...(item.filename !== undefined && { filename: item.filename }),
			});
		}
	}
	return parts;
}
