import { spawn } from "node:child_process";
import { CliProvisionError } from "../utils/errors.ts";

/**
 * Extract a .tgz into a directory using the system `tar` (BSD, GNU, and
 * Windows 10+ libarchive all accept these flags). npm tarballs are small
 * enough in entry count that shelling out beats maintaining a tar parser.
 */
export async function extractTarGz(tgzPath: string, destDir: string): Promise<void> {
	await new Promise<void>((resolve, reject) => {
		const proc = spawn("tar", ["-xzf", tgzPath, "-C", destDir], {
			stdio: ["ignore", "ignore", "pipe"],
		});
		let stderr = "";
		proc.stderr?.on("data", (chunk: Buffer) => {
			stderr += chunk.toString();
		});
		proc.on("error", (error) =>
			reject(
				new CliProvisionError(
					`Failed to run \`tar\` (${error.message}) — provisioning needs tar on PATH`,
					{ cause: error },
				),
			),
		);
		proc.on("exit", (code) => {
			if (code === 0) resolve();
			else reject(new CliProvisionError(`tar -xzf ${tgzPath} exited ${code}: ${stderr.trim()}`));
		});
	});
}
