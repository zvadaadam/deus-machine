import type {
	InitializeResponse,
	PromptRequest,
	RequestPermissionRequest,
	RequestPermissionResponse,
} from "@agentclientprotocol/sdk";
import type { AgentCapabilities, AgentInput, PermissionMode } from "../../../protocol/index.ts";
import { AsyncQueue } from "../../../protocol/index.ts";
import type { AgentExecuteOptions, PermissionRequestHandler, RawAgentEvent } from "../base.ts";
import { BaseAgent } from "../base.ts";
import { configFingerprint } from "../config-fingerprint.ts";
import { SessionStore } from "../session-store.ts";
import { AcpClient, type AcpClientOptions, type AcpLaunch } from "./client.ts";
import {
	CANCELLED_OUTCOME,
	autoDecide,
	chooseOutcome,
	permissionToolCall,
	toAcpMcpServers,
	toPromptBlocks,
} from "./mappings.ts";

const CAPABILITIES: AgentCapabilities = {
	multiTurn: true,
	// The engine always *accepts* resumeSessionId; whether context actually
	// survives depends on the target agent's `sessionCapabilities.resume`
	// (falls back to a fresh session when unsupported).
	sessionResume: true,
	// v1 exposes model selection only through agent-defined config options;
	// there is no portable model parameter to pass through yet.
	modelSwitch: "unsupported",
	thinkingLevels: false,
	images: true,
	mcpServers: true,
	permissionRequests: true,
};

/** ACP protocol major version this harness speaks. */
const PROTOCOL_VERSION = 1;

/** Idle time before an unused agent subprocess is shut down. */
const IDLE_TIMEOUT_MS = 5 * 60_000;

/** How long a cancelled prompt may take to resolve before the turn is failed. */
const CANCEL_GRACE_MS = 10_000;

/** Deadline for `initialize` on a freshly spawned agent (mirrors codex startup). */
const INITIALIZE_TIMEOUT_MS = 15_000;

/** Deadline for session lifecycle requests (`session/new`, `session/resume`). */
const SESSION_REQUEST_TIMEOUT_MS = 30_000;

export interface AcpAgentOptions {
	/**
	 * Resolve the ACP agent subprocess to launch. Operator-level only — never
	 * sourced from the wire (the command is arbitrary code execution).
	 */
	resolveLaunch: () => Promise<AcpLaunch | undefined> | AcpLaunch | undefined;
	/** `clientInfo.name` advertised to agents. */
	clientName?: string;
	idleTimeoutMs?: number;
	/** Grace period for a `session/cancel` to resolve the in-flight prompt. */
	cancelGraceMs?: number;
	/** Injectable client factory for deterministic tests. */
	createClient?: (options: AcpClientOptions) => Promise<AcpClient>;
}

/** Permission context of the turn currently running on a session — set and
 * cleared as ONE value so stale partial state (an authorization bypass) is
 * unrepresentable. `undefined` between turns → the auto policy rejects. */
interface TurnPermissions {
	broker?: PermissionRequestHandler;
	mode?: PermissionMode;
	signal?: AbortSignal;
}

interface AcpSession {
	client: AcpClient;
	acpSessionId: string;
	cwd: string;
	envFingerprint: string;
	mcpFingerprint: string;
	launchFingerprint: string;
	/** From `initialize`: whether the agent accepts image content blocks. */
	imagesSupported: boolean;
	turn?: TurnPermissions;
	idleTimer?: ReturnType<typeof setTimeout>;
}

export function acpSessionCompatible(
	existing: AcpSession | undefined,
	options: AgentExecuteOptions,
	launchFingerprint: string,
): boolean {
	return Boolean(
		existing &&
			!existing.client.closed &&
			existing.cwd === options.cwd &&
			existing.envFingerprint === configFingerprint(options.env) &&
			existing.mcpFingerprint === configFingerprint(options.mcpServers) &&
			existing.launchFingerprint === launchFingerprint &&
			(!options.resumeSessionId || options.resumeSessionId === existing.acpSessionId),
	);
}

/** Answer an agent permission request against the session's current turn. */
export async function answerPermission(
	session: AcpSession,
	request: RequestPermissionRequest,
): Promise<RequestPermissionResponse> {
	if (request.sessionId !== session.acpSessionId) return CANCELLED_OUTCOME;
	const turn = session.turn;
	const asks = (turn?.mode ?? "default") === "default";
	if (!turn?.broker || !asks) return autoDecide(request, turn?.mode);
	const decision = await turn.broker(permissionToolCall(request), { signal: turn.signal });
	if (decision.decision === "cancel") return CANCELLED_OUTCOME;
	// `decision.updatedInput` is unrepresentable here: ACP v1's outcome carries
	// an optionId and nothing else, so an edited input cannot be honoured — and
	// silently running the ORIGINAL is exactly what the field exists to prevent.
	// The claude-code harness (canUseTool) is the one that can execute the edit.
	return chooseOutcome(request.options, decision.decision === "allow");
}

/**
 * ACP harness: drives any Agent Client Protocol v1 agent as a long-lived
 * subprocess (one per logical session, reused across turns). The launch
 * command comes from the operator's `resolveLaunch`; `initialize` negotiates
 * the protocol version and gates optional features (resume, images) on the
 * agent's advertised capabilities. The turn's stopReason arrives as the
 * `session/prompt` *response*, so `execute` re-injects it into the raw stream
 * as a synthetic `session/prompt_result` event for the adapter.
 */
export class AcpAgent extends BaseAgent {
	readonly harness = "acp" as const;
	readonly capabilities = CAPABILITIES;
	private readonly sessions = new SessionStore<AcpSession>();

	constructor(private readonly agentOptions: AcpAgentOptions) {
		super();
	}

	private async resolveSession(options: AgentExecuteOptions): Promise<AcpSession> {
		const launch = await this.agentOptions.resolveLaunch();
		if (!launch) {
			throw new Error(
				"acp harness is not configured: resolveLaunch returned no agent launch command",
			);
		}
		const launchFingerprint = configFingerprint({
			command: launch.command,
			args: launch.args?.join(" ") ?? "",
			...launch.env,
		});

		const existing = this.sessions.get(options.sessionId);
		let resumeTarget = options.resumeSessionId;
		if (existing && !existing.client.closed) {
			if (acpSessionCompatible(existing, options, launchFingerprint)) {
				this.sessions.clearIdle(existing);
				return existing;
			}
			// Preserve context within the same cwd/env boundary when the agent can
			// resume (mirrors the claude-code/codex restart policy).
			if (
				resumeTarget === undefined &&
				existing.cwd === options.cwd &&
				existing.envFingerprint === configFingerprint(options.env)
			) {
				resumeTarget = existing.acpSessionId;
			}
			this.sessions.close(options.sessionId);
		}

		const clientOptions: AcpClientOptions = {
			launch,
			cwd: options.cwd,
			env: options.env,
			clientName: this.agentOptions.clientName,
		};
		const client = this.agentOptions.createClient
			? await this.agentOptions.createClient(clientOptions)
			: await AcpClient.create(clientOptions);
		client.onClose(() => this.sessions.dropIfCurrent(options.sessionId, client));

		let init: InitializeResponse;
		let acpSessionId: string | undefined;
		try {
			init = await client.request(
				"initialize",
				{ protocolVersion: PROTOCOL_VERSION, clientCapabilities: {} },
				INITIALIZE_TIMEOUT_MS,
			);
			const mcpServers = toAcpMcpServers(options.mcpServers);
			if (resumeTarget && init.agentCapabilities?.sessionCapabilities?.resume) {
				try {
					await client.request(
						"session/resume",
						{ sessionId: resumeTarget, cwd: options.cwd, mcpServers },
						SESSION_REQUEST_TIMEOUT_MS,
					);
					acpSessionId = resumeTarget;
				} catch {
					// Unknown/expired session id — fall through to a fresh one.
				}
			}
			if (!acpSessionId) {
				const created = await client.request(
					"session/new",
					{ cwd: options.cwd, mcpServers },
					SESSION_REQUEST_TIMEOUT_MS,
				);
				acpSessionId = created.sessionId;
			}
			if (!acpSessionId) throw new Error("acp agent returned no session id");
		} catch (error) {
			client.close();
			throw error;
		}

		const session: AcpSession = {
			client,
			acpSessionId,
			cwd: options.cwd,
			envFingerprint: configFingerprint(options.env),
			mcpFingerprint: configFingerprint(options.mcpServers),
			launchFingerprint,
			imagesSupported: Boolean(init.agentCapabilities?.promptCapabilities?.image),
		};
		client.setPermissionHandler((request) => answerPermission(session, request));
		this.sessions.set(options.sessionId, session);
		return session;
	}

	async *execute(
		input: AgentInput,
		options: AgentExecuteOptions,
	): AsyncIterableIterator<RawAgentEvent> {
		const controller = this.trackTurn(options.sessionId, options.signal);
		const queue = new AsyncQueue<RawAgentEvent>();
		const unsubscribe: Array<() => void> = [];
		let cancelTimer: ReturnType<typeof setTimeout> | undefined;
		let session: AcpSession | undefined;
		try {
			session = await this.resolveSession(options);
			session.turn = {
				broker: options.onPermissionRequest,
				mode: options.permissionMode,
				signal: controller.signal,
			};
			options.onNativeSession?.(session.acpSessionId, {
				resumed: session.acpSessionId === options.resumeSessionId,
			});
			const { client, acpSessionId } = session;

			unsubscribe.push(
				client.onSessionUpdate((notification) => {
					if (notification.sessionId !== acpSessionId) return;
					queue.push({ method: "session/update", params: notification });
				}),
			);
			unsubscribe.push(
				client.onClose((err) => queue.fail(err ?? new Error("acp agent exited mid-turn"))),
			);

			const onAbort = () => {
				// ACP semantics: session/cancel makes the in-flight prompt resolve
				// with stopReason=cancelled. Bound the wait for misbehaving agents.
				void client.notify("session/cancel", { sessionId: acpSessionId });
				cancelTimer = setTimeout(
					() => queue.fail(new Error("acp agent ignored session/cancel")),
					this.agentOptions.cancelGraceMs ?? CANCEL_GRACE_MS,
				);
				cancelTimer.unref?.();
			};

			if (controller.signal.aborted) {
				// Aborted while the session was being set up (a listener added now
				// would never fire) — never start the prompt at all.
				queue.push({ method: "session/prompt_result", params: { stopReason: "cancelled" } });
				queue.end();
			} else {
				controller.signal.addEventListener("abort", onAbort, { once: true });
				const prompt: PromptRequest = {
					sessionId: acpSessionId,
					prompt: toPromptBlocks(input, session.imagesSupported),
				};
				client.request("session/prompt", prompt).then(
					(response) => {
						queue.push({ method: "session/prompt_result", params: response });
						queue.end();
					},
					(error: unknown) => {
						queue.push({ method: "error", params: { message: String(error) } });
						queue.end();
					},
				);
			}

			for await (const event of queue) {
				yield event;
			}
		} finally {
			if (cancelTimer) clearTimeout(cancelTimer);
			for (const off of unsubscribe) off();
			if (session) session.turn = undefined;
			this.endTurn(options.sessionId, controller);
			if (session && !session.client.closed) {
				this.sessions.armIdle(
					options.sessionId,
					session,
					this.agentOptions.idleTimeoutMs ?? IDLE_TIMEOUT_MS,
				);
			}
		}
	}

	override async release(sessionId: string): Promise<void> {
		await super.release(sessionId);
		this.sessions.close(sessionId);
	}

	override async terminateAll(): Promise<void> {
		await super.terminateAll();
		this.sessions.closeAll();
	}
}
