# Consuming the agent-server stream

The integration recipe, written down once — every rule here was re-derived
independently by at least one real consumer before it landed in this file.

## Fold events with the shipped reducer

Do not hand-roll a `switch (event.type)` state fold. The package ships the
canonical one:

```ts
import { emptyConversation, reduceConversation, pendingPermissions } from "@zvada/agent-server";

let conversation = emptyConversation();
for await (const event of turn.events) {
  conversation = reduceConversation(conversation, event); // pure, copy-on-write
  render(conversation);                                    // React-friendly identities
  for (const request of pendingPermissions(conversation)) prompt(request);
}
```

The reducer encodes the rules consumers get wrong first:

- **Every turn starts with your own prompt echoed back.** See below — this is
  the rule that surprises consumers upgrading to 0.3.0.

- **Upsert parts by `part.id`.** A tool part can complete AFTER its message —
  or its turn — ended; the event's `messageId` names the original message and
  the upsert lands there. If you persist per-event, your writes must be
  upserts, never inserts.
- **Snapshots are authoritative; deltas are streaming sugar.** `message.part`
  replaces whatever `message.part.delta`s built. Never append a snapshot's
  text onto delta-accumulated text.
- **`turn.ended.tokens` ≠ `session.usage`.** The first is the turn's billing
  total (sum for spend); the second is the live context-window gauge (render
  for "how full"). Different numbers, both kept by the reducer.
- **Permissions resolve exactly once.** Turn end or cancel resolves pending
  requests as `cancelled`; you will always observe a `permission.resolved`
  before that turn's `turn.ended`.

Branch on the outcome with `isCleanStop` / `isFailureStopReason` rather than
your own list: `cancelled` is clean (the user asked for the stop), `error` is
not, and because `StopReason` is OPEN, anything neither this build nor yours
recognizes counts as a failure — the safe direction.

## Fold with changes when you WRITE

Rendering needs the state; persisting needs to know what moved. Use
`reduceConversationWithChanges` and let the fold tell you:

```ts
const { state, changes } = reduceConversationWithChanges(previous, event);
for (const change of changes) {
  switch (change.kind) {
    case "message-upserted": upsertMessageRow(state, change.messageId); break;
    case "part-upserted":    upsertPartRow(state, change.messageId, change.partId); break;
    case "turn-updated":     upsertTurnRow(state, change.turnId); break;
    // …message-ended · delta-buffered · compaction-upserted · permission-updated
    // usage-updated · session-meta-updated · session-ended · unknown-event-recorded
  }
}
```

The changes are recorded BY the fold, not diffed from its output —
`reduceConversation` is the same function with the recorder discarded, so
there is no second implementation to drift. A fold that changed nothing (a
replayed duplicate) yields `[]`, which is your cue to skip the write
entirely. SQL semantics stay yours: `ON CONFLICT` vs `REPLACE`, `COALESCE`
guards, and which columns are yours to own are schema knowledge, not fold
knowledge.

## Project the state with the shipped selectors

Four pure functions over `ConversationState`, so a UI does not re-derive them:

- `groupIntoTurns(state)` — turn cards: consecutive entries of the same turn
  and the same speaker. `isLatest` is true for the FINAL group only; render
  streaming affordances on it and nothing else, or the moment the next
  prompt's echo lands the previous — completed — answer flips back into
  "working".
- `subagentGroups(state)` — parented messages keyed by the `toolCallId` that
  spawned them, to nest under that tool card (and to filter out of the main
  flow, or the subagent's work prints twice).
- `agentActivity(state)` — `thinking` | `generating` | `tool_running` |
  `tool_failed` | `idle`, from the last part of the last top-level assistant
  message of the last ACTIVE turn. `idle` during an active turn means
  "between observable activities", not "finished" — combine it with your own
  busy flag.
- `toolResultText(toolPart.state)` — the display fallback: completed →
  `output`, failed → `error`, everything else → `""` (deliberately empty, not
  invented placeholder prose).

## Track `seq` with the shared cursor

If you fold envelopes yourself — forwarded over your own WebSocket, replayed
from a log — use `createSeqCursor()` instead of comparing numbers by hand:

```ts
const cursor = createSeqCursor();
switch (cursor.advance(envelope.sessionId, envelope.seq)) {
  case "deliver":   return fold(envelope.event);
  case "duplicate": return;                       // already folded
  case "gap":       return holdAndReplay(envelope); // request events/replay
  case "reset":     return dropLocalStateAndFold(envelope); // the log restarted at 1
}
```

`reset` is the one that is easy to get wrong: a restarted server begins the
session log at 1 again, and treating that as a duplicate silently discards the
entire post-restart stream. `duplicate` and `gap` leave the cursor untouched,
so healed events still land in order. `AgentServerClient` uses this exact
object — there is no second implementation.

## Render by role — the turn opens with the user echo

Every turn now begins with the submitted input echoed back as a complete user
message, before any harness output:

```text
turn.started
  message.started {role: "user", outputIndex: 0}   ← the echo
    message.part*                                  ← one per input part, state "done"
  message.ended
  message.started {role: "assistant", outputIndex: 1}   ← the model's reply
  ...
turn.ended
```

Consequences, in the order they bite:

- **A consumer that renders every `message.part` as model output now prints the
  user's own prompt.** Filter by the role of the part's message — never by
  position. `conversationMessages(state)` gives the timeline's messages in
  order, each with its `role`, so `messages.filter(m => m.role === "assistant")`
  is the whole fix.
- **`outputIndex: 0` is the echo; assistant messages start at 1.** Anything
  keyed on "the first message of the turn is the model's" needs re-keying.
- **The echo is predictable — don't reconcile, PREDICT.** Its ids are derived
  from the turn id you minted:

  ```ts
  const turnId = generateUUIDv7();
  renderOptimistically({
    messageId: echoMessageId(turnId),        // `echo-${turnId}`
    parts: createUserEchoParts(input, turnId), // ids `echo-${turnId}-${index}`
  });
  await client.runTurn({ turnId, input, config });
  ```

  The echo that arrives upserts onto your optimistic bubble by id: same
  message, same parts, byte for byte. No placeholder to swap, no window where
  the prompt renders twice, and multimodal parts survive (the swap-a-look-alike
  approach is where file and image parts got dropped). These two are the
  documented exception to engine-minted UUIDv7 ids — everything else on the
  wire stays opaque, and nothing may parse structure out of an id.
- The stream is now a complete transcript. Multi-client attach, replay and
  persistence no longer need the client's private copy of the prompt — which
  is the point: a second UI attaching mid-turn sees what was asked.

`session.created` is unrelated to this ordering and lands **mid-turn** (it
carries the harness-native id, which does not exist until the harness's first
yield). Persist it whenever it arrives.

## Tolerate the unknown

The client delivers events it does not recognize instead of dropping them: a
newer server's event type arrives as `UnknownEvent {type, sessionId?, raw}`,
and an unknown part type inside a known `message.part` as
`UnknownPart {type, id, sessionId, messageId, raw}`. Both keep their place in
the order, and the unknown event still advances the per-session `seq` — a
dropped event would read as an unfillable gap and kill the turn handle.

`reduceConversation` accepts the union as-is (unknown events land in
`state.unknownEvents`, unknown parts in their message's `parts`). In your own
code, narrow with `isUnknownEvent` / `isUnknownPart` before switching on a
known `type`, and **store and forward what you don't understand** — a
round trip through your persistence layer must not be where a newer server's
data disappears. A known type with a malformed body still fails loudly.

## Persist for resume

Store `state.nativeSessionId` (from `session.created`) keyed by your logical
`sessionId`, and pass it back as `config.resumeSessionId` to continue a
conversation later — across processes and machines. Check
`session.created.resumed` on resume turns: `false` means the harness fell
back to a fresh session (context lost) — surface that, never swallow it.
Compare with the flag, not ids: a successful Claude resume mints a NEW native
id.

## Retry safely

Turn admission is idempotent on `{sessionId, turnId}`: mint the `turnId`
client-side, and a retried `turn/start` (or embedded `runtime.run`) with the
identical request converges on the original execution — the wire acks it with
`deduplicated: true` and `events/replay` fills anything you missed. The same
`turnId` with different input fails loudly (`turnConflict` /
`TurnConflictError`). This is what makes at-least-once RPC layers (Durable
Object retries, queue redelivery) safe over the engine.

## Cancel honestly

`turn/cancel` (and `runtime.cancel`) accept a `turnId` stamp — always pass
the id of the turn you mean, so a late cancel can never kill its successor
(a stale stamp returns `{outcome: "no_active_turn", activeTurnId}`). The
result is a single-outcome union: `cancelled` means the harness confirmed the
interrupt; `unconfirmed` means it did not land — including the window between
the `turn/start` quick-ack and the harness registering its abortable turn —
and the agent may still be running. On `unconfirmed`, report "stopping…" and
treat `turn.ended` as the source of truth, not the cancel response.

## Verify the stream

`verifyStreamContract(events, {seqs?})` machine-checks a recorded stream
against the ordering/delivery contract — echo-first, bracket pairing,
upsert-address stability, delta-follows-snapshot, permissions resolve-once,
seq monotonicity — then folds it twice: once to assert the reducer's final
state agrees with the authoritative snapshots, and once with every upsert
delivered TWICE to assert re-delivery changes nothing (the property a replay
overlap or a reconnect resync depends on). Run it in CI over recorded fixtures
and in staging over live turns (`agent-server run "…" --verify` exits 1 on any
violation); a product pipeline (a Durable Object, a persistence shim) can run
it on replay to fail loudly instead of storing a corrupt projection.

It takes **one session's** stream, of any length: `session.created` is expected
once per turn (not once per stream), deltas that trail the last snapshot of a
cancelled turn are legal (a snapshot is a prefix of the fold, not a ceiling),
and unknown event/part types are forward-compat rather than violations. Pass
`{expectEcho: false}` for a partial capture that begins mid-turn.

## Own your session resources

Register `onSessionEnd` (claude options) to release per-session resources —
BYOK proxy keys, recorders — instead of re-deriving termination from side
effects. Reasons: `idle` (idle-timeout eviction), `replaced` (config change
restarted the subprocess — usually respawns immediately with context kept),
`released` (explicit close), `shutdown`. On the wire, call `session/close`
when a logical session will not be resumed: it frees the replay buffer and
the harness-native state (until then, memory cost ≈ `bufferSize` events per
session).

`session/close` also broadcasts `session.ended {reason: "released"}` — but
only to subscribers **connected at that moment**, because the replay log is
retired in the same operation. A subscriber that was detached does not get the
event later: its `events/replay` answers `unknownSession`, and that answer *is*
the terminal signal (the session is gone; nothing more will be appended to it).
Treat `unknownSession` on replay as "session over", not as an error to retry.

## Listen to the engine's diagnostics

Pass `onDiagnostic` (registry/runtime/proxy options) and log what arrives:
`interruptTimeout`, `resumeFallback`, `sinkError`, `proxyUpstreamAuth`.
These are the signals the engine deliberately does not fail turns over — a
product that doesn't surface them debugs blind.

## Wire transports

`spawn` (stdio subprocess), `connect` (dial a `--listen` server; reconnects
and replays by default), `attach` (an accepted socket, e.g. the server dialed
OUT to you via `--dial`). The client dedupes by per-session `seq` and heals
gaps via `events/replay`; an unfillable gap raises `EventGapError` instead of
silently losing events. The WebSocket wire itself carries no auth — keep it
on a trusted channel (localhost, sandbox-internal, or behind your own
authenticated boundary).
