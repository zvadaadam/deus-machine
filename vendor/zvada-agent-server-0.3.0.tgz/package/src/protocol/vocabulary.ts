import { z } from "zod";

/**
 * Law 3 — an OPEN vocabulary. The schema accepts values this build does not
 * know (a newer engine's `stopReason`, an adapter's `_`-prefixed extension),
 * because rejecting them is exactly how a forward-compatible wire turns into a
 * compatibility break — the failure ACP moved to v2 to escape. The cast keeps
 * the TypeScript side as `"a" | "b" | (string & {})`, so the canonical members
 * still autocomplete and still get checked by the casing test (Law 9), while
 * the runtime lets an unknown value through to be preserved.
 *
 * Blank is the one thing every open vocabulary rejects: `""` and `"   "` are
 * not values a consumer can switch on, render, or persist — they are a
 * producer bug, and accepting them silently is how it reaches a UI.
 */
export function openVocabulary<T extends string>(): z.ZodType<T> {
	return z.string().min(1).regex(/\S/, "must not be blank") as unknown as z.ZodType<T>;
}
