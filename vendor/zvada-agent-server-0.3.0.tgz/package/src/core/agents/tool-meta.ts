import type { ToolKind, ToolLocation, ToolMeta } from "../../protocol/index.ts";

/**
 * Maps provider-native tool names onto the normalized ToolKind taxonomy and
 * extracts touched file locations from tool inputs. Pure best-effort: unknown
 * tools are `other` and produce no locations.
 */

const CLAUDE_TOOL_KINDS: Record<string, ToolKind> = {
	Read: "read",
	NotebookRead: "read",
	Edit: "edit",
	Write: "edit",
	MultiEdit: "edit",
	NotebookEdit: "edit",
	Bash: "execute",
	BashOutput: "execute",
	KillShell: "execute",
	Grep: "search",
	Glob: "search",
	LS: "search",
	WebFetch: "fetch",
	WebSearch: "fetch",
	Task: "think",
	Agent: "think",
	TodoWrite: "think",
	ExitPlanMode: "switch_mode",
	EnterPlanMode: "switch_mode",
};

export function claudeToolKind(toolName: string): ToolKind {
	if (CLAUDE_TOOL_KINDS[toolName]) return CLAUDE_TOOL_KINDS[toolName];
	// MCP tools arrive as mcp__server__tool.
	if (toolName.startsWith("mcp__")) return "other";
	return "other";
}

const PATH_INPUT_KEYS = ["file_path", "filePath", "path", "notebook_path"] as const;

export function toolLocationsFromInput(input: Record<string, unknown>): ToolLocation[] | undefined {
	for (const key of PATH_INPUT_KEYS) {
		const v = input[key];
		if (typeof v === "string" && v) return [{ path: v }];
	}
	return undefined;
}

export function claudeToolMeta(toolName: string, input?: Record<string, unknown>): ToolMeta {
	return {
		kind: claudeToolKind(toolName),
		...(input ? { locations: toolLocationsFromInput(input) } : {}),
	};
}

/** Codex tools are already normalized names; kinds are fixed per item type. */
export const CODEX_TOOL_KINDS = {
	shell: "execute",
	apply_patch: "edit",
	web_search: "fetch",
	mcp: "other",
} as const satisfies Record<string, ToolKind>;

export function codexFileChangeLocations(
	changes: Array<{ path: string }> | undefined,
): ToolLocation[] | undefined {
	if (!changes?.length) return undefined;
	return changes.map((c) => ({ path: c.path }));
}
