// CLI provisioning — resolve/download the native CLIs the harnesses spawn.
export { CLI_TOOLS, type CliTool, DEFAULT_PINS, toolForHarness } from "./pins.ts";
export { type PlatformInfo, detectPlatform } from "./platform.ts";
export {
	CliProvisioner,
	type ProvisionMode,
	type ProvisionOptions,
	type ProvisionerDeps,
	type ResolvedCli,
} from "./provisioner.ts";
