import { z } from "zod";

/**
 * A UI-authored span over the text (mentions, pills, inline references) that
 * survives the round trip through the model, the user echo, and persistence.
 * The model sees plain text; `byteRange` is [start, end) over the UTF-8 bytes
 * of the parent `text`.
 */
export const TextElementSchema = z.object({
	byteRange: z.tuple([z.number().int().nonnegative(), z.number().int().nonnegative()]),
	/** Human-readable placeholder for the element, displayed in the UI. */
	placeholder: z.string().optional(),
});
export type TextElement = z.infer<typeof TextElementSchema>;

/** Inbound user content for a turn: plain text, or multimodal blocks. */
export const TextPartInputSchema = z.object({
	type: z.literal("text"),
	id: z.string().optional(),
	text: z.string().min(1),
	elements: z.array(TextElementSchema).optional(),
});
export type TextPartInput = z.infer<typeof TextPartInputSchema>;

export const ImagePartInputSchema = z
	.object({
		type: z.literal("image"),
		id: z.string().optional(),
		/** Either a URL or base64 `data` (one is required). */
		url: z.string().min(1).optional(),
		data: z.string().min(1).optional(),
		mimeType: z.string(),
		filename: z.string().optional(),
	})
	.refine((part) => part.url !== undefined || part.data !== undefined, {
		message: "image input requires a non-empty url or data payload",
	});
export type ImagePartInput = z.infer<typeof ImagePartInputSchema>;

export const FilePartInputSchema = z
	.object({
		type: z.literal("file"),
		id: z.string().optional(),
		url: z.string().min(1).optional(),
		data: z.string().min(1).optional(),
		mimeType: z.string(),
		filename: z.string().optional(),
	})
	.refine((part) => part.url !== undefined || part.data !== undefined, {
		message: "file input requires a non-empty url or data payload",
	});
export type FilePartInput = z.infer<typeof FilePartInputSchema>;

export const PartInputSchema = z.discriminatedUnion("type", [
	TextPartInputSchema,
	ImagePartInputSchema,
	FilePartInputSchema,
]);
export type PartInput = z.infer<typeof PartInputSchema>;

/** A turn's input is either a bare string or a list of typed parts. */
export const AgentInputSchema = z.union([z.string(), z.array(PartInputSchema)]);
export type AgentInput = z.infer<typeof AgentInputSchema>;

/** Collapse an AgentInput down to the text the model sees first. */
export function inputToText(input: AgentInput): string {
	if (typeof input === "string") return input;
	return input
		.filter((p): p is TextPartInput => p.type === "text")
		.map((p) => p.text)
		.join("\n\n");
}
